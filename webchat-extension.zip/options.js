(function () {
  'use strict';

  /**
   * 多模型提供商配置
   *
   * - visionCapable：该提供商的协议本身是否支持图像消息。为 false 的 provider
   *   即使用户在 UI 勾选"当前模型支持视觉"也会被忽略，避免发出对端不接受的 payload。
   * - defaultSupportsVision：visionCapable=true 时，"未被用户手动调整"前的默认值。
   *   用户可在 options 中针对当前选中的模型单独覆盖，存储在 providers[key].supportsVision。
   */
  const PROVIDERS = {
    openai: {
      name: 'OpenAI',
      apiBase: 'https://api.openai.com/v1/chat/completions',
      models: ['gpt-5.5', 'gpt-5.4', 'gpt-4-turbo', 'gpt-3.5-turbo'],
      defaultModel: 'gpt-5.5',
      requiresKey: true,
      authType: 'bearer',
      requestFormat: 'openai',
      streamFormat: 'sse',
      visionCapable: true,
      defaultSupportsVision: true,
      apiKeyPlaceholder: '请输入 OpenAI API Key',
      modelHelp: '推荐：gpt-4o-mini（性价比高）、gpt-4o（最强）'
    },
    deepseek: {
      name: 'DeepSeek',
      apiBase: 'https://api.deepseek.com/chat/completions',
      models: ['deepseek-v4-pro', 'deepseek-v4-flash', 'deepseek-chat', 'deepseek-reasoner'],
      defaultModel: 'deepseek-v4-pro',
      requiresKey: true,
      authType: 'bearer',
      requestFormat: 'openai',
      streamFormat: 'sse',
      visionCapable: false,
      defaultSupportsVision: false,
      apiKeyPlaceholder: '请输入 DeepSeek API Key',
      modelHelp: '推荐：deepseek-chat（通用）、deepseek-reasoner（推理）'
    },
    claude: {
      name: 'Claude',
      apiBase: 'https://api.anthropic.com/v1/messages',
      models: ['claude-sonnet-4-20250514', 'claude-haiku-4-20250414', 'claude-opus-4-20250514'],
      defaultModel: 'claude-sonnet-4-20250514',
      requiresKey: true,
      authType: 'x-api-key',
      requestFormat: 'anthropic',
      streamFormat: 'sse',
      extraHeaders: { 'anthropic-version': '2023-06-01' },
      visionCapable: true,
      defaultSupportsVision: true,
      apiKeyPlaceholder: '请输入 Anthropic API Key',
      modelHelp: '推荐：claude-sonnet-4（均衡）、claude-opus-4（最强）'
    },
    gemini: {
      name: 'Gemini',
      apiBase: 'https://generativelanguage.googleapis.com/v1beta/models/{model}:streamGenerateContent',
      models: ['gemini-2.5-flash', 'gemini-2.5-pro', 'gemini-2.0-flash'],
      defaultModel: 'gemini-2.5-flash',
      requiresKey: true,
      authType: 'query',
      requestFormat: 'gemini',
      streamFormat: 'json-stream',
      visionCapable: true,
      defaultSupportsVision: true,
      apiKeyPlaceholder: '请输入 Google AI API Key',
      modelHelp: '推荐：gemini-2.5-flash（快速）、gemini-2.5-pro（最强）'
    },
    ollama: {
      name: '本地模型 (Ollama)',
      apiBase: 'http://127.0.0.1:11434/api/chat',
      models: [],
      defaultModel: 'qwen2.5',
      requiresKey: false,
      authType: 'none',
      requestFormat: 'ollama',
      streamFormat: 'ndjson',
      fetchModels: true,
      visionCapable: true, // ollama 视模型而定，由用户开关决定
      defaultSupportsVision: false,
      apiKeyPlaceholder: '本地模型无需 API 密钥',
      modelHelp: '使用前请确保已安装模型：ollama pull qwen2.5'
    },
    custom: {
      name: '自定义 API',
      apiBase: '',
      models: [],
      defaultModel: '',
      requiresKey: true,
      authType: 'bearer',
      requestFormat: 'openai',
      streamFormat: 'sse',
      visionCapable: true, // 自定义 OpenAI 兼容端点，由用户开关决定
      defaultSupportsVision: false,
      apiKeyPlaceholder: '请输入 API 密钥',
      modelHelp: '支持 OpenAI 兼容的 API 接口'
    }
  };

  const DEFAULT_SETTINGS = {
    activeProvider: 'openai',
    maxTokens: 2048,
    temperature: 0.7,
    enableContext: true,
    maxContextRounds: 3,
    systemPrompt: '你是一个帮助理解网页内容的AI助手。请使用Markdown格式回复。',
    autoHideDialog: true,
    // 显示模式：'floating'（悬浮，可拖动） | 'sidebar-left' | 'sidebar-right'
    displayMode: 'floating',
    // 侧边栏宽度（px）
    sidebarWidth: 380,
    // 图片识别（多模态）
    enableImageRecognition: false,
    maxImagesPerPage: 3,
    // 视觉副模型 fallback：主模型不支持视觉时把图片转文字描述再喂给主模型
    // 空字符串 = 自动从已配 key 的 visionCapable provider 中挑选
    visionFallbackProvider: '',
    // 旧行为兜底：未标记任何图片时是否自动抓取页面图片（默认关，鼓励用户显式标记）
    autoCollectPageImages: false,
    // 多 tab 引用压缩
    enableTabCompression: true,
    tabCompressMaxChars: 3000,
    tabCompressMode: 'hybrid', // 'truncate' | 'ai' | 'hybrid'
    providers: Object.fromEntries(
      Object.entries(PROVIDERS).map(([key, config]) => [
        key,
        {
          apiKey: '',
          apiBase: config.apiBase,
          model: config.defaultModel,
          supportsVision: !!config.defaultSupportsVision
        }
      ])
    )
  };

  /**
   * API 适配器 — 统一不同提供商的请求和响应格式
   */
  class ApiAdapter {
    constructor(providerKey, config) {
      this.providerKey = providerKey;
      this.provider = PROVIDERS[providerKey];
      this.config = config; // { apiKey, apiBase, model }
    }

    /**
     * 构建请求 URL
     *
     * 对 OpenAI 兼容协议（openai / deepseek / custom）做容错：
     * 用户只填 https://api.deepseek.com 或 https://api.deepseek.com/v1
     * 会被自动补全为 https://api.deepseek.com/v1/chat/completions。
     */
    buildUrl() {
      let url = this.config.apiBase || this.provider.apiBase;

      if (this.provider.requestFormat === 'gemini') {
        url = url.replace('{model}', this.config.model);
        url += `?key=${this.config.apiKey}&alt=sse`;
        return url;
      }

      if (this.provider.requestFormat === 'openai') {
        url = normalizeOpenAIBase(url);
      }

      return url;
    }

    /**
     * 构建请求头
     */
    buildHeaders() {
      const headers = { 'Content-Type': 'application/json' };

      if (this.provider.authType === 'bearer') {
        headers['Authorization'] = `Bearer ${this.config.apiKey}`;
      } else if (this.provider.authType === 'x-api-key') {
        headers['x-api-key'] = this.config.apiKey;
      }
      // authType === 'query' 或 'none' 不需要 header 认证

      if (this.provider.extraHeaders) {
        Object.assign(headers, this.provider.extraHeaders);
      }

      return headers;
    }

    /**
     * 构建请求体
     *
     * messages[i].content 可能是字符串，也可能是 multimodal 数组：
     *   [{type:'text', text:'...'}, {type:'image', dataUrl:'data:image/jpeg;base64,...'}]
     * 由各 provider 分支转换成对应格式。
     */
    buildRequestBody(messages, options = {}) {
      const { maxTokens = 2048, temperature = 0.7 } = options;
      const format = this.provider.requestFormat;

      if (format === 'openai') {
        return {
          model: this.config.model,
          messages: messages.map(m => ({
            role: m.role,
            content: toOpenAIContent(m.content)
          })),
          max_tokens: maxTokens,
          temperature,
          stream: true
        };
      }

      if (format === 'anthropic') {
        // Claude 要求 system 单独传，不在 messages 数组中
        const systemMsg = messages.find(m => m.role === 'system');
        const chatMessages = messages.filter(m => m.role !== 'system');

        return {
          model: this.config.model,
          system: contentToText(systemMsg?.content) || '',
          messages: chatMessages.map(m => ({
            role: m.role,
            content: toAnthropicContent(m.content)
          })),
          max_tokens: maxTokens,
          temperature,
          stream: true
        };
      }

      if (format === 'gemini') {
        // Gemini 使用完全不同的格式
        const systemMsg = messages.find(m => m.role === 'system');
        const chatMessages = messages.filter(m => m.role !== 'system');

        const contents = chatMessages.map(msg => ({
          role: msg.role === 'assistant' ? 'model' : 'user',
          parts: toGeminiParts(msg.content)
        }));

        const body = {
          contents,
          generationConfig: {
            maxOutputTokens: maxTokens,
            temperature
          }
        };

        if (systemMsg) {
          body.systemInstruction = { parts: [{ text: contentToText(systemMsg.content) }] };
        }

        return body;
      }

      if (format === 'ollama') {
        // Ollama 不支持视觉（除少数模型），统一降级为纯文本
        return {
          model: this.config.model,
          messages: messages.map(m => ({ role: m.role, content: contentToText(m.content) })),
          stream: true,
          options: {
            temperature,
            num_predict: maxTokens
          }
        };
      }

      // 默认使用 openai 格式
      return {
        model: this.config.model,
        messages: messages.map(m => ({ role: m.role, content: toOpenAIContent(m.content) })),
        max_tokens: maxTokens,
        temperature,
        stream: true
      };
    }

    /**
     * 解析流式响应的一行数据，返回文本内容或 null
     */
    parseStreamLine(line) {
      const format = this.provider.streamFormat;

      if (format === 'sse') {
        return this._parseSSELine(line);
      }

      if (format === 'ndjson') {
        return this._parseNDJSONLine(line);
      }

      if (format === 'json-stream') {
        return this._parseSSELine(line);
      }

      return null;
    }

    _parseSSELine(line) {
      if (!line.startsWith('data: ')) return null;

      const data = line.slice(6).trim();
      if (data === '[DONE]') return { done: true };

      try {
        const parsed = JSON.parse(data);
        return { done: false, content: this._extractContent(parsed) };
      } catch {
        return null;
      }
    }

    _parseNDJSONLine(line) {
      if (!line.trim()) return null;

      try {
        const parsed = JSON.parse(line);

        if (parsed.done) return { done: true };

        return { done: false, content: this._extractContent(parsed) };
      } catch {
        return null;
      }
    }

    /**
     * 从解析后的 JSON 中提取文本内容
     */
    _extractContent(parsed) {
      const format = this.provider.requestFormat;

      if (format === 'openai') {
        return parsed.choices?.[0]?.delta?.content || '';
      }

      if (format === 'anthropic') {
        // Claude SSE 有多种事件类型
        if (parsed.type === 'content_block_delta') {
          return parsed.delta?.text || '';
        }
        return '';
      }

      if (format === 'gemini') {
        return parsed.candidates?.[0]?.content?.parts?.[0]?.text || '';
      }

      if (format === 'ollama') {
        return parsed.message?.content || '';
      }

      return '';
    }

    /**
     * 判断流是否结束
     */
    isStreamEnd(parsed) {
      const format = this.provider.requestFormat;

      if (format === 'anthropic') {
        return parsed.type === 'message_stop';
      }

      if (format === 'ollama') {
        return parsed.done === true;
      }

      return false;
    }

    /**
     * 非流式一次性调用：用于视觉副模型把图转文字这种"问一下要结果"的场景。
     * 复用 buildHeaders/buildRequestBody，但强制 stream:false，并自行解析单次响应。
     * 返回 { text } 或抛出 Error。
     */
    async callOnce(messages, options = {}, { signal } = {}) {
      const headers = this.buildHeaders();
      const body = this.buildRequestBody(messages, options);

      // 关掉 stream
      if ('stream' in body) body.stream = false;

      // URL 调整：Gemini 流式 URL 形如 .../models/{m}:streamGenerateContent?...&alt=sse
      let url = this.buildUrl();
      if (this.provider.requestFormat === 'gemini') {
        url = url.replace(':streamGenerateContent', ':generateContent').replace('&alt=sse', '');
      }

      const response = await fetch(url, {
        method: 'POST',
        headers,
        body: JSON.stringify(body),
        signal
      });

      if (!response.ok) {
        const errText = await response.text().catch(() => '');
        throw new Error(`HTTP ${response.status}: ${errText.slice(0, 300)}`);
      }

      const json = await response.json();
      const text = extractFullText(this.provider.requestFormat, json);
      if (!text) throw new Error('副模型返回空内容');
      return { text };
    }
  }

  function extractFullText(format, json) {
    if (format === 'openai') {
      return json?.choices?.[0]?.message?.content || '';
    }
    if (format === 'anthropic') {
      const parts = json?.content || [];
      return parts.map(p => (p.type === 'text' ? p.text : '')).join('').trim();
    }
    if (format === 'gemini') {
      const parts = json?.candidates?.[0]?.content?.parts || [];
      return parts.map(p => p.text || '').join('').trim();
    }
    if (format === 'ollama') {
      return json?.message?.content || '';
    }
    return '';
  }

  /**
   * 测试 API 配置是否可用
   */
  async function testApiConnection(providerKey, config) {
    const adapter = new ApiAdapter(providerKey, config);

    const messages = [
      { role: 'system', content: '你是一个帮助理解网页内容的AI助手。' },
      { role: 'user', content: '请回复：API配置测试成功' }
    ];

    const url = adapter.buildUrl();
    const headers = adapter.buildHeaders();
    const body = adapter.buildRequestBody(messages, { maxTokens: 50 });

    // 测试时不使用流式
    if (body.stream !== undefined) body.stream = false;

    const response = await fetch(url.replace('&alt=sse', ''), {
      method: 'POST',
      headers,
      body: JSON.stringify(body)
    });

    if (!response.ok) {
      const errorText = await response.text();
      try {
        const errorJson = JSON.parse(errorText);
        throw new Error(errorJson.error?.message || `请求失败 (${response.status})`);
      } catch (e) {
        if (e.message.includes('请求失败')) throw e;
        throw new Error(`请求失败 (${response.status}): ${errorText.slice(0, 200)}`);
      }
    }

    return true;
  }

  /**
   * 获取 Ollama 已安装的模型列表
   */
  async function fetchOllamaModels(apiBase = 'http://127.0.0.1:11434') {
    try {
      const response = await fetch(`${apiBase}/api/tags`);
      if (!response.ok) throw new Error('无法连接到 Ollama');

      const data = await response.json();
      return (data.models || []).map(m => m.name);
    } catch {
      throw new Error('无法获取 Ollama 模型列表，请确保 Ollama 服务已启动');
    }
  }

  // ====================================================================
  // multimodal content 转换辅助
  // ====================================================================
  // 上层传入的 message.content 统一格式：
  //   string                                    // 纯文本
  //   | Array<{type:'text', text} | {type:'image', dataUrl}>   // 多模态
  //
  // 各 provider 的 wire format 不同，下面的 helper 把统一格式转成对应 wire 形式。

  /**
   * 把用户填写的 OpenAI 兼容 base URL 归一化到带 /chat/completions 的完整地址。
   * 兼容这些写法：
   *   https://api.deepseek.com                    → https://api.deepseek.com/v1/chat/completions
   *   https://api.deepseek.com/                   → https://api.deepseek.com/v1/chat/completions
   *   https://api.deepseek.com/v1                 → https://api.deepseek.com/v1/chat/completions
   *   https://api.deepseek.com/v1/                → https://api.deepseek.com/v1/chat/completions
   *   https://api.deepseek.com/chat/completions   → 原样保留
   *   https://api.openai.com/v1/chat/completions  → 原样保留
   */
  function normalizeOpenAIBase(raw) {
    if (!raw) return raw;
    let url = raw.trim().replace(/\/+$/, '');
    // 已经是完整 endpoint
    if (/\/chat\/completions(\?|$)/.test(url)) return url;
    // 已经带 /v1（或其它版本号），直接拼 /chat/completions
    if (/\/v\d+$/.test(url)) return url + '/chat/completions';
    // 否则按 OpenAI 兼容默认补 /v1/chat/completions
    return url + '/v1/chat/completions';
  }

  function isMultimodalArray(content) {
    return Array.isArray(content);
  }

  function contentToText(content) {
    if (!content) return '';
    if (typeof content === 'string') return content;
    if (!isMultimodalArray(content)) return String(content);
    return content
      .map(part => part.type === 'text' ? part.text : '')
      .filter(Boolean)
      .join('\n');
  }

  function toOpenAIContent(content) {
    if (!isMultimodalArray(content)) return content || '';
    return content.map(part => {
      if (part.type === 'text') return { type: 'text', text: part.text };
      if (part.type === 'image') return { type: 'image_url', image_url: { url: part.dataUrl } };
      return null;
    }).filter(Boolean);
  }

  function toAnthropicContent(content) {
    if (!isMultimodalArray(content)) return content || '';
    return content.map(part => {
      if (part.type === 'text') return { type: 'text', text: part.text };
      if (part.type === 'image') {
        const m = /^data:(image\/[a-zA-Z]+);base64,(.+)$/.exec(part.dataUrl || '');
        if (!m) return null;
        return {
          type: 'image',
          source: { type: 'base64', media_type: m[1], data: m[2] }
        };
      }
      return null;
    }).filter(Boolean);
  }

  function toGeminiParts(content) {
    if (!isMultimodalArray(content)) return [{ text: content || '' }];
    return content.map(part => {
      if (part.type === 'text') return { text: part.text };
      if (part.type === 'image') {
        const m = /^data:(image\/[a-zA-Z]+);base64,(.+)$/.exec(part.dataUrl || '');
        if (!m) return null;
        return { inline_data: { mime_type: m[1], data: m[2] } };
      }
      return null;
    }).filter(Boolean);
  }

  /**
   * 存储迁移 — 将旧格式配置迁移到新的多提供商格式
   */
  async function migrateSettings() {
    const oldSettings = await chrome.storage.sync.get(null);

    // 如果已经是新格式，跳过迁移
    if (oldSettings.activeProvider && oldSettings.providers) {
      return oldSettings;
    }

    // 检测旧格式标志
    if (!oldSettings.apiType) {
      // 全新安装，使用默认设置
      await chrome.storage.sync.set(DEFAULT_SETTINGS);
      return DEFAULT_SETTINGS;
    }

    // 执行迁移
    const newSettings = { ...DEFAULT_SETTINGS };

    // 映射旧的 apiType 到新的 activeProvider
    if (oldSettings.apiType === 'custom') {
      newSettings.activeProvider = 'openai';
    } else if (oldSettings.apiType === 'ollama') {
      newSettings.activeProvider = 'ollama';
    }

    // 迁移通用设置
    if (oldSettings.maxTokens) newSettings.maxTokens = oldSettings.maxTokens;
    if (oldSettings.temperature !== undefined) newSettings.temperature = oldSettings.temperature;
    if (oldSettings.enableContext !== undefined) newSettings.enableContext = oldSettings.enableContext;
    if (oldSettings.maxContextRounds) newSettings.maxContextRounds = oldSettings.maxContextRounds;
    if (oldSettings.systemPrompt) newSettings.systemPrompt = oldSettings.systemPrompt;
    if (oldSettings.autoHideDialog !== undefined) newSettings.autoHideDialog = oldSettings.autoHideDialog;

    // 迁移 custom API 配置到 openai provider
    if (oldSettings.custom_apiKey || oldSettings.custom_apiBase || oldSettings.custom_model) {
      newSettings.providers.openai = {
        apiKey: oldSettings.custom_apiKey || '',
        apiBase: oldSettings.custom_apiBase || PROVIDERS.openai.apiBase,
        model: oldSettings.custom_model || PROVIDERS.openai.defaultModel
      };
      // 同时保留到 custom provider
      newSettings.providers.custom = {
        apiKey: oldSettings.custom_apiKey || '',
        apiBase: oldSettings.custom_apiBase || '',
        model: oldSettings.custom_model || ''
      };
    }

    // 迁移 ollama 配置
    if (oldSettings.ollama_apiBase || oldSettings.ollama_model) {
      newSettings.providers.ollama = {
        apiKey: '',
        apiBase: oldSettings.ollama_apiBase || PROVIDERS.ollama.apiBase,
        model: oldSettings.ollama_model || PROVIDERS.ollama.defaultModel
      };
    }

    // 保留 UI 状态
    if (oldSettings.showFloatingBall !== undefined) newSettings.showFloatingBall = oldSettings.showFloatingBall;
    if (oldSettings.dialogPosition) newSettings.dialogPosition = oldSettings.dialogPosition;
    if (oldSettings.dialogSize) newSettings.dialogSize = oldSettings.dialogSize;
    if (oldSettings.ballPosition) newSettings.ballPosition = oldSettings.ballPosition;
    if (oldSettings.totalTokens) newSettings.totalTokens = oldSettings.totalTokens;

    // 清除旧格式的 key，写入新格式
    const keysToRemove = [
      'apiType', 'custom_apiKey', 'custom_apiBase', 'custom_model',
      'ollama_apiKey', 'ollama_apiBase', 'ollama_model', 'activeConfig'
    ];
    await chrome.storage.sync.remove(keysToRemove);
    await chrome.storage.sync.set(newSettings);

    return newSettings;
  }

  let currentProvider = 'openai';

  // 显示状态消息
  function showStatus(message, type = 'success') {
    const status = document.getElementById('status');
    status.textContent = message;
    status.className = `status ${type}`;
    status.style.display = 'block';

    if (message === '正在测试API配置...') {
      setTimeout(() => {
        if (status.textContent === message) status.style.display = 'none';
      }, 2000);
    }
  }

  // 更新提供商 Tab UI
  function switchProvider(providerKey) {
    currentProvider = providerKey;
    const provider = PROVIDERS[providerKey];

    // 更新 tab 激活状态
    document.querySelectorAll('.provider-tab').forEach(tab => {
      tab.classList.toggle('active', tab.dataset.provider === providerKey);
    });

    // 更新 API Key 显示
    const apiKeyGroup = document.querySelector('.api-key-group');
    apiKeyGroup.style.display = provider.requiresKey ? 'block' : 'none';
    document.getElementById('apiKey').placeholder = provider.apiKeyPlaceholder;

    // 更新模型下拉框
    const modelSelect = document.getElementById('modelSelect');
    modelSelect.innerHTML = '<option value="">手动输入...</option>';
    if (provider.models.length > 0) {
      provider.models.forEach(model => {
        const option = document.createElement('option');
        option.value = model;
        option.textContent = model;
        modelSelect.appendChild(option);
      });
      modelSelect.style.display = 'block';
    } else if (provider.fetchModels) {
      modelSelect.style.display = 'block';
      loadOllamaModels();
    } else {
      modelSelect.style.display = providerKey === 'custom' ? 'none' : 'block';
    }

    // 更新帮助文本
    document.getElementById('modelHelp').textContent = provider.modelHelp;
    document.getElementById('apiBaseHelp').textContent =
      providerKey === 'ollama' ? '本地 API 接口地址' : 'API 接口地址';

    // 从存储加载该提供商的配置
    chrome.storage.sync.get({ providers: DEFAULT_SETTINGS.providers }, (items) => {
      const config = items.providers[providerKey] || {};
      document.getElementById('apiKey').value = config.apiKey || '';
      document.getElementById('apiBase').value = config.apiBase || provider.apiBase;

      const model = config.model || provider.defaultModel;
      document.getElementById('modelInput').value = model;

      // 同步下拉框选中状态
      if (provider.models.includes(model)) {
        modelSelect.value = model;
      } else {
        modelSelect.value = '';
      }

      // 同步当前 provider 的视觉支持开关
      const visionEl = document.getElementById('modelSupportsVision');
      if (visionEl) {
        const protocolOk = provider.visionCapable !== false;
        if (!protocolOk) {
          visionEl.checked = false;
          visionEl.disabled = true;
          visionEl.title = '当前提供商协议不支持视觉输入（如 DeepSeek）';
        } else {
          visionEl.disabled = false;
          visionEl.title = '';
          const stored = config.supportsVision;
          visionEl.checked = typeof stored === 'boolean' ? stored : !!provider.defaultSupportsVision;
        }
      }
    });
  }

  // 加载 Ollama 模型列表
  async function loadOllamaModels() {
    const modelSelect = document.getElementById('modelSelect');
    try {
      const apiBase = document.getElementById('apiBase').value || PROVIDERS.ollama.apiBase;
      const baseUrl = apiBase.replace(/\/api\/chat$/, '');
      const models = await fetchOllamaModels(baseUrl);

      modelSelect.innerHTML = '<option value="">手动输入...</option>';
      models.forEach(model => {
        const option = document.createElement('option');
        option.value = model;
        option.textContent = model;
        modelSelect.appendChild(option);
      });

      // 选中当前模型
      const currentModel = document.getElementById('modelInput').value;
      if (models.includes(currentModel)) {
        modelSelect.value = currentModel;
      }
    } catch {
      modelSelect.innerHTML = '<option value="">无法获取模型列表</option>';
    }
  }

  // 保存设置
  async function saveOptions() {
    const providerKey = currentProvider;
    const apiKey = document.getElementById('apiKey').value.trim();
    const apiBase = document.getElementById('apiBase').value.trim() || PROVIDERS[providerKey].apiBase;
    const model = document.getElementById('modelInput').value.trim();

    // 验证
    const provider = PROVIDERS[providerKey];
    if (provider.requiresKey && !apiKey) {
      showStatus('API 密钥是必填项', 'error');
      return;
    }
    if (!model) {
      showStatus('请选择或输入模型名称', 'error');
      return;
    }

    const config = { apiKey, apiBase, model };

    showStatus('正在测试API配置...');

    try {
      await testApiConnection(providerKey, config);

      // 保存到存储（保留已有 supportsVision 等字段）
      const { providers = DEFAULT_SETTINGS.providers } = await chrome.storage.sync.get('providers');
      const prev = providers[providerKey] || {};
      providers[providerKey] = { ...prev, ...config };

      await chrome.storage.sync.set({
        activeProvider: providerKey,
        providers
      });

      showStatus('✅ API 配置测试成功，设置已保存');
    } catch (error) {
      showStatus(`测试失败: ${error.message}`, 'error');
    }
  }

  // 加载设置
  async function loadOptions() {
    await migrateSettings();

    const settings = await chrome.storage.sync.get({
      activeProvider: DEFAULT_SETTINGS.activeProvider,
      providers: DEFAULT_SETTINGS.providers,
      maxTokens: DEFAULT_SETTINGS.maxTokens,
      temperature: DEFAULT_SETTINGS.temperature,
      enableContext: DEFAULT_SETTINGS.enableContext,
      maxContextRounds: DEFAULT_SETTINGS.maxContextRounds,
      systemPrompt: DEFAULT_SETTINGS.systemPrompt,
      autoHideDialog: DEFAULT_SETTINGS.autoHideDialog,
      displayMode: DEFAULT_SETTINGS.displayMode,
      sidebarWidth: DEFAULT_SETTINGS.sidebarWidth,
      enableImageRecognition: DEFAULT_SETTINGS.enableImageRecognition,
      maxImagesPerPage: DEFAULT_SETTINGS.maxImagesPerPage,
      autoCollectPageImages: DEFAULT_SETTINGS.autoCollectPageImages,
      visionFallbackProvider: DEFAULT_SETTINGS.visionFallbackProvider,
      enableTabCompression: DEFAULT_SETTINGS.enableTabCompression,
      tabCompressMaxChars: DEFAULT_SETTINGS.tabCompressMaxChars,
      tabCompressMode: DEFAULT_SETTINGS.tabCompressMode
    });

    // 常规设置
    document.getElementById('autoHideDialog').checked = settings.autoHideDialog;
    document.getElementById('enableContext').checked = settings.enableContext;
    document.getElementById('maxContextRounds').value = settings.maxContextRounds;
    document.getElementById('systemPrompt').value = settings.systemPrompt;
    document.getElementById('contextSettings').style.display =
      settings.enableContext ? 'block' : 'none';

    // 图片识别 / 引用 tab 相关
    const imgEl = document.getElementById('enableImageRecognition');
    const imgSettings = document.getElementById('imageSettings');
    const maxImagesEl = document.getElementById('maxImagesPerPage');
    document.getElementById('modelSupportsVision');
    const autoCollectEl = document.getElementById('autoCollectPageImages');
    const fallbackEl = document.getElementById('visionFallbackProvider');
    const refMaxEl = document.getElementById('referencedTabMaxChars');
    const refModeEl = document.getElementById('referencedTabCompressMode');
    if (imgEl) imgEl.checked = !!settings.enableImageRecognition;
    if (maxImagesEl) maxImagesEl.value = settings.maxImagesPerPage;
    if (autoCollectEl) autoCollectEl.checked = !!settings.autoCollectPageImages;
    if (fallbackEl) fallbackEl.value = settings.visionFallbackProvider || '';
    // modelSupportsVision 跟随当前 provider 的 supportsVision，在 switchProvider 中再同步
    if (refMaxEl) refMaxEl.value = settings.tabCompressMaxChars;
    if (refModeEl) refModeEl.value = settings.tabCompressMode || 'hybrid';
    if (imgSettings) imgSettings.style.display = settings.enableImageRecognition ? 'block' : 'none';

    // 显示模式
    const modeEl = document.getElementById('displayMode');
    const sidebarWidthEl = document.getElementById('sidebarWidth');
    const sidebarSettings = document.getElementById('sidebarSettings');
    if (modeEl) modeEl.value = settings.displayMode || 'floating';
    if (sidebarWidthEl) sidebarWidthEl.value = settings.sidebarWidth || 380;
    if (sidebarSettings) {
      sidebarSettings.style.display = (settings.displayMode && settings.displayMode !== 'floating') ? 'block' : 'none';
    }

    // 模型参数
    document.getElementById('maxTokensRange').value = settings.maxTokens;
    document.getElementById('maxTokensInput').value = settings.maxTokens;
    document.getElementById('temperatureRange').value = settings.temperature;
    document.getElementById('temperatureInput').value = settings.temperature;

    // 切换到当前活跃的提供商
    switchProvider(settings.activeProvider);
  }

  // 还原默认设置
  async function resetOptions() {
    if (!confirm('确定要还原所有设置到默认值吗？')) return;

    await chrome.storage.sync.set(DEFAULT_SETTINGS);
    await loadOptions();
    showStatus('已还原默认设置', 'warning');
  }

  // 事件绑定
  document.addEventListener('DOMContentLoaded', async () => {
    await loadOptions();

    // 提供商 Tab 切换
    document.getElementById('providerTabs').addEventListener('click', (e) => {
      const tab = e.target.closest('.provider-tab');
      if (tab) switchProvider(tab.dataset.provider);
    });

    // 模型下拉框变化
    document.getElementById('modelSelect').addEventListener('change', (e) => {
      if (e.target.value) {
        document.getElementById('modelInput').value = e.target.value;
      }
    });

    // 模型输入框变化时同步下拉框
    document.getElementById('modelInput').addEventListener('input', (e) => {
      const modelSelect = document.getElementById('modelSelect');
      const provider = PROVIDERS[currentProvider];
      if (provider.models.includes(e.target.value)) {
        modelSelect.value = e.target.value;
      } else {
        modelSelect.value = '';
      }
    });

    // 滑块同步
    document.getElementById('maxTokensRange').addEventListener('input', (e) => {
      document.getElementById('maxTokensInput').value = e.target.value;
    });
    document.getElementById('maxTokensInput').addEventListener('input', (e) => {
      document.getElementById('maxTokensRange').value = e.target.value;
    });
    document.getElementById('temperatureRange').addEventListener('input', (e) => {
      document.getElementById('temperatureInput').value = e.target.value;
    });
    document.getElementById('temperatureInput').addEventListener('input', (e) => {
      document.getElementById('temperatureRange').value = e.target.value;
    });

    // 保存按钮
    document.getElementById('save').addEventListener('click', saveOptions);
    document.getElementById('reset').addEventListener('click', resetOptions);

    // API Key 可见性切换
    const toggleBtn = document.getElementById('toggleApiKey');
    const apiKeyInput = document.getElementById('apiKey');
    toggleBtn.addEventListener('click', () => {
      const isPassword = apiKeyInput.type === 'password';
      apiKeyInput.type = isPassword ? 'text' : 'password';
      toggleBtn.title = isPassword ? '点击隐藏' : '点击显示';
    });

    // 常规设置即时保存
    const debounceSave = (fn, delay = 1000) => {
      let timer;
      return (...args) => { clearTimeout(timer); timer = setTimeout(() => fn(...args), delay); };
    };

    document.getElementById('autoHideDialog').addEventListener('change', (e) => {
      chrome.storage.sync.set({ autoHideDialog: e.target.checked });
    });

    const enableContext = document.getElementById('enableContext');
    enableContext.addEventListener('change', (e) => {
      chrome.storage.sync.set({ enableContext: e.target.checked });
      document.getElementById('contextSettings').style.display = e.target.checked ? 'block' : 'none';
    });

    document.getElementById('maxContextRounds').addEventListener('change', (e) => {
      const value = Math.max(1, Math.min(10, parseInt(e.target.value) || 3));
      e.target.value = value;
      chrome.storage.sync.set({ maxContextRounds: value });
    });

    document.getElementById('systemPrompt').addEventListener('input', debounceSave((e) => {
      chrome.storage.sync.set({
        systemPrompt: e.target.value || DEFAULT_SETTINGS.systemPrompt
      });
    }));

    // 显示模式 / 侧边栏宽度
    const modeEl = document.getElementById('displayMode');
    if (modeEl) {
      modeEl.addEventListener('change', (e) => {
        const mode = e.target.value || 'floating';
        chrome.storage.sync.set({ displayMode: mode });
        const sub = document.getElementById('sidebarSettings');
        if (sub) sub.style.display = mode === 'floating' ? 'none' : 'block';
      });
    }
    const sidebarWidthEl = document.getElementById('sidebarWidth');
    if (sidebarWidthEl) {
      sidebarWidthEl.addEventListener('change', (e) => {
        const v = Math.max(280, Math.min(720, parseInt(e.target.value) || 380));
        e.target.value = v;
        chrome.storage.sync.set({ sidebarWidth: v });
      });
    }

    // maxTokens 和 temperature 保存
    const saveModelParams = debounceSave(() => {
      chrome.storage.sync.set({
        maxTokens: parseInt(document.getElementById('maxTokensInput').value),
        temperature: parseFloat(document.getElementById('temperatureInput').value)
      });
    }, 500);

    document.getElementById('maxTokensInput').addEventListener('input', saveModelParams);
    document.getElementById('temperatureInput').addEventListener('input', saveModelParams);

    // 图片识别开关
    const enableImg = document.getElementById('enableImageRecognition');
    if (enableImg) {
      enableImg.addEventListener('change', (e) => {
        chrome.storage.sync.set({ enableImageRecognition: e.target.checked });
        const sub = document.getElementById('imageSettings');
        if (sub) sub.style.display = e.target.checked ? 'block' : 'none';
      });
    }
    const maxImagesEl = document.getElementById('maxImagesPerPage');
    if (maxImagesEl) {
      maxImagesEl.addEventListener('change', (e) => {
        const v = Math.max(1, Math.min(8, parseInt(e.target.value) || 3));
        e.target.value = v;
        chrome.storage.sync.set({ maxImagesPerPage: v });
      });
    }
    const autoCollectEl = document.getElementById('autoCollectPageImages');
    if (autoCollectEl) {
      autoCollectEl.addEventListener('change', (e) => {
        chrome.storage.sync.set({ autoCollectPageImages: e.target.checked });
      });
    }
    const fallbackEl = document.getElementById('visionFallbackProvider');
    if (fallbackEl) {
      fallbackEl.addEventListener('change', (e) => {
        chrome.storage.sync.set({ visionFallbackProvider: e.target.value || '' });
      });
    }
    const visionEl = document.getElementById('modelSupportsVision');
    if (visionEl) {
      visionEl.addEventListener('change', async (e) => {
        const { providers = DEFAULT_SETTINGS.providers } = await chrome.storage.sync.get('providers');
        const cur = providers[currentProvider] || {};
        providers[currentProvider] = { ...cur, supportsVision: e.target.checked };
        await chrome.storage.sync.set({ providers });
      });
    }
    const refMaxEl = document.getElementById('referencedTabMaxChars');
    if (refMaxEl) {
      refMaxEl.addEventListener('change', (e) => {
        const v = Math.max(500, Math.min(20000, parseInt(e.target.value) || 4000));
        e.target.value = v;
        chrome.storage.sync.set({ tabCompressMaxChars: v });
      });
    }
    const refModeEl = document.getElementById('referencedTabCompressMode');
    if (refModeEl) {
      refModeEl.addEventListener('change', (e) => {
        chrome.storage.sync.set({ tabCompressMode: e.target.value });
      });
    }
  });

})();
