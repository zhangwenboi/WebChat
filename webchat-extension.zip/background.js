(function () {
  'use strict';

  /**
   * 多模型提供商配置
   *
   * - visionCapable：该提供商的协议本身是否支持图像消息。为 false 的 provider
   *   即使用户在 UI 勾选"当前模型支持视觉"也会被忽略，避免发出对端不接受的 payload。
   * - defaultSupportsVision：visionCapable=true 时，"未被用户手动调整"前的默认值。
   *   用户可在 options 中针对当前选中的模型单独覆盖，存储在 providers[key].supportsVision。
   */
  const PROVIDERS = {
    openai: {
      name: 'OpenAI',
      apiBase: 'https://api.openai.com/v1/chat/completions',
      models: ['gpt-5.5', 'gpt-5.4', 'gpt-4-turbo', 'gpt-3.5-turbo'],
      defaultModel: 'gpt-5.5',
      requiresKey: true,
      authType: 'bearer',
      requestFormat: 'openai',
      streamFormat: 'sse',
      visionCapable: true,
      defaultSupportsVision: true,
      apiKeyPlaceholder: '请输入 OpenAI API Key',
      modelHelp: '推荐：gpt-4o-mini（性价比高）、gpt-4o（最强）'
    },
    deepseek: {
      name: 'DeepSeek',
      apiBase: 'https://api.deepseek.com/chat/completions',
      models: ['deepseek-v4-pro', 'deepseek-v4-flash', 'deepseek-chat', 'deepseek-reasoner'],
      defaultModel: 'deepseek-v4-pro',
      requiresKey: true,
      authType: 'bearer',
      requestFormat: 'openai',
      streamFormat: 'sse',
      visionCapable: false,
      defaultSupportsVision: false,
      apiKeyPlaceholder: '请输入 DeepSeek API Key',
      modelHelp: '推荐：deepseek-chat（通用）、deepseek-reasoner（推理）'
    },
    claude: {
      name: 'Claude',
      apiBase: 'https://api.anthropic.com/v1/messages',
      models: ['claude-sonnet-4-20250514', 'claude-haiku-4-20250414', 'claude-opus-4-20250514'],
      defaultModel: 'claude-sonnet-4-20250514',
      requiresKey: true,
      authType: 'x-api-key',
      requestFormat: 'anthropic',
      streamFormat: 'sse',
      extraHeaders: { 'anthropic-version': '2023-06-01' },
      visionCapable: true,
      defaultSupportsVision: true,
      apiKeyPlaceholder: '请输入 Anthropic API Key',
      modelHelp: '推荐：claude-sonnet-4（均衡）、claude-opus-4（最强）'
    },
    gemini: {
      name: 'Gemini',
      apiBase: 'https://generativelanguage.googleapis.com/v1beta/models/{model}:streamGenerateContent',
      models: ['gemini-2.5-flash', 'gemini-2.5-pro', 'gemini-2.0-flash'],
      defaultModel: 'gemini-2.5-flash',
      requiresKey: true,
      authType: 'query',
      requestFormat: 'gemini',
      streamFormat: 'json-stream',
      visionCapable: true,
      defaultSupportsVision: true,
      apiKeyPlaceholder: '请输入 Google AI API Key',
      modelHelp: '推荐：gemini-2.5-flash（快速）、gemini-2.5-pro（最强）'
    },
    ollama: {
      name: '本地模型 (Ollama)',
      apiBase: 'http://127.0.0.1:11434/api/chat',
      models: [],
      defaultModel: 'qwen2.5',
      requiresKey: false,
      authType: 'none',
      requestFormat: 'ollama',
      streamFormat: 'ndjson',
      fetchModels: true,
      visionCapable: true, // ollama 视模型而定，由用户开关决定
      defaultSupportsVision: false,
      apiKeyPlaceholder: '本地模型无需 API 密钥',
      modelHelp: '使用前请确保已安装模型：ollama pull qwen2.5'
    },
    custom: {
      name: '自定义 API',
      apiBase: '',
      models: [],
      defaultModel: '',
      requiresKey: true,
      authType: 'bearer',
      requestFormat: 'openai',
      streamFormat: 'sse',
      visionCapable: true, // 自定义 OpenAI 兼容端点，由用户开关决定
      defaultSupportsVision: false,
      apiKeyPlaceholder: '请输入 API 密钥',
      modelHelp: '支持 OpenAI 兼容的 API 接口'
    }
  };

  const DEFAULT_SETTINGS = {
    activeProvider: 'openai',
    maxTokens: 2048,
    temperature: 0.7,
    enableContext: true,
    maxContextRounds: 3,
    systemPrompt: '你是一个帮助理解网页内容的AI助手。请使用Markdown格式回复。',
    autoHideDialog: true,
    // 显示模式：'floating'（悬浮，可拖动） | 'sidebar-left' | 'sidebar-right'
    displayMode: 'floating',
    // 侧边栏宽度（px）
    sidebarWidth: 380,
    // 图片识别（多模态）
    enableImageRecognition: false,
    maxImagesPerPage: 3,
    // 视觉副模型 fallback：主模型不支持视觉时把图片转文字描述再喂给主模型
    // 空字符串 = 自动从已配 key 的 visionCapable provider 中挑选
    visionFallbackProvider: '',
    // 旧行为兜底：未标记任何图片时是否自动抓取页面图片（默认关，鼓励用户显式标记）
    autoCollectPageImages: false,
    // 多 tab 引用压缩
    enableTabCompression: true,
    tabCompressMaxChars: 3000,
    tabCompressMode: 'hybrid', // 'truncate' | 'ai' | 'hybrid'
    providers: Object.fromEntries(
      Object.entries(PROVIDERS).map(([key, config]) => [
        key,
        {
          apiKey: '',
          apiBase: config.apiBase,
          model: config.defaultModel,
          supportsVision: !!config.defaultSupportsVision
        }
      ])
    )
  };

  /**
   * API 适配器 — 统一不同提供商的请求和响应格式
   */
  class ApiAdapter {
    constructor(providerKey, config) {
      this.providerKey = providerKey;
      this.provider = PROVIDERS[providerKey];
      this.config = config; // { apiKey, apiBase, model }
    }

    /**
     * 构建请求 URL
     *
     * 对 OpenAI 兼容协议（openai / deepseek / custom）做容错：
     * 用户只填 https://api.deepseek.com 或 https://api.deepseek.com/v1
     * 会被自动补全为 https://api.deepseek.com/v1/chat/completions。
     */
    buildUrl() {
      let url = this.config.apiBase || this.provider.apiBase;

      if (this.provider.requestFormat === 'gemini') {
        url = url.replace('{model}', this.config.model);
        url += `?key=${this.config.apiKey}&alt=sse`;
        return url;
      }

      if (this.provider.requestFormat === 'openai') {
        url = normalizeOpenAIBase(url);
      }

      return url;
    }

    /**
     * 构建请求头
     */
    buildHeaders() {
      const headers = { 'Content-Type': 'application/json' };

      if (this.provider.authType === 'bearer') {
        headers['Authorization'] = `Bearer ${this.config.apiKey}`;
      } else if (this.provider.authType === 'x-api-key') {
        headers['x-api-key'] = this.config.apiKey;
      }
      // authType === 'query' 或 'none' 不需要 header 认证

      if (this.provider.extraHeaders) {
        Object.assign(headers, this.provider.extraHeaders);
      }

      return headers;
    }

    /**
     * 构建请求体
     *
     * messages[i].content 可能是字符串，也可能是 multimodal 数组：
     *   [{type:'text', text:'...'}, {type:'image', dataUrl:'data:image/jpeg;base64,...'}]
     * 由各 provider 分支转换成对应格式。
     */
    buildRequestBody(messages, options = {}) {
      const { maxTokens = 2048, temperature = 0.7 } = options;
      const format = this.provider.requestFormat;

      if (format === 'openai') {
        return {
          model: this.config.model,
          messages: messages.map(m => ({
            role: m.role,
            content: toOpenAIContent(m.content)
          })),
          max_tokens: maxTokens,
          temperature,
          stream: true
        };
      }

      if (format === 'anthropic') {
        // Claude 要求 system 单独传，不在 messages 数组中
        const systemMsg = messages.find(m => m.role === 'system');
        const chatMessages = messages.filter(m => m.role !== 'system');

        return {
          model: this.config.model,
          system: contentToText(systemMsg?.content) || '',
          messages: chatMessages.map(m => ({
            role: m.role,
            content: toAnthropicContent(m.content)
          })),
          max_tokens: maxTokens,
          temperature,
          stream: true
        };
      }

      if (format === 'gemini') {
        // Gemini 使用完全不同的格式
        const systemMsg = messages.find(m => m.role === 'system');
        const chatMessages = messages.filter(m => m.role !== 'system');

        const contents = chatMessages.map(msg => ({
          role: msg.role === 'assistant' ? 'model' : 'user',
          parts: toGeminiParts(msg.content)
        }));

        const body = {
          contents,
          generationConfig: {
            maxOutputTokens: maxTokens,
            temperature
          }
        };

        if (systemMsg) {
          body.systemInstruction = { parts: [{ text: contentToText(systemMsg.content) }] };
        }

        return body;
      }

      if (format === 'ollama') {
        // Ollama 不支持视觉（除少数模型），统一降级为纯文本
        return {
          model: this.config.model,
          messages: messages.map(m => ({ role: m.role, content: contentToText(m.content) })),
          stream: true,
          options: {
            temperature,
            num_predict: maxTokens
          }
        };
      }

      // 默认使用 openai 格式
      return {
        model: this.config.model,
        messages: messages.map(m => ({ role: m.role, content: toOpenAIContent(m.content) })),
        max_tokens: maxTokens,
        temperature,
        stream: true
      };
    }

    /**
     * 解析流式响应的一行数据，返回文本内容或 null
     */
    parseStreamLine(line) {
      const format = this.provider.streamFormat;

      if (format === 'sse') {
        return this._parseSSELine(line);
      }

      if (format === 'ndjson') {
        return this._parseNDJSONLine(line);
      }

      if (format === 'json-stream') {
        return this._parseSSELine(line);
      }

      return null;
    }

    _parseSSELine(line) {
      if (!line.startsWith('data: ')) return null;

      const data = line.slice(6).trim();
      if (data === '[DONE]') return { done: true };

      try {
        const parsed = JSON.parse(data);
        return { done: false, content: this._extractContent(parsed) };
      } catch {
        return null;
      }
    }

    _parseNDJSONLine(line) {
      if (!line.trim()) return null;

      try {
        const parsed = JSON.parse(line);

        if (parsed.done) return { done: true };

        return { done: false, content: this._extractContent(parsed) };
      } catch {
        return null;
      }
    }

    /**
     * 从解析后的 JSON 中提取文本内容
     */
    _extractContent(parsed) {
      const format = this.provider.requestFormat;

      if (format === 'openai') {
        return parsed.choices?.[0]?.delta?.content || '';
      }

      if (format === 'anthropic') {
        // Claude SSE 有多种事件类型
        if (parsed.type === 'content_block_delta') {
          return parsed.delta?.text || '';
        }
        return '';
      }

      if (format === 'gemini') {
        return parsed.candidates?.[0]?.content?.parts?.[0]?.text || '';
      }

      if (format === 'ollama') {
        return parsed.message?.content || '';
      }

      return '';
    }

    /**
     * 判断流是否结束
     */
    isStreamEnd(parsed) {
      const format = this.provider.requestFormat;

      if (format === 'anthropic') {
        return parsed.type === 'message_stop';
      }

      if (format === 'ollama') {
        return parsed.done === true;
      }

      return false;
    }

    /**
     * 非流式一次性调用：用于视觉副模型把图转文字这种"问一下要结果"的场景。
     * 复用 buildHeaders/buildRequestBody，但强制 stream:false，并自行解析单次响应。
     * 返回 { text } 或抛出 Error。
     */
    async callOnce(messages, options = {}, { signal } = {}) {
      const headers = this.buildHeaders();
      const body = this.buildRequestBody(messages, options);

      // 关掉 stream
      if ('stream' in body) body.stream = false;

      // URL 调整：Gemini 流式 URL 形如 .../models/{m}:streamGenerateContent?...&alt=sse
      let url = this.buildUrl();
      if (this.provider.requestFormat === 'gemini') {
        url = url.replace(':streamGenerateContent', ':generateContent').replace('&alt=sse', '');
      }

      const response = await fetch(url, {
        method: 'POST',
        headers,
        body: JSON.stringify(body),
        signal
      });

      if (!response.ok) {
        const errText = await response.text().catch(() => '');
        throw new Error(`HTTP ${response.status}: ${errText.slice(0, 300)}`);
      }

      const json = await response.json();
      const text = extractFullText(this.provider.requestFormat, json);
      if (!text) throw new Error('副模型返回空内容');
      return { text };
    }
  }

  function extractFullText(format, json) {
    if (format === 'openai') {
      return json?.choices?.[0]?.message?.content || '';
    }
    if (format === 'anthropic') {
      const parts = json?.content || [];
      return parts.map(p => (p.type === 'text' ? p.text : '')).join('').trim();
    }
    if (format === 'gemini') {
      const parts = json?.candidates?.[0]?.content?.parts || [];
      return parts.map(p => p.text || '').join('').trim();
    }
    if (format === 'ollama') {
      return json?.message?.content || '';
    }
    return '';
  }

  // ====================================================================
  // multimodal content 转换辅助
  // ====================================================================
  // 上层传入的 message.content 统一格式：
  //   string                                    // 纯文本
  //   | Array<{type:'text', text} | {type:'image', dataUrl}>   // 多模态
  //
  // 各 provider 的 wire format 不同，下面的 helper 把统一格式转成对应 wire 形式。

  /**
   * 把用户填写的 OpenAI 兼容 base URL 归一化到带 /chat/completions 的完整地址。
   * 兼容这些写法：
   *   https://api.deepseek.com                    → https://api.deepseek.com/v1/chat/completions
   *   https://api.deepseek.com/                   → https://api.deepseek.com/v1/chat/completions
   *   https://api.deepseek.com/v1                 → https://api.deepseek.com/v1/chat/completions
   *   https://api.deepseek.com/v1/                → https://api.deepseek.com/v1/chat/completions
   *   https://api.deepseek.com/chat/completions   → 原样保留
   *   https://api.openai.com/v1/chat/completions  → 原样保留
   */
  function normalizeOpenAIBase(raw) {
    if (!raw) return raw;
    let url = raw.trim().replace(/\/+$/, '');
    // 已经是完整 endpoint
    if (/\/chat\/completions(\?|$)/.test(url)) return url;
    // 已经带 /v1（或其它版本号），直接拼 /chat/completions
    if (/\/v\d+$/.test(url)) return url + '/chat/completions';
    // 否则按 OpenAI 兼容默认补 /v1/chat/completions
    return url + '/v1/chat/completions';
  }

  function isMultimodalArray(content) {
    return Array.isArray(content);
  }

  function contentToText(content) {
    if (!content) return '';
    if (typeof content === 'string') return content;
    if (!isMultimodalArray(content)) return String(content);
    return content
      .map(part => part.type === 'text' ? part.text : '')
      .filter(Boolean)
      .join('\n');
  }

  function toOpenAIContent(content) {
    if (!isMultimodalArray(content)) return content || '';
    return content.map(part => {
      if (part.type === 'text') return { type: 'text', text: part.text };
      if (part.type === 'image') return { type: 'image_url', image_url: { url: part.dataUrl } };
      return null;
    }).filter(Boolean);
  }

  function toAnthropicContent(content) {
    if (!isMultimodalArray(content)) return content || '';
    return content.map(part => {
      if (part.type === 'text') return { type: 'text', text: part.text };
      if (part.type === 'image') {
        const m = /^data:(image\/[a-zA-Z]+);base64,(.+)$/.exec(part.dataUrl || '');
        if (!m) return null;
        return {
          type: 'image',
          source: { type: 'base64', media_type: m[1], data: m[2] }
        };
      }
      return null;
    }).filter(Boolean);
  }

  function toGeminiParts(content) {
    if (!isMultimodalArray(content)) return [{ text: content || '' }];
    return content.map(part => {
      if (part.type === 'text') return { text: part.text };
      if (part.type === 'image') {
        const m = /^data:(image\/[a-zA-Z]+);base64,(.+)$/.exec(part.dataUrl || '');
        if (!m) return null;
        return { inline_data: { mime_type: m[1], data: m[2] } };
      }
      return null;
    }).filter(Boolean);
  }

  /**
   * 存储迁移 — 将旧格式配置迁移到新的多提供商格式
   */
  async function migrateSettings() {
    const oldSettings = await chrome.storage.sync.get(null);

    // 如果已经是新格式，跳过迁移
    if (oldSettings.activeProvider && oldSettings.providers) {
      return oldSettings;
    }

    // 检测旧格式标志
    if (!oldSettings.apiType) {
      // 全新安装，使用默认设置
      await chrome.storage.sync.set(DEFAULT_SETTINGS);
      return DEFAULT_SETTINGS;
    }

    // 执行迁移
    const newSettings = { ...DEFAULT_SETTINGS };

    // 映射旧的 apiType 到新的 activeProvider
    if (oldSettings.apiType === 'custom') {
      newSettings.activeProvider = 'openai';
    } else if (oldSettings.apiType === 'ollama') {
      newSettings.activeProvider = 'ollama';
    }

    // 迁移通用设置
    if (oldSettings.maxTokens) newSettings.maxTokens = oldSettings.maxTokens;
    if (oldSettings.temperature !== undefined) newSettings.temperature = oldSettings.temperature;
    if (oldSettings.enableContext !== undefined) newSettings.enableContext = oldSettings.enableContext;
    if (oldSettings.maxContextRounds) newSettings.maxContextRounds = oldSettings.maxContextRounds;
    if (oldSettings.systemPrompt) newSettings.systemPrompt = oldSettings.systemPrompt;
    if (oldSettings.autoHideDialog !== undefined) newSettings.autoHideDialog = oldSettings.autoHideDialog;

    // 迁移 custom API 配置到 openai provider
    if (oldSettings.custom_apiKey || oldSettings.custom_apiBase || oldSettings.custom_model) {
      newSettings.providers.openai = {
        apiKey: oldSettings.custom_apiKey || '',
        apiBase: oldSettings.custom_apiBase || PROVIDERS.openai.apiBase,
        model: oldSettings.custom_model || PROVIDERS.openai.defaultModel
      };
      // 同时保留到 custom provider
      newSettings.providers.custom = {
        apiKey: oldSettings.custom_apiKey || '',
        apiBase: oldSettings.custom_apiBase || '',
        model: oldSettings.custom_model || ''
      };
    }

    // 迁移 ollama 配置
    if (oldSettings.ollama_apiBase || oldSettings.ollama_model) {
      newSettings.providers.ollama = {
        apiKey: '',
        apiBase: oldSettings.ollama_apiBase || PROVIDERS.ollama.apiBase,
        model: oldSettings.ollama_model || PROVIDERS.ollama.defaultModel
      };
    }

    // 保留 UI 状态
    if (oldSettings.showFloatingBall !== undefined) newSettings.showFloatingBall = oldSettings.showFloatingBall;
    if (oldSettings.dialogPosition) newSettings.dialogPosition = oldSettings.dialogPosition;
    if (oldSettings.dialogSize) newSettings.dialogSize = oldSettings.dialogSize;
    if (oldSettings.ballPosition) newSettings.ballPosition = oldSettings.ballPosition;
    if (oldSettings.totalTokens) newSettings.totalTokens = oldSettings.totalTokens;

    // 清除旧格式的 key，写入新格式
    const keysToRemove = [
      'apiType', 'custom_apiKey', 'custom_apiBase', 'custom_model',
      'ollama_apiKey', 'ollama_apiBase', 'ollama_model', 'activeConfig'
    ];
    await chrome.storage.sync.remove(keysToRemove);
    await chrome.storage.sync.set(newSettings);

    return newSettings;
  }

  /**
   * 获取当前活跃提供商的配置
   */
  async function getActiveProviderConfig() {
    const settings = await chrome.storage.sync.get(['activeProvider', 'providers']);
    const providerKey = settings.activeProvider || DEFAULT_SETTINGS.activeProvider;
    const providers = settings.providers || DEFAULT_SETTINGS.providers;
    const config = providers[providerKey] || {};

    return {
      providerKey,
      apiKey: config.apiKey || '',
      apiBase: config.apiBase || PROVIDERS[providerKey]?.apiBase || '',
      model: config.model || PROVIDERS[providerKey]?.defaultModel || ''
    };
  }

  /**
   * 估算文本的 token 数
   * 中文每字约 1 token，英文每 4 字符约 1 token，混合文本分别计算后求和
   * 比单纯 length/4 更接近真实 tokenizer 的结果
   */
  function estimateTokens(text) {
    if (!text) return 0;
    let cjk = 0;
    let other = 0;
    for (let i = 0; i < text.length; i++) {
      const code = text.charCodeAt(i);
      // CJK Unified + 扩展 A + 兼容象形 + 平假名 + 片假名 + Hangul
      if (
        (code >= 0x3400 && code <= 0x9fff) ||
        (code >= 0xf900 && code <= 0xfaff) ||
        (code >= 0x3040 && code <= 0x309f) ||
        (code >= 0x30a0 && code <= 0x30ff) ||
        (code >= 0xac00 && code <= 0xd7af)
      ) {
        cjk++;
      } else {
        other++;
      }
    }
    return cjk + Math.ceil(other / 4);
  }

  /**
   * 将 HTTP 状态码 + 提供商原始错误转成对用户友好的错误
   */
  function friendlyError({ status, providerMessage = '', providerKey = '' }) {
    const tail = providerMessage ? `（${providerMessage}）` : '';

    if (status === 401 || status === 403) {
      return new Error(`认证失败：API 密钥无效或权限不足，请前往设置页检查 ${providerKey || ''} 的密钥${tail}`);
    }
    if (status === 404) {
      return new Error(`接口未找到：请求 URL 或模型名可能填错${tail}`);
    }
    if (status === 429) {
      return new Error(`请求过于频繁或额度不足，请稍后重试${tail}`);
    }
    if (status >= 500 && status < 600) {
      return new Error(`服务端错误（${status}），请稍后重试${tail}`);
    }
    if (status === 400) {
      return new Error(`请求参数错误${tail}`);
    }
    return new Error(`API 请求失败（${status}）${tail}`);
  }

  const POPUP_WAIT_SELECTOR = [
    '[role="dialog"]',
    '[role="listbox"]',
    '[role="menu"]',
    '.ant-picker-dropdown',
    '.ant-select-dropdown',
    '.el-picker-panel',
    '.el-select-dropdown',
    '.el-popper',
    '.MuiPopover-root',
    '.MuiMenu-root'
  ].join(', ');

  const FORMAT_HINTS = [
    ['YYYY-MM-DD ~ YYYY-MM-DD', /\b(\d{4})[/-](\d{1,2})[/-](\d{1,2})\s*(?:~|-|至|到)\s*(\d{4})[/-](\d{1,2})[/-](\d{1,2})\b/g],
    ['YYYY-MM-DD', /\b(\d{4})[/-](\d{1,2})[/-](\d{1,2})\b/g]
  ];

  function buildGenerateScriptPrompts({ prompt, pageInfo }) {
    const systemPrompt = [
      '你是 WebChat 网页自动化脚本生成助手，只输出一个 JSON 对象，不要输出 Markdown。',
      '脚本格式必须是 { "meta": { "name": "..." }, "variables": {}, "steps": [{ "type": "...", "description": "...", "params": {}, "options": {} }] }。',
      '支持动作：click, input, select, checkbox, wait, waitTime, scroll, hover, keypress, hotkey, extract, assert, aiLocate。',
      '必须优先使用元素提供的 targets；如果没有 targets，再使用 selector 和 selectorFallbacks。',
      '所有用户提到或页面中明显相关的可见表单项都要全部填写，不要遗漏任何必填、可编辑、选择类字段。',
      '输入值必须匹配元素的 type、pattern、placeholder、formatHint、min/max 等格式要求。日期范围优先使用 YYYY-MM-DD ~ YYYY-MM-DD。',
      '点击会触发弹窗、下拉、日期选择器、时间范围选择器的元素后，必须添加 wait 步骤等待弹层可见，再点击或输入弹层中的目标元素。',
      '对于 select/combobox/date-range 这类控件，如果页面结构中有候选项、弹窗 selector 或格式提示，要生成打开控件、等待弹层、选择/输入值、确认的完整步骤。',
      '每个步骤都要有清晰中文 description；关键操作 options.timeout 使用 8000 到 12000 毫秒。',
      '不要臆造页面上不存在的 selector；无法确定值时使用变量占位符，并在 variables 中提供空字符串默认值。'
    ].join('\n');

    const userPrompt = [
      `用户需求：${prompt}`,
      '',
      '当前页面信息和交互元素如下。元素中的 label、formatHint、required、options、targets、popupHints 都是生成脚本的重要依据：',
      JSON.stringify(pageInfo || {}, null, 2)
    ].join('\n');

    return { systemPrompt, userPrompt };
  }

  function normalizeGeneratedScript(rawScript, pageInfo = {}) {
    const script = rawScript && typeof rawScript === 'object' ? rawScript : {};
    const meta = {
      ...(script.meta && typeof script.meta === 'object' ? script.meta : {})
    };
    const variables = {
      ...(script.variables && typeof script.variables === 'object' ? script.variables : {})
    };
    const elements = Array.isArray(pageInfo.elements) ? pageInfo.elements : [];
    const steps = Array.isArray(script.steps) ? script.steps.map((step, index) => normalizeStep(step, index, elements)) : [];

    addMissingFieldSteps(steps, variables, elements);
    addPopupWaitSteps(steps, elements);
    normalizeInputValues(steps, elements);

    return {
      ...script,
      meta,
      variables,
      steps: steps.map((step, index) => ({
        id: step.id || `step_${Date.now()}_${index + 1}`,
        type: step.type,
        description: step.description || defaultDescription(step),
        params: step.params || {},
        options: step.options || {}
      }))
    };
  }

  function normalizeStep(step, index, elements) {
    const normalized = step && typeof step === 'object' ? { ...step } : {};
    normalized.type = normalizeActionType(normalized.type);
    normalized.description = normalized.description || '';
    normalized.params = normalized.params && typeof normalized.params === 'object' ? { ...normalized.params } : {};
    normalized.options = normalized.options && typeof normalized.options === 'object' ? { ...normalized.options } : {};

    const element = findElementForStep(normalized, elements);
    if (element) mergeLocatorParams(normalized.params, element);
    if (!normalized.id) normalized.id = `step_${index + 1}`;
    if (!normalized.options.timeout && needsTimeout(normalized.type)) normalized.options.timeout = 8000;
    return normalized;
  }

  function normalizeActionType(type) {
    const text = String(type || '').trim();
    const aliases = {
      fill: 'input',
      typeText: 'input',
      setValue: 'input',
      choose: 'select',
      check: 'checkbox'
    };
    return aliases[text] || text || 'click';
  }

  function needsTimeout(type) {
    return ['click', 'input', 'select', 'checkbox', 'wait', 'hover', 'assert'].includes(type);
  }

  function mergeLocatorParams(params, element) {
    if (!params.selector && element.selector) params.selector = element.selector;
    if (!params.selectorFallbacks && Array.isArray(element.selectorFallbacks)) params.selectorFallbacks = element.selectorFallbacks;
    if (!params.targets && Array.isArray(element.targets)) params.targets = element.targets;
  }

  function findElementForStep(step, elements) {
    const selector = step.params?.selector;
    if (selector) {
      const bySelector = elements.find(el => el.selector === selector || (Array.isArray(el.selectorFallbacks) && el.selectorFallbacks.includes(selector)));
      if (bySelector) return bySelector;
    }

    const text = `${step.description || ''} ${step.params?.label || ''}`.toLowerCase();
    return elements.find(el => {
      const label = String(el.label || el.text || el.placeholder || el.name || '').toLowerCase();
      return label && text.includes(label);
    }) || null;
  }

  function addMissingFieldSteps(steps, variables, elements) {
    const handled = new Set(steps.map(step => step.params?.selector).filter(Boolean));
    for (const element of elements) {
      if (!isRelevantFormElement(element)) continue;
      if (!element.selector || handled.has(element.selector)) continue;

      const variableName = variableNameForElement(element);
      if (!(variableName in variables)) variables[variableName] = element.exampleValue || '';
      const type = element.tag === 'select' || element.role === 'combobox' ? 'select' : 'input';
      const step = {
        type,
        description: `填写${element.label || element.placeholder || element.name || element.selector}`,
        params: {
          selector: element.selector,
          value: `{{${variableName}}}`,
          clearBefore: type === 'input'
        },
        options: { timeout: 8000 }
      };
      mergeLocatorParams(step.params, element);
      steps.push(step);
      handled.add(element.selector);
    }
  }

  function isRelevantFormElement(element) {
    if (!element || !element.selector) return false;
    if (element.disabled || element.readOnly || element.type === 'hidden') return false;
    if (['input', 'textarea', 'select'].includes(element.tag)) return true;
    if (['textbox', 'combobox', 'spinbutton', 'searchbox'].includes(element.role) || element.contentEditable === true) return true;
    if (element.label || element.placeholder || element.formatHint || element.name) return true;
    return false;
  }

  function variableNameForElement(element) {
    const source = element.name || element.id || element.label || element.placeholder || 'field';
    const ascii = String(source)
      .trim()
      .replace(/^[^A-Za-z_]+/, '')
      .replace(/[^A-Za-z0-9_]+/g, '_')
      .replace(/^_+|_+$/g, '');
    return ascii || `field_${Math.abs(hashCode(String(source)))}`;
  }

  function hashCode(text) {
    let hash = 0;
    for (let i = 0; i < text.length; i++) hash = ((hash << 5) - hash) + text.charCodeAt(i);
    return hash | 0;
  }

  function addPopupWaitSteps(steps, elements) {
    for (let i = 0; i < steps.length; i++) {
      const step = steps[i];
      if (step.type !== 'click') continue;
      if (!looksLikePopupTrigger(step, elements)) continue;
      const next = steps[i + 1];
      if (next && next.type === 'wait') continue;
      steps.splice(i + 1, 0, {
        type: 'wait',
        description: '等待弹窗或下拉面板出现',
        params: { selector: popupSelectorForStep(step, elements), state: 'visible' },
        options: { timeout: 10000 }
      });
      i++;
    }
  }

  function looksLikePopupTrigger(step, elements) {
    const element = findElementForStep(step, elements);
    if (element?.opensPopup || element?.ariaHasPopup || element?.popupSelector) return true;
    const text = `${step.description || ''} ${element?.label || ''} ${element?.placeholder || ''}`.toLowerCase();
    return /弹窗|下拉|日期|时间|范围|选择器|picker|dropdown|select|range/.test(text);
  }

  function popupSelectorForStep(step, elements) {
    const element = findElementForStep(step, elements);
    return step.params.popupSelector || element?.popupSelector || POPUP_WAIT_SELECTOR;
  }

  function normalizeInputValues(steps, elements) {
    for (const step of steps) {
      if (step.type !== 'input' || step.params?.value == null) continue;
      const element = findElementForStep(step, elements);
      const hint = element?.formatHint || step.params.formatHint || '';
      if (!hint) continue;
      step.params.value = normalizeValueForFormat(step.params.value, hint);
    }
  }

  function normalizeValueForFormat(value, hint) {
    let out = String(value);
    if (/YYYY-MM-DD\s*~\s*YYYY-MM-DD/i.test(hint)) {
      out = out.replace(FORMAT_HINTS[0][1], (_, y1, m1, d1, y2, m2, d2) => {
        return `${y1}-${pad2(m1)}-${pad2(d1)} ~ ${y2}-${pad2(m2)}-${pad2(d2)}`;
      });
    } else if (/YYYY-MM-DD/i.test(hint)) {
      out = out.replace(FORMAT_HINTS[1][1], (_, y, m, d) => `${y}-${pad2(m)}-${pad2(d)}`);
    } else if (/number|数字|金额|价格|预算/i.test(hint)) {
      out = out.replace(/,/g, '');
    }
    return out;
  }

  function pad2(value) {
    return String(value).padStart(2, '0');
  }

  function defaultDescription(step) {
    const selector = step.params?.selector || '';
    if (step.type === 'input') return `输入 ${selector}`;
    if (step.type === 'click') return `点击 ${selector}`;
    if (step.type === 'wait') return `等待 ${selector}`;
    return step.type;
  }

  /**
   * 对话管理模块 — 基于 chrome.storage.local 持久化
   *
   * 数据模型 (chrome.storage.local key: "webchat_conversations"):
   * {
   *   "tab_<tabId>": {
   *     activeId: "uuid",
   *     conversations: {
   *       "uuid": {
   *         id, title, createdAt, updatedAt,
   *         messages: [{ content, isUser, markdownContent? }]
   *       }
   *     }
   *   }
   * }
   */

  const STORAGE_KEY = 'webchat_conversations';

  // —— 内存缓存，避免每次操作都读 storage ——
  let cache = null;       // 完整的 storage dump
  let cacheLoaded = false;

  async function loadCache() {
    if (cacheLoaded) return cache;
    const result = await chrome.storage.local.get(STORAGE_KEY);
    cache = result[STORAGE_KEY] || {};
    cacheLoaded = true;
    return cache;
  }

  async function saveCache() {
    await chrome.storage.local.set({ [STORAGE_KEY]: cache });
  }

  function tabKey(tabId) {
    return `tab_${tabId}`;
  }

  function ensureTab(tabId) {
    const key = tabKey(tabId);
    if (!cache[key]) {
      cache[key] = { activeId: null, conversations: {} };
    }
    return cache[key];
  }

  function generateId() {
    // 简单的 UUID v4
    return 'conv_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 8);
  }

  function makeTitle(content) {
    if (!content) return '新对话';
    const cleaned = content.replace(/\s+/g, ' ').trim();
    return cleaned.length > 30 ? cleaned.slice(0, 30) + '…' : cleaned;
  }

  // ==================== 对外 API ====================

  /** 列出某个 tab 下的所有对话（按更新时间倒序） */
  async function listConversations(tabId) {
    await loadCache();
    const tab = ensureTab(tabId);
    const list = Object.values(tab.conversations);
    list.sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
    return list.map(c => ({
      id: c.id,
      title: c.title,
      createdAt: c.createdAt,
      updatedAt: c.updatedAt,
      messageCount: (c.messages || []).length,
      isActive: c.id === tab.activeId
    }));
  }

  /** 创建新对话并设为活跃 */
  async function createConversation(tabId) {
    await loadCache();
    const tab = ensureTab(tabId);
    const id = generateId();
    const now = Date.now();
    const conversation = {
      id,
      title: '新对话',
      createdAt: now,
      updatedAt: now,
      messages: []
    };
    tab.conversations[id] = conversation;
    tab.activeId = id;
    await saveCache();
    return { id, title: conversation.title, createdAt: now, updatedAt: now, messageCount: 0 };
  }

  /** 删除对话；若删除的是活跃对话则自动切到最新对话 */
  async function deleteConversation(tabId, convId) {
    await loadCache();
    const tab = ensureTab(tabId);
    if (!tab.conversations[convId]) return false;
    delete tab.conversations[convId];
    if (tab.activeId === convId) {
      const remaining = Object.values(tab.conversations);
      remaining.sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
      tab.activeId = remaining.length > 0 ? remaining[0].id : null;
    }
    await saveCache();
    return true;
  }

  /** 切换活跃对话 */
  async function switchConversation(tabId, convId) {
    await loadCache();
    const tab = ensureTab(tabId);
    if (!tab.conversations[convId]) return false;
    tab.activeId = convId;
    await saveCache();
    return true;
  }

  /** 添加用户消息到活跃对话（同时自动更新标题） */
  async function addUserMessage(tabId, content) {
    await loadCache();
    const tab = ensureTab(tabId);
    if (!tab.activeId || !tab.conversations[tab.activeId]) return;
    const conv = tab.conversations[tab.activeId];
    // 去重
    const last = conv.messages[conv.messages.length - 1];
    if (!last || !last.isUser || last.content !== content) {
      conv.messages.push({ content, isUser: true });
    }
    // 自动标题：取第一条用户消息
    if (conv.title === '新对话' || !conv.title) {
      const firstUser = conv.messages.find(m => m.isUser);
      if (firstUser) conv.title = makeTitle(firstUser.content);
    }
    conv.updatedAt = Date.now();
    await saveCache();
  }

  /** 添加用户消息到指定对话（不依赖活跃对话） */
  async function addUserMessageToConv(tabId, convId, content) {
    await loadCache();
    const tab = ensureTab(tabId);
    if (!convId || !tab.conversations[convId]) return;
    const conv = tab.conversations[convId];
    const last = conv.messages[conv.messages.length - 1];
    if (!last || !last.isUser || last.content !== content) {
      conv.messages.push({ content, isUser: true });
    }
    if (conv.title === '新对话' || !conv.title) {
      const firstUser = conv.messages.find(m => m.isUser);
      if (firstUser) conv.title = makeTitle(firstUser.content);
    }
    conv.updatedAt = Date.now();
    await saveCache();
  }

  /** 添加助手消息到指定对话（不依赖活跃对话） */
  async function addAssistantMessageToConv(tabId, convId, content) {
    if (!content) return;
    await loadCache();
    const tab = ensureTab(tabId);
    if (!convId || !tab.conversations[convId]) return;
    const conv = tab.conversations[convId];
    conv.messages.push({ isUser: false, content, markdownContent: content });
    conv.updatedAt = Date.now();
    await saveCache();
  }

  /** 获取指定对话的消息 */
  async function getMessagesByConv(tabId, convId) {
    await loadCache();
    const tab = ensureTab(tabId);
    if (!convId || !tab.conversations[convId]) return [];
    return [...tab.conversations[convId].messages];
  }

  /** 添加助手消息到活跃对话 */
  async function addAssistantMessage(tabId, content) {
    if (!content) return;
    await loadCache();
    const tab = ensureTab(tabId);
    if (!tab.activeId || !tab.conversations[tab.activeId]) return;
    const conv = tab.conversations[tab.activeId];
    conv.messages.push({ isUser: false, content, markdownContent: content });
    conv.updatedAt = Date.now();
    await saveCache();
  }

  /** 替换活跃对话的全部消息 */
  async function setMessages(tabId, messages) {
    await loadCache();
    const tab = ensureTab(tabId);
    if (!tab.activeId || !tab.conversations[tab.activeId]) return;
    tab.conversations[tab.activeId].messages = Array.isArray(messages) ? [...messages] : [];
    tab.conversations[tab.activeId].updatedAt = Date.now();
    await saveCache();
  }

  /** 清空活跃对话的消息（不删除对话本身） */
  async function clearActiveConversation(tabId) {
    await loadCache();
    const tab = ensureTab(tabId);
    if (!tab.activeId || !tab.conversations[tab.activeId]) return;
    tab.conversations[tab.activeId].messages = [];
    tab.conversations[tab.activeId].title = '新对话';
    tab.conversations[tab.activeId].updatedAt = Date.now();
    await saveCache();
  }

  /**
   * 为保持向后兼容：chat-history.js 委托到这里。
   * 返回与旧 getHistorySnapshot 相同格式的数据。
   */
  async function getHistorySnapshot$1(tabId) {
    await loadCache();
    const tab = ensureTab(tabId);
    // 如果没有活跃对话，返回空
    if (!tab.activeId || !tab.conversations[tab.activeId]) {
      // 兼容：检查旧内存数据是否在 generateAnswer 中被写入了
      return [];
    }
    return [...tab.conversations[tab.activeId].messages];
  }

  /** 确保活跃对话存在（不存在则自动创建） */
  async function ensureActiveConversation(tabId) {
    await loadCache();
    const tab = ensureTab(tabId);
    if (!tab.activeId || !tab.conversations[tab.activeId]) {
      const id = generateId();
      const now = Date.now();
      tab.conversations[id] = {
        id,
        title: '新对话',
        createdAt: now,
        updatedAt: now,
        messages: []
      };
      tab.activeId = id;
      await saveCache();
    }
    return tab.activeId;
  }

  /**
   * 清除内存缓存 — 在 storage.onChanged 外部修改后同步
   * 或 Service Worker 被唤醒时重新加载
   */
  function invalidateCache() {
    cacheLoaded = false;
    cache = null;
  }

  /**
   * 对话历史兼容层 — 委托给 conversation-manager.js
   *
   * 保留旧 API 签名，内部全部桥接到 chrome.storage.local 持久化。
   * 所有函数现在返回 Promise。
   */


  function createHistoryStore(initial = {}) {
    // 不再使用内存 store，返回一个占位对象以保持兼容
    return {};
  }

  async function getHistorySnapshot(_store, tabId) {
    return getHistorySnapshot$1(tabId);
  }

  async function setHistorySnapshot(_store, tabId, history = []) {
    // 确保存在活跃对话后再写入
    await ensureActiveConversation(tabId);
    await setMessages(tabId, history);
  }

  async function clearHistoryForTab(_store, tabId) {
    await clearActiveConversation(tabId);
  }

  async function clearAllHistories(_store) {
    // 清空所有 tab 的活跃对话；简单干掉整个存储
    await chrome.storage.local.remove('webchat_conversations');
    invalidateCache();
  }

  async function recordUserMessage(_store, tabId, content) {
    await ensureActiveConversation(tabId);
    await addUserMessage(tabId, content);
  }

  async function recordAssistantMessage(_store, tabId, content) {
    await ensureActiveConversation(tabId);
    await addAssistantMessage(tabId, content);
  }

  /** 将用户消息写入指定对话（用于生成过程中切换对话时保留归属） */
  async function recordUserMessageToConv(_store, tabId, convId, content) {
    await addUserMessageToConv(tabId, convId, content);
  }

  /** 将助手消息写入指定对话 */
  async function recordAssistantMessageToConv(_store, tabId, convId, content) {
    await addAssistantMessageToConv(tabId, convId, content);
  }

  /** 获取指定对话的历史（用于生成过程中获取上下文） */
  async function getHistoryByConv(_store, tabId, convId) {
    return getMessagesByConv(tabId, convId);
  }

  /**
   * 跨 tab 内容抓取与压缩 — 仅在 background 上下文使用
   *
   *  - listAvailableTabs    枚举当前可注入的 tab（过滤 chrome:// 等）
   *  - extractTabContent    向目标 tab 注入精简版 parser 抓正文
   *  - compressContent      根据用户设置截断/AI 摘要
   *
   * 注意：chrome.scripting.executeScript 的 func 必须是自包含函数，
   * 不能引用外层 import，所以下方 inlinePageParser 把 page-parser 的核心逻辑内联了一份。
   */

  const UNSUPPORTED_PROTOCOLS = [
    'chrome:', 'edge:', 'about:', 'chrome-extension:', 'moz-extension:',
    'view-source:', 'devtools:', 'chrome-search:', 'chrome-untrusted:'
  ];

  function isSupportedUrl(url) {
    if (!url) return false;
    try {
      const u = new URL(url);
      if (UNSUPPORTED_PROTOCOLS.includes(u.protocol)) return false;
      // 扩展商店页面注入会被浏览器拦截
      if (/chromewebstore\.google\.com|chrome\.google\.com\/webstore/i.test(u.hostname)) return false;
      return true;
    } catch {
      return false;
    }
  }

  async function listAvailableTabs() {
    const tabs = await chrome.tabs.query({});
    return tabs
      .filter(t => isSupportedUrl(t.url))
      .map(t => ({
        id: t.id,
        title: t.title || '',
        url: t.url || '',
        favIconUrl: t.favIconUrl || '',
        windowId: t.windowId,
        active: t.active
      }));
  }

  async function extractTabContent(tabId) {
    try {
      const [result] = await chrome.scripting.executeScript({
        target: { tabId },
        func: inlinePageParser,
        args: [{ maxChars: 30000 }] // 抓取阶段不强压缩，留给 compressContent 决定
      });
      if (!result || !result.result) {
        return { tabId, error: '注入失败：无返回值' };
      }
      return { tabId, ...result.result };
    } catch (e) {
      return { tabId, error: e.message || String(e) };
    }
  }

  /**
   * @param {string} text
   * @param {object} opts
   * @param {'truncate'|'ai'|'hybrid'} opts.mode
   * @param {number} opts.maxChars
   * @param {(text:string, target:number)=>Promise<string>} opts.summarizer
   * @param {number} [opts.aiThreshold] hybrid 模式下超过该长度才走 AI 摘要
   */
  async function compressContent(text, opts) {
    const { mode = 'hybrid', maxChars = 3000, summarizer, aiThreshold = 8000 } = opts || {};
    if (!text) return { content: '', truncated: false, mode: 'noop' };
    if (text.length <= maxChars) return { content: text, truncated: false, mode: 'noop' };

    if (mode === 'truncate') {
      return {
        content: text.slice(0, maxChars) + `\n[已截断，原文 ${text.length} 字]`,
        truncated: true,
        mode: 'truncate'
      };
    }

    const shouldAI = mode === 'ai' || (mode === 'hybrid' && text.length >= aiThreshold);
    if (shouldAI && typeof summarizer === 'function') {
      try {
        const summary = await summarizer(text, maxChars);
        if (summary && summary.length) {
          return {
            content: summary.slice(0, maxChars + 500),
            truncated: true,
            mode: 'ai'
          };
        }
      } catch {
        // AI 摘要失败时继续走截断
      }
    }
    return {
      content: text.slice(0, maxChars) + `\n[已截断，原文 ${text.length} 字]`,
      truncated: true,
      mode: 'truncate'
    };
  }

  // ============================================================
  // 注入到目标 tab 执行的精简 parser（自包含、无 import）
  // ============================================================
  function inlinePageParser({ maxChars = 30000 } = {}) {
    const NOISE = [
      'script', 'style', 'noscript', 'template',
      'header', 'nav', 'footer', 'aside',
      '[role="navigation"]', '[role="banner"]', '[role="contentinfo"]',
      '.ad', '.ads', '.advert', '[class*="advertisement"]',
      '[aria-hidden="true"]'
    ];

    function extract(root) {
      const lines = [];
      const visit = (node) => {
        if (node.nodeType === 3) {
          const t = node.nodeValue.replace(/\s+/g, ' ');
          if (t.trim()) lines.push(t);
          return;
        }
        if (node.nodeType !== 1) return;
        const tag = node.tagName.toLowerCase();
        if (['script', 'style', 'noscript', 'template'].includes(tag)) return;
        if (/^h[1-6]$/.test(tag)) {
          lines.push('\n' + '#'.repeat(+tag[1]) + ' ' + node.textContent.trim() + '\n');
          return;
        }
        if (tag === 'li') {
          lines.push('- ' + node.textContent.trim());
          return;
        }
        if (['p', 'br', 'div', 'section', 'article', 'tr', 'pre', 'blockquote'].includes(tag)) {
          const before = lines.length;
          for (const c of node.childNodes) visit(c);
          if (lines.length > before) lines.push('');
          return;
        }
        for (const c of node.childNodes) visit(c);
      };
      visit(root);
      return lines.join('\n').replace(/\n{3,}/g, '\n\n').trim();
    }

    try {
      const clone = document.body?.cloneNode(true);
      if (!clone) return { title: document.title, url: location.href, content: '', error: 'no body' };
      NOISE.forEach(sel => clone.querySelectorAll(sel).forEach(el => el.remove()));
      const main = clone.querySelector('main') || clone.querySelector('article') || clone;
      let text = extract(main);
      if (text.length > maxChars) {
        text = text.slice(0, maxChars) + `\n[原始截断 ${text.length} 字]`;
      }
      return { title: document.title, url: location.href, content: text };
    } catch (e) {
      return { title: document.title, url: location.href, content: '', error: e.message };
    }
  }

  /**
   * 视觉副模型 fallback
   *
   * 主模型不支持视觉时（visionCapable=false 或用户未勾 supportsVision），
   * 用一个用户指定/自动选定的、视觉能力齐全的副模型把每张图片转成文字描述，
   * 再把描述拼回主模型的 user message 里一起回答。
   *
   * 调用方在 background 上下文。导出两个函数：
   *   - pickFallbackProvider(settings)
   *   - describeImages(images, providerKey, providerConfig)
   */


  const PROMPT = '请用一段不超过 200 字的中文描述这张图片的客观内容；如有可读文字请原文摘录关键句。不要主观评价，不要发挥联想。';
  const CONCURRENCY = 3;
  // 自动挑选时的优先级：先云端再本地
  const AUTO_PICK_ORDER = ['openai', 'claude', 'gemini', 'ollama'];

  /**
   * 在 settings 中挑一个可用的视觉副模型
   * @returns {{ providerKey: string, providerConfig: object } | null}
   */
  function pickFallbackProvider(settings) {
    const providers = settings?.providers || {};
    const candidates = [];

    // 1) 用户指定优先
    const explicit = settings?.visionFallbackProvider;
    if (explicit && PROVIDERS[explicit]?.visionCapable !== false) {
      candidates.push(explicit);
    }

    // 2) 自动挑：按 AUTO_PICK_ORDER 顺序补充
    for (const key of AUTO_PICK_ORDER) {
      if (!candidates.includes(key) && PROVIDERS[key]?.visionCapable) {
        candidates.push(key);
      }
    }

    for (const key of candidates) {
      const provider = PROVIDERS[key];
      const config = providers[key];
      if (!provider || !config) continue;
      // ollama 不需要 key
      if (provider.requiresKey && !config.apiKey) continue;
      return { providerKey: key, providerConfig: config };
    }

    return null;
  }

  /**
   * 把一组图片逐张转成文字描述
   * @param {Array<{id?:string, dataUrl:string, alt?:string, source?:string}>} images
   * @param {string} providerKey
   * @param {object} providerConfig
   * @returns {Promise<Array<{id?:string, ok:boolean, description:string, error?:string}>>}
   */
  async function describeImages(images, providerKey, providerConfig) {
    if (!Array.isArray(images) || images.length === 0) return [];

    const adapter = new ApiAdapter(providerKey, providerConfig);
    const results = new Array(images.length);
    let cursor = 0;

    async function worker() {
      while (true) {
        const i = cursor++;
        if (i >= images.length) return;
        const img = images[i];
        try {
          const messages = [
            {
              role: 'user',
              content: [
                { type: 'text', text: PROMPT },
                { type: 'image', dataUrl: img.dataUrl }
              ]
            }
          ];
          const { text } = await adapter.callOnce(messages, { maxTokens: 400, temperature: 0.2 });
          results[i] = {
            id: img.id,
            ok: true,
            description: (text || '').trim()
          };
        } catch (err) {
          results[i] = {
            id: img.id,
            ok: false,
            description: '',
            error: err?.message || String(err)
          };
        }
      }
    }

    const workers = Array.from({ length: Math.min(CONCURRENCY, images.length) }, () => worker());
    await Promise.all(workers);
    return results;
  }

  /**
   * 把 describeImages 的结果格式化成主模型可读的中文段落
   */
  function formatImageDescriptions(images, descriptions) {
    const lines = ['', '【图片描述（来自视觉副模型）】'];
    descriptions.forEach((r, i) => {
      const src = images[i]?.source || 'unknown';
      if (r.ok) {
        lines.push(`图片 ${i + 1}（来源：${src}）：${r.description}`);
      } else {
        lines.push(`图片 ${i + 1}（来源：${src}）：[描述获取失败：${r.error || '未知错误'}]`);
      }
    });
    return lines.join('\n');
  }

  const REQUEST_TIMEOUT_MS = 60000;

  // 存储会话历史的对象，键是标签ID
  let sessionHistories = createHistoryStore();
  let generatingStates = {};
  let currentAnswers = {};
  let activePorts = {};
  let activeAborts = {};
  let completedAnswers = {};

  // 设置点击扩展图标时打开侧边栏（而非 popup）
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true })
    .catch(err => console.warn('sidePanel.setPanelBehavior 失败：', err?.message || err));

  // 扩展安装时执行迁移
  chrome.runtime.onInstalled.addListener(async () => {
    await migrateSettings();
    console.log('WebChat 扩展已安装/更新，设置已迁移');

    // 注册右键菜单：图片 → 添加到 WebChat 图片标记
    try {
      chrome.contextMenus.removeAll(() => {
        chrome.contextMenus.create({
          id: 'webchat-mark-image',
          title: '添加到 WebChat 图片标记',
          contexts: ['image']
        });
      });
    } catch (e) {
      console.warn('注册右键菜单失败：', e?.message || e);
    }
  });

  // 右键菜单：把图片 srcUrl 转给 content script
  chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (info.menuItemId !== 'webchat-mark-image' || !tab?.id) return;
    chrome.tabs.sendMessage(tab.id, {
      action: 'imageMark/addByUrl',
      srcUrl: info.srcUrl,
      pageUrl: info.pageUrl,
      frameUrl: info.frameUrl
    }).catch(() => {
      // content script 未注入或页面不允许注入
    });
  });

  // 处理来自 popup/content 的消息
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'saveHistory') {
      setHistorySnapshot(sessionHistories, request.tabId, request.history)
        .then(() => sendResponse({ status: 'ok' }));
      return true;
    } else if (request.action === 'getHistory') {
      (async () => {
        // 确保活跃对话存在
        await ensureActiveConversation(request.tabId);
        const history = await getHistorySnapshot(sessionHistories, request.tabId);
        const state = generatingStates[request.tabId] || { isGenerating: false };

        if (state.isGenerating && state.pendingQuestion) {
          const lastMessage = history[history.length - 1];
          if (!lastMessage || !lastMessage.isUser || lastMessage.content !== state.pendingQuestion) {
            const updatedHistory = [...history, { content: state.pendingQuestion, isUser: true }];
            sendResponse({
              history: updatedHistory,
              isGenerating: state.isGenerating,
              pendingQuestion: state.pendingQuestion,
              currentAnswer: currentAnswers[request.tabId] || ''
            });
            return;
          }
        }

        sendResponse({
          history,
          isGenerating: state.isGenerating,
          pendingQuestion: state.pendingQuestion,
          currentAnswer: currentAnswers[request.tabId] || ''
        });
      })();
      return true;
    } else if (request.action === 'clearHistory') {
      (async () => {
        await clearHistoryForTab(sessionHistories, request.tabId);
        delete generatingStates[request.tabId];
        delete currentAnswers[request.tabId];
        delete completedAnswers[request.tabId];
        sendResponse({ status: 'ok' });
      })();
      return true;
    } else if (request.action === 'listConversations') {
      listConversations(request.tabId).then(
        (conversations) => sendResponse({ conversations }),
        (err) => sendResponse({ error: err.message })
      );
      return true;
    } else if (request.action === 'createConversation') {
      createConversation(request.tabId).then(
        (conv) => sendResponse({ conversation: conv }),
        (err) => sendResponse({ error: err.message })
      );
      return true;
    } else if (request.action === 'deleteConversation') {
      deleteConversation(request.tabId, request.convId).then(
        (ok) => sendResponse({ status: ok ? 'ok' : 'not-found' }),
        (err) => sendResponse({ error: err.message })
      );
      return true;
    } else if (request.action === 'switchConversation') {
      switchConversation(request.tabId, request.convId).then(
        (ok) => sendResponse({ status: ok ? 'ok' : 'not-found' }),
        (err) => sendResponse({ error: err.message })
      );
      return true;
    } else if (request.action === 'reloadExtension') {
      sendResponse({ status: 'ok' });
      // 延迟一点让 sendResponse 发出去
      setTimeout(() => chrome.runtime.reload(), 100);
      return true;
    } else if (request.action === 'getCurrentTab') {
      sendResponse({ tabId: sender.tab.id });
    } else if (request.action === 'openOptions') {
      chrome.runtime.openOptionsPage();
      sendResponse({ status: 'ok' });
    } else if (request.action === 'downloadScript') {
      handleDownloadScript(request).then(sendResponse, (err) => sendResponse({ ok: false, error: err.message }));
      return true;
    } else if (request.action === 'downloadImage') {
      handleDownloadImage(request).then(sendResponse, (err) => sendResponse({ ok: false, error: err.message }));
      return true;
    } else if (request.action === 'captureScreenshot') {
      handleCaptureScreenshot(sender).then(sendResponse, (err) => sendResponse({ error: err.message }));
      return true;
    } else if (request.action === 'captureRegion') {
      // 区域截图：返回整页截图，由 content 自己 crop
      handleCaptureScreenshot(sender).then(sendResponse, (err) => sendResponse({ error: err.message }));
      return true;
    } else if (request.action === 'aiAssist') {
      handleAiAssist(request).then(sendResponse, (err) => sendResponse({ error: err.message }));
      return true;
    } else if (request.action === 'listTabs') {
      listAvailableTabs().then(
        (tabs) => sendResponse({ tabs }),
        (err) => sendResponse({ error: err.message })
      );
      return true;
    } else if (request.action === 'extractTabs') {
      handleExtractTabs(request).then(sendResponse, (err) => sendResponse({ error: err.message }));
      return true;
    }
    // 默认不返回 true，避免对未识别的 action 把通道挂着等不到 sendResponse，
    // 触发 "A listener indicated an asynchronous response..." 误报
    return false;
  });

  // ============ 脚本相关辅助函数 ============

  async function handleDownloadScript({ content, filename, mime }) {
    const dataUrl = 'data:' + (mime || 'application/octet-stream') + ';charset=utf-8,' + encodeURIComponent(content);
    return new Promise((resolve, reject) => {
      chrome.downloads.download({
        url: dataUrl,
        filename: filename || 'webchat-script.json',
        saveAs: false
      }, (id) => {
        if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
        else resolve({ ok: true, id });
      });
    });
  }

  async function handleDownloadImage({ dataUrl, filename }) {
    if (!dataUrl || !filename) throw new Error('dataUrl 和 filename 不能为空');
    // content script 已将图片转成 data URL（带页面 Referer 的 fetch），这里直接下载
    return new Promise((resolve, reject) => {
      chrome.downloads.download({
        url: dataUrl,
        filename: 'webchat-xhs-covers/' + filename,
        saveAs: false
      }, (id) => {
        if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
        else resolve({ ok: true, id });
      });
    });
  }

  async function handleCaptureScreenshot(sender) {
    return new Promise((resolve, reject) => {
      const windowId = sender?.tab?.windowId;
      chrome.tabs.captureVisibleTab(windowId ?? chrome.windows.WINDOW_ID_CURRENT, { format: 'png' }, (dataUrl) => {
        if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
        else resolve({ dataUrl });
      });
    });
  }

  async function handleAiAssist(request) {
    const active = await getActiveProviderConfig();
    const { providerKey, apiKey, apiBase, model } = active;
    if (!apiBase) throw new Error('未配置 API 地址，请在扩展选项中完成配置');
    if (!model) throw new Error('未配置模型，请在扩展选项中完成配置');
    const adapter = new ApiAdapter(providerKey, { apiKey, apiBase, model });

    let systemPrompt = '';
    let userPrompt = '';
    if (request.mode === 'read') {
      systemPrompt = '你是网页内容理解助手。根据用户的需求，从给出的页面内容中提取信息或回答问题，仅输出结果文本。';
      userPrompt = `指令：${request.prompt}\n\n页面内容：\n${request.content || ''}`;
    } else if (request.mode === 'locate') {
      systemPrompt = '你是网页元素定位助手。根据描述与候选元素列表，返回最匹配元素的 selector。仅输出 JSON：{"selector":"..."}';
      userPrompt = `描述：${request.description}\n\n候选元素：\n${JSON.stringify(request.elements || [], null, 2)}`;
  } else if (request.mode === 'generate') {
      ({ systemPrompt, userPrompt } = buildGenerateScriptPrompts({
        prompt: request.prompt,
        pageInfo: request.pageInfo
      }));
    } else {
      throw new Error('未知的 aiAssist 模式：' + request.mode);
    }

    const messages = [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: userPrompt }
    ];
    const url = adapter.buildUrl();
    const headers = adapter.buildHeaders();
    const body = adapter.buildRequestBody(messages, { maxTokens: 2000 });
    if (body.stream !== undefined) body.stream = false;

    const response = await fetch(url.replace('&alt=sse', ''), {
      method: 'POST',
      headers,
      body: JSON.stringify(body)
    });
    if (!response.ok) {
      const txt = await response.text().catch(() => '');
      throw new Error(`AI 请求失败 (${response.status}): ${txt.slice(0, 200)}`);
    }
    const json = await response.json();
    const text = extractAiText(json);

    if (request.mode === 'read') return { text };
    if (request.mode === 'locate') {
      try { return JSON.parse(extractJsonBlock(text)); } catch { return { selector: null, raw: text }; }
    }
    if (request.mode === 'generate') {
      try {
        const parsed = JSON.parse(extractJsonBlock(text));
        return { script: normalizeGeneratedScript(parsed, request.pageInfo || {}) };
      }
      catch (e) { return { error: '生成结果非 JSON：' + e.message, raw: text }; }
    }
    return { text };
  }

  // 处理 extractTabs 请求 — 并发抓取选中 tab 的正文、按用户压缩设置压缩
  async function handleExtractTabs(request) {
    const { tabIds = [] } = request;
    const settings = await chrome.storage.sync.get({
      enableTabCompression: DEFAULT_SETTINGS.enableTabCompression,
      tabCompressMaxChars: DEFAULT_SETTINGS.tabCompressMaxChars,
      tabCompressMode: DEFAULT_SETTINGS.tabCompressMode
    });

    const summarizer = createAiSummarizer();

    const results = await Promise.all(
      tabIds.map(async (tabId) => {
        const raw = await extractTabContent(tabId);
        if (raw.error || !raw.content) return raw;
        if (!settings.enableTabCompression) {
          return { ...raw, truncated: false, compressMode: 'noop' };
        }
        const compressed = await compressContent(raw.content, {
          mode: settings.tabCompressMode,
          maxChars: settings.tabCompressMaxChars,
          summarizer
        });
        return {
          ...raw,
          content: compressed.content,
          truncated: compressed.truncated,
          compressMode: compressed.mode
        };
      })
    );

    return { tabs: results };
  }

  // 用当前 provider 给一段长文本做摘要 — 与 handleAiAssist 的 read 模式同款（非流式）
  function createAiSummarizer() {
    return async (text, target) => {
      const active = await getActiveProviderConfig();
      const { providerKey, apiKey, apiBase, model } = active;
      if (!apiBase || !model) throw new Error('AI 摘要不可用：未完成 provider 配置');
      const adapter = new ApiAdapter(providerKey, { apiKey, apiBase, model });

      const messages = [
        { role: 'system', content: '你是网页内容压缩助手。请在保留关键事实的前提下，把页面正文压缩到指定字数以内，输出纯文本，不要添加任何解释或前后缀。' },
        { role: 'user', content: `目标字数：约 ${target} 字。\n\n内容：\n${text}` }
      ];

      const url = adapter.buildUrl();
      const headers = adapter.buildHeaders();
      const body = adapter.buildRequestBody(messages, { maxTokens: Math.min(2048, Math.ceil(target / 1.5)) });
      if (body.stream !== undefined) body.stream = false;

      const response = await fetch(url.replace('&alt=sse', ''), {
        method: 'POST', headers, body: JSON.stringify(body)
      });
      if (!response.ok) throw new Error(`摘要请求失败 (${response.status})`);
      const json = await response.json();
      return extractAiText(json) || '';
    };
  }

  function extractAiText(json) {
    // OpenAI / Anthropic / Gemini 兼容
    if (json.choices?.[0]?.message?.content) return json.choices[0].message.content;
    if (json.choices?.[0]?.text) return json.choices[0].text;
    if (json.content?.[0]?.text) return json.content[0].text;
    if (json.candidates?.[0]?.content?.parts?.[0]?.text) return json.candidates[0].content.parts[0].text;
    if (typeof json.response === 'string') return json.response;
    return JSON.stringify(json);
  }

  function extractJsonBlock(text) {
    if (!text) return '';
    // 去掉 ```json 包裹
    const fence = text.match(/```(?:json)?\s*([\s\S]*?)```/);
    if (fence) return fence[1].trim();
    // 直接定位首个 { ... } 完整片段
    const start = text.indexOf('{');
    const end = text.lastIndexOf('}');
    if (start >= 0 && end > start) return text.slice(start, end + 1);
    return text.trim();
  }

  // 长连接处理 — 流式生成
  chrome.runtime.onConnect.addListener((port) => {
    if (port.name === 'scriptGenerateStream') {
      handleScriptGenerateStream(port);
      return;
    }
    if (port.name !== 'answerStream') return;

    port.onMessage.addListener(async (request) => {
      const tabId = request.tabId;

      if (request.action === 'generateAnswer') {
        activePorts[tabId] = port;
        try {
          await handleAnswerGeneration(port, tabId, {
            pageContent: request.pageContent,
            question: request.question,
            images: request.images || [],
            referencedTabs: request.referencedTabs || []
          });
        } catch (error) {
          if (port === activePorts[tabId]) {
            try { port.postMessage({ type: 'error', error: error.message }); } catch {}
          }
        }
      } else if (request.action === 'reconnectStream') {
        if (completedAnswers[tabId]) {
          port.postMessage({ type: 'answer-chunk', content: completedAnswers[tabId] });
          port.postMessage({ type: 'answer-end' });
          delete completedAnswers[tabId];
        } else if (currentAnswers[tabId]) {
          port.postMessage({ type: 'answer-chunk', content: currentAnswers[tabId] });
          activePorts[tabId] = port;
        } else if (generatingStates[tabId]?.isGenerating) {
          activePorts[tabId] = port;
        } else {
          port.postMessage({ type: 'answer-end' });
        }
      }
    });

    port.onDisconnect.addListener(() => {
      for (const tabId in activePorts) {
        if (activePorts[tabId] === port) {
          delete activePorts[tabId];
          // 端口断开 = 用户主动停止生成，立刻 abort 正在进行的 fetch
          const ctrl = activeAborts[tabId];
          if (ctrl) {
            try { ctrl.abort(); } catch {}
            delete activeAborts[tabId];
          }
          break;
        }
      }
    });
  });

  // 拼接 user message 文本：主页面 + 引用 tab + 图片状态提示 + 副模型描述
  function buildUserPrompt({
    pageContent, question, referencedTabs,
    imageCount, visionEnabled,
    fallbackUsed = false, fallbackProviderName = '', fallbackDescriptions = ''
  }) {
    const parts = ['基于以下网页内容回答问题：', '', '【主页面】', pageContent || '(无内容)'];

    if (Array.isArray(referencedTabs) && referencedTabs.length) {
      referencedTabs.forEach((tab, i) => {
        parts.push('', `【引用页面 ${i + 1}】${tab.title || ''}`);
        if (tab.url) parts.push(`URL：${tab.url}`);
        if (tab.error) {
          parts.push(`(抓取失败：${tab.error})`);
        } else {
          parts.push(tab.content || '');
          if (tab.truncated) parts.push(`[已${tab.compressMode === 'ai' ? 'AI 压缩' : '截断'}]`);
        }
      });
    }

    if (imageCount > 0 && visionEnabled) {
      parts.push('', `（已附带 ${imageCount} 张图片，请结合图片内容分析）`);
    } else if (imageCount > 0 && fallbackUsed && fallbackDescriptions) {
      parts.push(
        '',
        `（当前模型不支持视觉，已用 ${fallbackProviderName} 视觉副模型把 ${imageCount} 张图片转写为下列文字描述，请基于这些描述回答）`,
        fallbackDescriptions
      );
    } else if (imageCount > 0) {
      parts.push('', `[包含 ${imageCount} 张图片，但当前模型不支持视觉、且未配置可用的视觉副模型，已忽略]`);
    }

    parts.push('', `问题：${question}`);
    return parts.join('\n');
  }

  // 核心：流式生成回答
  async function handleAnswerGeneration(port, tabId, payload) {
    const { pageContent, question, images = [], referencedTabs = [], systemPromptOverride, convId } = payload;
    const abortCtrl = new AbortController();
    activeAborts[tabId] = abortCtrl;
    // 使用传入的 convId，若无则回退到活跃对话
    const targetConvId = convId || null;

    try {
      // 保存用户问题到历史（持久化），失败不影响主流程
      try {
        if (targetConvId) {
          await recordUserMessageToConv(sessionHistories, tabId, targetConvId, question);
        } else {
          await recordUserMessage(sessionHistories, tabId, question);
        }
      } catch (e) {
        console.warn('保存用户消息失败:', e?.message || e);
      }

      currentAnswers[tabId] = '';
      completedAnswers[tabId] = null;
      generatingStates[tabId] = { isGenerating: true, pendingQuestion: question };

      // 获取设置
      const settings = await chrome.storage.sync.get({
        activeProvider: DEFAULT_SETTINGS.activeProvider,
        providers: DEFAULT_SETTINGS.providers,
        maxTokens: DEFAULT_SETTINGS.maxTokens,
        temperature: DEFAULT_SETTINGS.temperature,
        enableContext: DEFAULT_SETTINGS.enableContext,
        maxContextRounds: DEFAULT_SETTINGS.maxContextRounds,
        systemPrompt: DEFAULT_SETTINGS.systemPrompt,
        enableImageRecognition: DEFAULT_SETTINGS.enableImageRecognition,
        visionFallbackProvider: DEFAULT_SETTINGS.visionFallbackProvider
      });

      // 获取当前提供商配置
      const providerKey = settings.activeProvider;
      const providerConfig = settings.providers[providerKey] || {};
      const adapter = new ApiAdapter(providerKey, providerConfig);

      // 构建消息 — systemPromptOverride 用于小红书重写等特殊场景
      const effectiveSystemPrompt = systemPromptOverride || settings.systemPrompt;
      let messages = [{ role: 'system', content: effectiveSystemPrompt }];

      // 添加历史上下文（注意：不重复包含本轮的 user question，下面单独追加）
      if (settings.enableContext) {
        const history = targetConvId
          ? await getHistoryByConv(sessionHistories, tabId, targetConvId)
          : await getHistorySnapshot(sessionHistories, tabId);
        const maxMessages = settings.maxContextRounds * 2;
        const recentHistory = history.slice(-(maxMessages));
        // 去掉末尾刚 push 的 user question，避免下方重复添加
        const trimmed = recentHistory.length && recentHistory[recentHistory.length - 1].isUser && recentHistory[recentHistory.length - 1].content === question
          ? recentHistory.slice(0, -1)
          : recentHistory;
        trimmed.forEach(msg => {
          messages.push({
            role: msg.isUser ? 'user' : 'assistant',
            content: msg.content
          });
        });
      }

      // 拼接当前问题（含网页内容 + 引用 tab + 图片占位提示）
      // 视觉硬门：协议本身不支持（如 DeepSeek 的 visionCapable=false），即便用户勾了开关也忽略
      const protocolVisionOk = PROVIDERS[providerKey]?.visionCapable !== false;
      const visionEnabled = settings.enableImageRecognition
        && !!providerConfig.supportsVision
        && protocolVisionOk;

      // 视觉副模型 fallback：主模型不支持视觉、但用户标记了图片 → 用副模型把图转文字
      let fallbackDescriptions = '';
      let fallbackUsed = false;
      let fallbackProviderName = '';
      if (!visionEnabled && images.length > 0 && settings.enableImageRecognition !== false) {
        const fb = pickFallbackProvider(settings);
        if (fb) {
          fallbackUsed = true;
          fallbackProviderName = PROVIDERS[fb.providerKey]?.name || fb.providerKey;
          try {
            if (port) try { port.postMessage({ type: 'status', message: `正在用 ${fallbackProviderName} 识别 ${images.length} 张图片...` }); } catch {}
            const results = await describeImages(images, fb.providerKey, fb.providerConfig);
            fallbackDescriptions = formatImageDescriptions(images, results);
          } catch (e) {
            console.warn('视觉副模型调用失败：', e);
            fallbackDescriptions = `\n[视觉副模型调用失败：${e?.message || e}]`;
          }
        }
      }

      const userText = buildUserPrompt({
        pageContent,
        question,
        referencedTabs,
        imageCount: images.length,
        visionEnabled,
        fallbackUsed,
        fallbackProviderName,
        fallbackDescriptions
      });

      if (visionEnabled && images.length) {
        const parts = [{ type: 'text', text: userText }];
        for (const img of images.slice(0, 8)) {
          if (img && img.dataUrl) parts.push({ type: 'image', dataUrl: img.dataUrl });
        }
        messages.push({ role: 'user', content: parts });
      } else {
        messages.push({ role: 'user', content: userText });
      }

      // 构建请求
      const url = adapter.buildUrl();
      const headers = adapter.buildHeaders();
      const body = adapter.buildRequestBody(messages, {
        maxTokens: settings.maxTokens,
        temperature: settings.temperature
      });

      // 估算输入 tokens；图片每张按 1500 估
      const textTokens = messages.reduce((sum, m) => {
        if (typeof m.content === 'string') return sum + estimateTokens(m.content);
        if (Array.isArray(m.content)) {
          return sum + m.content.reduce((s, p) => s + (p.type === 'text' ? estimateTokens(p.text) : 0), 0);
        }
        return sum;
      }, 0);
      const imageTokens = visionEnabled ? images.length * 1500 : 0;
      const inputTokens = textTokens + imageTokens;
      if (port) {
        try { port.postMessage({ type: 'input-tokens', tokens: inputTokens }); } catch {}
      }

      // 超时处理
      const timeoutId = setTimeout(() => {
        try { abortCtrl.abort(new DOMException('timeout', 'TimeoutError')); } catch {}
      }, REQUEST_TIMEOUT_MS);

      // 发起流式请求
      let response;
      try {
        response = await fetch(url, {
          method: 'POST',
          headers,
          body: JSON.stringify(body),
          signal: abortCtrl.signal
        });
      } finally {
        clearTimeout(timeoutId);
      }

      if (!response.ok) {
        const errorText = await response.text();
        let providerMsg = '';
        try {
          const errorJson = JSON.parse(errorText);
          providerMsg = errorJson.error?.message || errorJson.message || '';
        } catch {}
        throw friendlyError({ status: response.status, providerMessage: providerMsg, providerKey });
      }

      // 读取流式响应
      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let accumulatedResponse = '';
      let buffer = '';

      while (true) {
        if (!activePorts[tabId]) {
          try { await reader.cancel(); } catch {}
          break;
        }

        let chunk;
        try {
          chunk = await reader.read();
        } catch (err) {
          if (abortCtrl.signal.aborted) break;
          throw err;
        }
        const { done, value } = chunk;
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          if (!line.trim()) continue;

          const result = adapter.parseStreamLine(line);
          if (!result) continue;

          if (result.done) continue;

          if (result.content && port) {
            accumulatedResponse += result.content;
            currentAnswers[tabId] = accumulatedResponse;
            const outputTokens = estimateTokens(result.content);
            try {
              port.postMessage({
                type: 'answer-chunk',
                content: result.content,
                markdownContent: accumulatedResponse,
                tokens: outputTokens
              });
            } catch {
              try { await reader.cancel(); } catch {}
              return;
            }
          }
        }
      }

      // 完成
      if (activePorts[tabId] === port) {
        try {
          port.postMessage({ type: 'answer-end', markdownContent: accumulatedResponse });
        } catch {}

        try {
          if (targetConvId) {
            await recordAssistantMessageToConv(sessionHistories, tabId, targetConvId, accumulatedResponse);
          } else {
            await recordAssistantMessage(sessionHistories, tabId, accumulatedResponse);
          }
        } catch (e) {
          console.warn('保存助手消息失败:', e?.message || e);
        }
      } else {
        completedAnswers[tabId] = accumulatedResponse;
      }

    } catch (error) {
      if (error?.name === 'AbortError' || abortCtrl.signal.aborted) {
        // 用户主动停止 / 超时取消，不当作错误对外抛
        if (error?.name === 'TimeoutError' || error?.message === 'timeout') {
          if (port) try { port.postMessage({ type: 'error', error: '请求超时，请检查网络或稍后重试' }); } catch {}
        }
      } else {
        console.error('生成回答时出错:', error);
        if (port) {
          try { port.postMessage({ type: 'error', error: error.message }); } catch {}
        }
      }
    } finally {
      generatingStates[tabId] = { isGenerating: false };
      delete currentAnswers[tabId];
      if (activeAborts[tabId] === abortCtrl) {
        delete activeAborts[tabId];
      }
    }
  }

  // 监听设置变更
  chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace === 'sync') {
      if (changes.enableContext && !changes.enableContext.newValue) {
        clearAllHistories().catch(err => console.warn('清空历史失败:', err));
      }
    }
  });

  // 标签页更新/关闭时清理（不再清除持久化对话，只清理运行状态）
  chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
    if (changeInfo.status === 'loading') {
      delete generatingStates[tabId];
      delete currentAnswers[tabId];
      delete activePorts[tabId];
      delete completedAnswers[tabId];
      const ctrl = activeAborts[tabId];
      if (ctrl) {
        try { ctrl.abort(); } catch {}
        delete activeAborts[tabId];
      }
    }
  });

  chrome.tabs.onRemoved.addListener((tabId) => {
    delete generatingStates[tabId];
    delete currentAnswers[tabId];
    delete activePorts[tabId];
    delete completedAnswers[tabId];
    const ctrl = activeAborts[tabId];
    if (ctrl) {
      try { ctrl.abort(); } catch {}
      delete activeAborts[tabId];
    }
  });

  // ========================================================================
  // 流式 AI 脚本生成
  // ========================================================================
  // 区别于 handleAiAssist 的非流式实现：把 stream:true 打开，每收到一个 chunk
  // 就推送给 panel 端，让 UI 能显示"正在生成中"的实时文本，最后再做 JSON 解析
  // 与 normalizeGeneratedScript 处理。
  async function handleScriptGenerateStream(port) {
    const abortCtrl = new AbortController();
    let aborted = false;
    // 每 20s 推一条 ping，目的有两个：
    //  1) MV3 service worker 在 30s 内没有 port 活动会被回收，端口断开后我们的
    //     fetch 会被 abort，进而被 panel 看到一条似是而非的 "channel closed" 错误。
    //     持续在 port 上发消息能让 worker 保活。
    //  2) 网络中断时 panel 也能更早察觉。
    const keepalive = setInterval(() => {
      try { port.postMessage({ type: 'ping' }); } catch { /* port closed */ }
    }, 20000);
    port.onDisconnect.addListener(() => {
      aborted = true;
      clearInterval(keepalive);
      try { abortCtrl.abort(); } catch {}
    });

    port.onMessage.addListener(async (request) => {
      if (request.action !== 'generateScript') return;
      try {
        await runScriptGenerateStream(port, request, abortCtrl, () => aborted);
      } catch (err) {
        if (!aborted) {
          const msg = (err && err.name === 'AbortError') ? '请求被取消（可能因超时或服务被回收）' : (err.message || String(err));
          try { port.postMessage({ type: 'error', error: msg }); } catch {}
        }
      } finally {
        clearInterval(keepalive);
      }
    });
  }

  async function runScriptGenerateStream(port, request, abortCtrl, isAborted) {
    const active = await getActiveProviderConfig();
    const { providerKey, apiKey, apiBase, model } = active;
    if (!apiBase) throw new Error('未配置 API 地址，请在扩展选项中完成配置');
    if (!model) throw new Error('未配置模型，请在扩展选项中完成配置');
    const adapter = new ApiAdapter(providerKey, { apiKey, apiBase, model });

    const { systemPrompt, userPrompt } = buildGenerateScriptPrompts({
      prompt: request.prompt,
      pageInfo: request.pageInfo
    });

    const messages = [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: userPrompt }
    ];
    const url = adapter.buildUrl();
    const headers = adapter.buildHeaders();
    const body = adapter.buildRequestBody(messages, { maxTokens: 2000 });
    // 显式确保 stream 开启（adapter 默认就是 true，这里防御性写一下）
    body.stream = true;

    // 首字节超时：等服务端开始返回的最长时间。模型排队/慢启动时给充足时间。
    const FIRST_BYTE_TIMEOUT_MS = 90000;
    // 空闲超时：两次 chunk 之间最长间隔。流一开就缩短到这个值，长生成也不会被误杀。
    const IDLE_TIMEOUT_MS = 45000;

    let stallTimer = setTimeout(() => {
      try { abortCtrl.abort(new DOMException('first-byte-timeout', 'TimeoutError')); } catch {}
    }, FIRST_BYTE_TIMEOUT_MS);
    let lastTimeoutKind = 'first-byte';
    const armIdle = () => {
      clearTimeout(stallTimer);
      lastTimeoutKind = 'idle';
      stallTimer = setTimeout(() => {
        try { abortCtrl.abort(new DOMException('idle-timeout', 'TimeoutError')); } catch {}
      }, IDLE_TIMEOUT_MS);
    };

    let response;
    try {
      response = await fetch(url, {
        method: 'POST',
        headers,
        body: JSON.stringify(body),
        signal: abortCtrl.signal
      });
    } catch (err) {
      clearTimeout(stallTimer);
      if (err?.name === 'AbortError' && abortCtrl.signal.aborted) {
        throw new Error(`AI 请求${lastTimeoutKind === 'first-byte' ? '首字节超时' : '中断'}（${FIRST_BYTE_TIMEOUT_MS / 1000}s 内未响应）`);
      }
      throw err;
    }

    if (!response.ok) {
      clearTimeout(stallTimer);
      const txt = await response.text().catch(() => '');
      throw new Error(`AI 请求失败 (${response.status}): ${txt.slice(0, 200)}`);
    }

    try { port.postMessage({ type: 'stream-start' }); } catch {}

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let accumulated = '';
    let buffer = '';

    try {
      while (true) {
        if (isAborted()) {
          try { await reader.cancel(); } catch {}
          return;
        }
        let chunk;
        try {
          chunk = await reader.read();
        } catch (err) {
          if (abortCtrl.signal.aborted) {
            throw new Error(`AI 流式响应${lastTimeoutKind === 'idle' ? `空闲超时（${IDLE_TIMEOUT_MS / 1000}s 无新增内容）` : '被中断'}`);
          }
          throw err;
        }
        const { done, value } = chunk;
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';
        let gotChunk = false;
        for (const line of lines) {
          if (!line.trim()) continue;
          const result = adapter.parseStreamLine(line);
          if (!result || result.done) continue;
          if (result.content) {
            accumulated += result.content;
            gotChunk = true;
            try {
              port.postMessage({ type: 'chunk', content: result.content, accumulated });
            } catch {
              try { await reader.cancel(); } catch {}
              return;
            }
          }
        }
        // 只要拿到了内容就重置空闲计时器
        if (gotChunk) armIdle();
      }
    } finally {
      clearTimeout(stallTimer);
    }

    // 解析最终 JSON
    try {
      const parsed = JSON.parse(extractJsonBlock(accumulated));
      const script = normalizeGeneratedScript(parsed, request.pageInfo || {});
      try { port.postMessage({ type: 'done', script, raw: accumulated }); } catch {}
    } catch (e) {
      try { port.postMessage({ type: 'error', error: '生成结果非 JSON：' + e.message, raw: accumulated }); } catch {}
    }
  }

})();
