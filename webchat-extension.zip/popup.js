(function () {
  'use strict';

  /**
   * 统一的 marked 加载与配置；popup 和 content 共用
   * 假定 marked 已在 lib/marked.min.js 中通过 script 标签预加载
   */
  async function getMarkdownRenderer() {
    // 等待全局 marked 可用（最多 5s）
    if (typeof marked === 'undefined') {
      await new Promise((resolve, reject) => {
        const start = Date.now();
        const tick = () => {
          if (typeof marked !== 'undefined') return resolve();
          if (Date.now() - start > 5000) return reject(new Error('marked 加载超时'));
          setTimeout(tick, 100);
        };
        tick();
      });
    }
    marked.setOptions({
      breaks: true,
      gfm: true,
      headerIds: false,
      mangle: false
    });
    return (text) => marked.parse(text || '');
  }

  /**
   * 轻量级 HTML 净化器，专为 marked 渲染后的输出设计
   * 仅允许常见 markdown 输出标签和有限属性，移除 script/iframe/事件回调/javascript: URL
   * 不依赖外部库，避免给扩展打包带来负担
   */

  const ALLOWED_TAGS = new Set([
    'a', 'p', 'br', 'hr',
    'strong', 'b', 'em', 'i', 'u', 's', 'del', 'mark', 'small',
    'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
    'ul', 'ol', 'li',
    'blockquote', 'pre', 'code', 'kbd', 'samp', 'var',
    'table', 'thead', 'tbody', 'tfoot', 'tr', 'th', 'td',
    'img', 'span', 'div'
  ]);

  const ALLOWED_ATTRS = {
    a: ['href', 'title', 'target', 'rel'],
    img: ['src', 'alt', 'title', 'width', 'height'],
    '*': ['class']
  };

  const URL_ATTRS = new Set(['href', 'src']);

  function isSafeUrl(value) {
    if (!value) return false;
    const trimmed = String(value).trim();
    // 拒绝 javascript: / data:text/html / vbscript:
    if (/^(javascript|vbscript):/i.test(trimmed)) return false;
    if (/^data:text\/html/i.test(trimmed)) return false;
    return true;
  }

  function cleanAttributes(el) {
    const tag = el.tagName.toLowerCase();
    const allowed = new Set([...(ALLOWED_ATTRS[tag] || []), ...(ALLOWED_ATTRS['*'] || [])]);

    for (const attr of [...el.attributes]) {
      const name = attr.name.toLowerCase();

      // 移除事件处理属性
      if (name.startsWith('on')) {
        el.removeAttribute(attr.name);
        continue;
      }

      // 不在白名单内的属性删除
      if (!allowed.has(name)) {
        el.removeAttribute(attr.name);
        continue;
      }

      // URL 类属性做协议检查
      if (URL_ATTRS.has(name) && !isSafeUrl(attr.value)) {
        el.removeAttribute(attr.name);
      }
    }

    // 链接默认在新窗口打开 + 安全 rel
    if (tag === 'a') {
      if (el.hasAttribute('href')) {
        el.setAttribute('target', '_blank');
        el.setAttribute('rel', 'noopener noreferrer');
      }
    }
  }

  /**
   * 净化 HTML 字符串，返回安全的 HTML
   */
  function sanitizeHTML(dirty) {
    if (typeof dirty !== 'string' || !dirty) return '';

    const template = document.createElement('template');
    template.innerHTML = dirty;

    const walk = (node) => {
      const children = [...node.childNodes];
      for (const child of children) {
        if (child.nodeType === 1 /* element */) {
          const tag = child.tagName.toLowerCase();
          if (!ALLOWED_TAGS.has(tag)) {
            // 不允许的标签：保留其文本子节点
            while (child.firstChild) node.insertBefore(child.firstChild, child);
            node.removeChild(child);
            continue;
          }
          cleanAttributes(child);
          walk(child);
        } else if (child.nodeType === 8 /* comment */) {
          node.removeChild(child);
        }
      }
    };

    walk(template.content);
    return template.innerHTML;
  }

  /**
   * 把净化后的 HTML 安全地写入元素
   */
  function setSafeHTML(el, dirty) {
    el.innerHTML = sanitizeHTML(dirty);
  }

  let markedInstance;

  async function initMarked() {
      try {
          markedInstance = await getMarkdownRenderer();
          console.log('Marked初始化成功');
      } catch (error) {
          console.error('Marked初始化失败:', error);
          markedInstance = text => text;
      }
  }

  document.addEventListener('DOMContentLoaded', async () => {
      try {
          await initPopup();
      } catch (err) {
          console.error('Popup 初始化失败:', err);
          const messages = document.getElementById('messages');
          if (messages) {
              const div = document.createElement('div');
              div.className = 'welcome-message';
              div.textContent = '初始化失败：' + (err?.message || err);
              messages.appendChild(div);
          }
      }
  });

  async function initPopup() {
      // 在其他代码执行前先初始化marked
      await initMarked();

      const userInput = document.getElementById('userInput');
      const askButton = document.getElementById('askButton');
      const messagesContainer = document.getElementById('messages');
      let isGenerating = false;
      let generatingConvId = null; // 正在生成中的对话 ID
      let currentConvId = null;    // 当前查看的对话 ID

      // 获取当前标签页ID
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      const tabId = tab.id;

      // 初始化悬浮球开关状态
      const toggleBall = document.getElementById('toggleBall');
      const { showFloatingBall = true } = await chrome.storage.sync.get('showFloatingBall');
      toggleBall.checked = showFloatingBall;

      // ===== 对话管理 =====
      const convSelectorBtn = document.getElementById('convSelectorBtn');
      const convDropdown = document.getElementById('convDropdown');
      const convDropdownList = document.getElementById('convDropdownList');
      const convTitleText = document.querySelector('.conv-title-text');

      function formatTime(timestamp) {
          if (!timestamp) return '';
          const diff = Date.now() - timestamp;
          const mins = Math.floor(diff / 60000);
          if (mins < 1) return '刚刚';
          if (mins < 60) return `${mins} 分钟前`;
          const hours = Math.floor(mins / 60);
          if (hours < 24) return `${hours} 小时前`;
          const days = Math.floor(hours / 24);
          if (days < 30) return `${days} 天前`;
          return new Date(timestamp).toLocaleDateString('zh-CN');
      }

      async function refreshConversationList() {
          try {
              const res = await chrome.runtime.sendMessage({ action: 'listConversations', tabId });
              const conversations = res?.conversations || [];
              const activeConv = conversations.find(c => c.isActive) || conversations[0];

              if (activeConv) {
                  convTitleText.textContent = activeConv.title || '新对话';
                  if (!currentConvId) currentConvId = activeConv.id;
              } else {
                  convTitleText.textContent = '新对话';
              }

              convDropdownList.innerHTML = '';
              if (conversations.length === 0) {
                  convDropdownList.innerHTML = '<div class="conv-dropdown-empty">还没有对话，发送消息开始吧</div>';
              } else {
                  conversations.forEach(conv => {
                      const isActive = conv.isActive;
                      const row = document.createElement('div');
                      row.className = 'conv-dropdown-row' + (isActive ? ' active' : '');
                      row.dataset.convId = conv.id;
                      const iconEmoji = isActive ? '💬' : '📝';
                      row.innerHTML = `
                        <div class="conv-row-icon">${iconEmoji}</div>
                        <div class="conv-row-content">
                            <span class="conv-row-title">${escapeHtmlPopup(conv.title || '新对话')}</span>
                            <span class="conv-row-meta">
                                <span>${conv.messageCount || 0} 条</span>
                                <span class="conv-row-meta-dot"></span>
                                <span>${formatTime(conv.updatedAt)}</span>
                            </span>
                        </div>
                        <button class="conv-row-delete" data-conv-id="${conv.id}" title="删除">🗑</button>
                    `;
                      row.addEventListener('click', (e) => {
                          if (e.target.closest('.conv-row-delete')) return;
                          convDropdown.hidden = true;
                          switchToConversation(conv.id);
                      });
                      convDropdownList.appendChild(row);
                  });

                  convDropdownList.querySelectorAll('.conv-row-delete').forEach(btn => {
                      btn.addEventListener('click', async (e) => {
                          e.stopPropagation();
                          const convId = btn.dataset.convId;
                          if (!confirm('确定删除此对话？该操作不可恢复。')) return;
                          await chrome.runtime.sendMessage({ action: 'deleteConversation', tabId, convId });
                          await refreshConversationList();
                          await loadHistory();
                      });
                  });
              }
          } catch (err) {
              console.error('刷新对话列表失败:', err);
          }
      }

      function escapeHtmlPopup(str) {
          const div = document.createElement('div');
          div.textContent = str;
          return div.innerHTML;
      }

      async function switchToConversation(convId) {
          try {
              if (convId) {
                  await chrome.runtime.sendMessage({ action: 'switchConversation', tabId, convId });
              } else {
                  const res = await chrome.runtime.sendMessage({ action: 'createConversation', tabId });
                  convId = res?.conversation?.id;
              }
              currentConvId = convId;
              await loadHistory();
              await refreshConversationList();
              // 如果 AI 正在为其他对话生成，保持 UI 可用
              if (generatingConvId && convId !== generatingConvId) {
                  isGenerating = false;
                  userInput.disabled = false;
                  askButton.disabled = false;
              }
              userInput.focus();
          } catch (err) {
              console.error('切换对话失败:', err);
          }
      }

      convSelectorBtn?.addEventListener('click', (e) => {
          e.stopPropagation();
          convDropdown.hidden = !convDropdown.hidden;
          if (!convDropdown.hidden) refreshConversationList();
      });

      // 下拉头部 + 按钮
      document.getElementById('convDropdownAdd')?.addEventListener('click', (e) => {
          e.stopPropagation();
          convDropdown.hidden = true;
          switchToConversation(null);
      });

      document.addEventListener('click', (e) => {
          if (!convDropdown.hidden && !convDropdown.contains(e.target) && e.target !== convSelectorBtn) {
              convDropdown.hidden = true;
          }
      });

      document.getElementById('newChatBtn')?.addEventListener('click', () => {
          convDropdown.hidden = true;
          switchToConversation(null);
      });

      document.getElementById('refreshBtn')?.addEventListener('click', () => {
          if (!confirm('刷新将重新加载扩展，当前对话已自动保存。确定继续？')) return;
          chrome.runtime.sendMessage({ action: 'reloadExtension' }).catch(() => {});
      });

      // 监听开关变化
      toggleBall.addEventListener('change', async () => {
          await chrome.storage.sync.set({ showFloatingBall: toggleBall.checked });
          // 向content script发送消息以更新悬浮球状态
          const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
          if (tab) {
              chrome.tabs.sendMessage(tab.id, { action: 'toggleFloatingBall' });
          }
      });

      // 加载历史会话
      async function loadHistory() {
          try {
              const response = await chrome.runtime.sendMessage({
                  action: 'getHistory',
                  tabId: tabId
              });

              // 清空现有消息
              messagesContainer.innerHTML = '';

              if (!response || !response.history || response.history.length === 0) {
                  // 没有历史记录时，显示欢迎消息
                  const welcomeDiv = document.createElement('div');
                  welcomeDiv.className = 'welcome-message';
                  welcomeDiv.innerHTML = '<p>👋 你好！我是AI助手，可以帮你理解和分析当前网页的内容。</p>';
                  messagesContainer.appendChild(welcomeDiv);
              } else {
                  // 显示历史消息
                  response.history.forEach(msg => {
                      const messageDiv = document.createElement('div');
                      messageDiv.className = `message ${msg.isUser ? 'user-message' : 'assistant-message'}`;
                      if (msg.isUser) {
                          messageDiv.textContent = msg.content;
                      } else {
                          try {
                              setSafeHTML(messageDiv, markedInstance(msg.content));
                          } catch (error) {
                              console.error('Markdown渲染失败:', error);
                              messageDiv.textContent = msg.content;
                          }
                      }
                      messagesContainer.appendChild(messageDiv);
                  });

                  // 如果正在生成回答，添加加载指示器并连接到流
                  if (response.isGenerating) {
                      isGenerating = true;
                      userInput.disabled = true;
                      askButton.disabled = true;

                      // 添加最后一个用户问题（如果不存在）
                      const lastMessage = response.history[response.history.length - 1];
                      if (!lastMessage || !lastMessage.isUser) {
                          const userQuestion = response.pendingQuestion;
                          if (userQuestion) {
                              const questionDiv = document.createElement('div');
                              questionDiv.className = 'message user-message';
                              questionDiv.textContent = userQuestion;
                              messagesContainer.appendChild(questionDiv);
                          }
                      }

                      // 添加空的回答消息和加载指示器
                      const messageDiv = addMessage('', false);
                      const typingIndicator = addTypingIndicator();

                      // 连接到流
                      const port = chrome.runtime.connect({ name: "answerStream" });
                      let answer = response.currentAnswer || ''; // 使用已生成的部分答案
                      const genConvId = currentConvId; // 重连时绑定当前对话

                      // 如果有已生成的部分答案，立即显示
                      if (answer) {
                          try {
                              setSafeHTML(messageDiv, markedInstance(answer));
                          } catch (error) {
                              console.error('Markdown渲染失败:', error);
                              messageDiv.textContent = answer;
                          }
                      }

                      port.onMessage.addListener(async (msg) => {
                          if (msg.type === 'answer-chunk') {
                              answer += msg.content;
                              try {
                                  setSafeHTML(messageDiv, markedInstance(answer));
                              } catch (error) {
                                  console.error('Markdown渲染失败:', error);
                                  messageDiv.textContent = answer;
                              }
                              messagesContainer.scrollTop = messagesContainer.scrollHeight;
                          } else if (msg.type === 'answer-end') {
                              generatingConvId = null;
                              if (currentConvId === genConvId) {
                                  messageDiv.removeAttribute('data-pending');
                                  isGenerating = false;
                                  userInput.disabled = false;
                                  askButton.disabled = false;
                                  userInput.focus();
                              }
                              typingIndicator.remove();
                              port.disconnect();
                              refreshConversationList();
                          } else if (msg.type === 'error') {
                              generatingConvId = null;
                              if (currentConvId === genConvId) {
                                  messageDiv.remove();
                                  addMessage('发生错误：' + msg.error, false);
                                  isGenerating = false;
                                  userInput.disabled = false;
                                  askButton.disabled = false;
                                  userInput.focus();
                              }
                              typingIndicator.remove();
                              port.disconnect();
                          }
                      });

                      port.onDisconnect.addListener(() => {
                          generatingConvId = null;
                          if (isGenerating && currentConvId === genConvId) {
                              isGenerating = false;
                              userInput.disabled = false;
                              askButton.disabled = false;
                              userInput.focus();
                              const pending = document.querySelector('.message[data-pending="true"]');
                              if (pending) pending.remove();
                              const typing = document.querySelector('.typing-indicator');
                              if (typing) typing.remove();
                          }
                      });

                      // 重新连接到现有的生成流
                      port.postMessage({
                          action: 'reconnectStream',
                          tabId: tabId
                      });
                  }
              }
              messagesContainer.scrollTop = messagesContainer.scrollHeight;
          } catch (error) {
              console.error('加载历史记录失败:', error);
              messagesContainer.innerHTML = `
                <div class="welcome-message">
                    <p>👋 你好！我是AI助手，可以帮你理解和分析当前网页的内容。</p>
                </div>
            `;
          }
      }

      // 保存历史会话
      async function saveHistory() {
          try {
              const messages = Array.from(messagesContainer.children)
                  .filter(el => el.classList.contains('message') && !el.hasAttribute('data-pending'))
                  .map(el => ({
                      content: el.textContent,
                      isUser: el.classList.contains('user-message')
                  }));

              await chrome.runtime.sendMessage({
                  action: 'saveHistory',
                  tabId: tabId,
                  history: messages
              });
          } catch (error) {
              console.error('保存历史记录失败:', error);
          }
      }

      // 检查 URL 是否为 Chrome 受限页面（无法注入 content script）
      function isRestrictedUrl(url) {
          if (!url) return false;
          return /^(chrome|chrome-extension|about|edge|brave):/.test(url)
              || url.startsWith('https://chrome.google.com/webstore/');
      }

      // 检查content script是否已加载
      async function ensureContentScriptLoaded(tabId) {
          // 先检查页面是否可注入，避免无意义的重试
          try {
              const tabInfo = await chrome.tabs.get(tabId);
              if (isRestrictedUrl(tabInfo.url)) {
                  return false; // 受限页面，无法注入
              }
          } catch { /* 获取标签页信息失败，继续尝试 */ }

          try {
              await chrome.tabs.sendMessage(tabId, { action: 'ping' });
              return true;
          } catch (error) {
              // 如果content script未加载，注入它
              try {
                  await chrome.scripting.executeScript({
                      target: { tabId: tabId },
                      files: ['content.js']
                  });
                  // 等待content script初始化
                  await new Promise(resolve => setTimeout(resolve, 100));
                  return true;
              } catch (error) {
                  console.error('Failed to inject content script:', error);
                  return false;
              }
          }
      }

      // 获取页面内容的函数，包含重试逻辑
      async function getPageContent(tab, maxRetries = 3) {
          for (let i = 0; i < maxRetries; i++) {
              try {
                  // 保content script已加载
                  const ok = await ensureContentScriptLoaded(tab.id);
                  if (!ok) throw new Error('当前页面不支持扩展功能，请切换到普通网页');

                  // 尝试获取页面内容
                  const response = await chrome.tabs.sendMessage(tab.id, { action: 'getPageContent' });
                  return response.content;
              } catch (error) {
                  if (error.message.includes('当前页面不支持')) throw error;
                  if (i === maxRetries - 1) {
                      throw new Error('无法获取页面内容，请刷新页面后重试');
                  }
                  // 等待一段时间后重试
                  await new Promise(resolve => setTimeout(resolve, 100 * (i + 1)));
              }
          }
      }

      // 添加消息到聊天界面
      function addMessage(content, isUser = false) {
          const messageDiv = document.createElement('div');
          messageDiv.className = `message ${isUser ? 'user-message' : 'assistant-message'}`;

          if (!isUser && content === '') {
              messageDiv.setAttribute('data-pending', 'true');
          } else {
              if (isUser) {
                  messageDiv.textContent = content;
              } else {
                  try {
                      setSafeHTML(messageDiv, markedInstance(content));
                  } catch (error) {
                      console.error('Markdown渲染失败:', error);
                      messageDiv.textContent = content;
                  }
              }
          }

          messagesContainer.appendChild(messageDiv);
          messagesContainer.scrollTop = messagesContainer.scrollHeight;

          if (content !== '' || isUser) {
              saveHistory();
          }

          return messageDiv;
      }

      // 添加打字指示器
      function addTypingIndicator() {
          const indicatorDiv = document.createElement('div');
          indicatorDiv.className = 'message assistant-message typing-indicator';
          indicatorDiv.innerHTML = '<span></span><span></span><span></span>';
          messagesContainer.appendChild(indicatorDiv);
          messagesContainer.scrollTop = messagesContainer.scrollHeight;
          return indicatorDiv;
      }

      // 处理用户输入
      async function handleUserInput() {
          if (isGenerating) return;

          const question = userInput.value.trim();
          if (!question) return;

          // 禁用输入和发送按钮
          isGenerating = true;
          generatingConvId = currentConvId;
          userInput.disabled = true;
          askButton.disabled = true;
          userInput.value = '';
          const genConvId = generatingConvId;

          try {
              // 从content script获取网页内容
              const pageContent = await getPageContent(tab);

              // 先添加用户消息
              addMessage(question, true);

              // 添加空的回答消息和打字指示器
              const messageDiv = addMessage('', false);
              const typingIndicator = addTypingIndicator();

              // 开始监听答案更新
              const port = chrome.runtime.connect({ name: "answerStream" });
              let answer = '';

              port.onMessage.addListener(async (msg) => {
                  if (msg.type === 'answer-chunk') {
                      // 流式更新答案
                      answer += msg.content;
                      try {
                          setSafeHTML(messageDiv, markedInstance(answer));
                      } catch (error) {
                          console.error('Markdown渲染失败:', error);
                          messageDiv.textContent = answer;
                      }
                      messagesContainer.scrollTop = messagesContainer.scrollHeight;
                  } else if (msg.type === 'answer-end') {
                      // 答案生成完成
                      generatingConvId = null;
                      if (currentConvId === genConvId) {
                          messageDiv.removeAttribute('data-pending');
                          isGenerating = false;
                          userInput.disabled = false;
                          askButton.disabled = false;
                          userInput.focus();
                      }
                      typingIndicator.remove();
                      port.disconnect();
                      refreshConversationList();
                  } else if (msg.type === 'error') {
                      generatingConvId = null;
                      if (currentConvId === genConvId) {
                          messageDiv.remove();
                          addMessage('发生错误：' + msg.error, false);
                          isGenerating = false;
                          userInput.disabled = false;
                          askButton.disabled = false;
                          userInput.focus();
                      }
                      typingIndicator.remove();
                      port.disconnect();
                  }
              });

              port.onDisconnect.addListener(() => {
                  generatingConvId = null;
                  if (isGenerating && currentConvId === genConvId) {
                      isGenerating = false;
                      userInput.disabled = false;
                      askButton.disabled = false;
                      userInput.focus();
                      const pending = document.querySelector('.message[data-pending="true"]');
                      if (pending) pending.remove();
                      const typing = document.querySelector('.typing-indicator');
                      if (typing) typing.remove();
                  }
              });

              // 发送生成请求到background
              port.postMessage({
                  action: 'generateAnswer',
                  tabId: tabId,
                  convId: genConvId,
                  pageContent: pageContent,
                  question: question
              });

          } catch (error) {
              addMessage('发生错误：' + error.message, false);
              isGenerating = false;
              userInput.disabled = false;
              askButton.disabled = false;
              userInput.focus();
          }
      }

      // 发送按钮点击事件
      askButton.addEventListener('click', handleUserInput);

      // 输入框回车事件（Shift+Enter换行）
      userInput.addEventListener('keydown', (e) => {
          if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault();
              handleUserInput();
          }
      });

      // 自动调整输入框高度
      userInput.addEventListener('input', () => {
          userInput.style.height = 'auto';
          userInput.style.height = Math.min(userInput.scrollHeight, 100) + 'px';
      });

      // 清空对话
      document.getElementById('clearChatBtn')?.addEventListener('click', async () => {
          if (!confirm('确定要清空当前对话吗？')) return;
          await chrome.runtime.sendMessage({ action: 'clearHistory', tabId });
          messagesContainer.innerHTML = '';
          const welcomeDiv = document.createElement('div');
          welcomeDiv.className = 'welcome-message';
          welcomeDiv.innerHTML = '<p>👋 你好！我是AI助手，可以帮你理解和分析当前网页的内容。</p>';
          messagesContainer.appendChild(welcomeDiv);
      });

      // 导出对话
      document.getElementById('exportChatBtn')?.addEventListener('click', async () => {
          const response = await chrome.runtime.sendMessage({ action: 'getHistory', tabId });
          const history = response?.history || [];
          if (!history.length) {
              alert('暂无对话可导出');
              return;
          }
          const lines = [`# WebChat 对话导出`, `> ${tab.title || ''}`, `> ${tab.url || ''}`, ''];
          history.forEach(msg => {
              const who = msg.isUser ? '🙋 用户' : '🤖 助手';
              const content = msg.markdownContent || msg.content || '';
              lines.push(`## ${who}`);
              lines.push('');
              lines.push(content);
              lines.push('');
          });
          const blob = new Blob([lines.join('\n')], { type: 'text/markdown;charset=utf-8' });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `webchat-${Date.now()}.md`;
          a.click();
          setTimeout(() => URL.revokeObjectURL(url), 1000);
      });

      // 打开设置页
      document.getElementById('openOptionsBtn')?.addEventListener('click', () => {
          chrome.runtime.openOptionsPage();
      });

      // 初始化时加载历史会话
      await loadHistory();
      await refreshConversationList();
  }

})();
