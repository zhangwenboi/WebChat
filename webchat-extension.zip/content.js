(function () {
  'use strict';

  const scriptRel = 'modulepreload';const assetsURL = function(dep) { return "/"+dep };const seen = {};const __vitePreload = function preload(baseModule, deps, importerUrl) {
    let promise = Promise.resolve();
    if (false              && deps && deps.length > 0) {
      let allSettled2 = function(promises) {
        return Promise.all(
          promises.map(
            (p) => Promise.resolve(p).then(
              (value) => ({ status: "fulfilled", value }),
              (reason) => ({ status: "rejected", reason })
            )
          )
        );
      };
      document.getElementsByTagName("link");
      const cspNonceMeta = document.querySelector(
        "meta[property=csp-nonce]"
      );
      const cspNonce = cspNonceMeta?.nonce || cspNonceMeta?.getAttribute("nonce");
      promise = allSettled2(
        deps.map((dep) => {
          dep = assetsURL(dep);
          if (dep in seen) return;
          seen[dep] = true;
          const isCss = dep.endsWith(".css");
          const cssSelector = isCss ? '[rel="stylesheet"]' : "";
          if (document.querySelector(`link[href="${dep}"]${cssSelector}`)) {
            return;
          }
          const link = document.createElement("link");
          link.rel = isCss ? "stylesheet" : scriptRel;
          if (!isCss) {
            link.as = "script";
          }
          link.crossOrigin = "";
          link.href = dep;
          if (cspNonce) {
            link.setAttribute("nonce", cspNonce);
          }
          document.head.appendChild(link);
          if (isCss) {
            return new Promise((res, rej) => {
              link.addEventListener("load", res);
              link.addEventListener(
                "error",
                () => rej(new Error(`Unable to preload CSS for ${dep}`))
              );
            });
          }
        })
      );
    }
    function handlePreloadError(err) {
      const e = new Event("vite:preloadError", {
        cancelable: true
      });
      e.payload = err;
      window.dispatchEvent(e);
      if (!e.defaultPrevented) {
        throw err;
      }
    }
    return promise.then((res) => {
      for (const item of res || []) {
        if (item.status !== "rejected") continue;
        handlePreloadError(item.reason);
      }
      return baseModule().catch(handlePreloadError);
    });
  };

  /**
   * 网页内容抽取
   *  - 优先抽取 <main> / <article>，回退到 body
   *  - 移除 script/style/header/nav/footer/aside/广告等噪声
   *  - 保留标题/列表/段落的基本结构（以换行分隔）
   *  - 按字符数截断，避免 prompt 超限
   *  - 用户有选区时优先使用选区内容
   */

  const NOISE_SELECTORS = [
    'script', 'style', 'noscript', 'template', 'link[rel="stylesheet"]',
    'header', 'nav', 'footer', 'aside',
    '[role="navigation"]', '[role="banner"]', '[role="contentinfo"]',
    '.ad', '.ads', '.advert', '[class*="advertisement"]',
    '[aria-hidden="true"]'
  ];

  const MAX_CONTENT_CHARS = 12000;

  function extractStructuredText(root) {
    if (!root) return '';

    const lines = [];

    const blockSep = (text) => {
      const t = text.trim();
      if (t) lines.push(t);
    };

    const visit = (node) => {
      if (node.nodeType === 3) {
        // text node
        const text = node.nodeValue.replace(/\s+/g, ' ');
        if (text.trim()) lines.push(text);
        return;
      }
      if (node.nodeType !== 1) return;

      const tag = node.tagName.toLowerCase();
      if (['script', 'style', 'noscript', 'template'].includes(tag)) return;

      if (/^h[1-6]$/.test(tag)) {
        const level = parseInt(tag[1], 10);
        blockSep('\n' + '#'.repeat(level) + ' ' + node.textContent.trim() + '\n');
        return;
      }

      if (tag === 'li') {
        blockSep('- ' + node.textContent.trim());
        return;
      }

      if (['p', 'br', 'div', 'section', 'article', 'tr', 'pre', 'blockquote'].includes(tag)) {
        const before = lines.length;
        for (const child of node.childNodes) visit(child);
        // 段落分隔符
        if (lines.length > before) lines.push('');
        return;
      }

      for (const child of node.childNodes) visit(child);
    };

    visit(root);

    return lines
      .join('\n')
      .replace(/\n{3,}/g, '\n\n')
      .trim();
  }

  /**
   * 抽取页面主要内容
   * @param {object} opts
   * @param {boolean} opts.preferSelection 是否优先用选区
   * @param {number} opts.maxChars 最大字符数（默认 12000）
   */
  function parseWebContent(opts = {}) {
    const { preferSelection = true, maxChars = MAX_CONTENT_CHARS } = opts;

    // 1. 选区优先
    if (preferSelection) {
      const sel = window.getSelection?.();
      if (sel && sel.toString().trim().length > 30) {
        const selText = sel.toString().replace(/\s+/g, ' ').trim();
        return truncate(selText, maxChars);
      }
    }

    // 2. 克隆并清理噪声
    const clone = document.body?.cloneNode(true);
    if (!clone) return '';

    NOISE_SELECTORS.forEach(sel => {
      clone.querySelectorAll(sel).forEach(el => el.remove());
    });

    // 3. 优先 main/article
    const main = clone.querySelector('main') || clone.querySelector('article') || clone;

    const text = extractStructuredText(main);
    return truncate(text, maxChars);
  }

  function truncate(text, max) {
    if (!text || text.length <= max) return text;
    return text.slice(0, max) + `\n\n[内容已截断，原文共 ${text.length} 字]`;
  }

  // 顶部右侧轻量提示，以及扩展失效时的全局错误兜底

  const NOTIFICATION_STYLE = `
    position: fixed;
    right: 20px;
    top: 20px;
    padding: 10px 20px;
    background: rgba(0, 0, 0, 0.8);
    color: white;
    border-radius: 4px;
    z-index: 10000;
    font-size: 14px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
`;

  // 显示一条 3s 自动消失的通知，重复触发时会替换上一条
  function showNotification(message, { animated = true } = {}) {
      const existing = document.querySelector('.extension-notification');
      if (existing) existing.remove();

      const notification = document.createElement('div');
      notification.className = 'extension-notification';
      notification.style.cssText = NOTIFICATION_STYLE + (animated ? 'animation: fadeInOut 3s ease forwards;' : '');
      notification.textContent = message;
      document.body.appendChild(notification);

      setTimeout(() => notification.remove(), 3000);
      return notification;
  }

  // 拦截 Extension context invalidated 类错误，提示用户刷新页面，避免控制台噪音
  function installGlobalErrorHandlers() {
      const isContextInvalidated = (err) =>
          err && err.message && err.message.includes('Extension context invalidated');

      window.addEventListener('error', (event) => {
          if (isContextInvalidated(event.error)) {
              event.preventDefault();
              showNotification('扩展已更新，请刷新页面以继续使用', { animated: false });
          }
      });

      window.addEventListener('unhandledrejection', (event) => {
          if (isContextInvalidated(event.reason)) {
              event.preventDefault();
          }
      });
  }

  /**
   * 小红书合集工具箱
   *
   * 当浏览小红书合集页面（/board/*）时：
   *   1. 提取合集名称 + 笔记作者的用户 ID → 一键复制
   *   2. 提取所有笔记封面图 + 标题 → 一键下载（文件名 = 笔记标题）
   *
   * 复制格式：
   *   合集名
   *   @user_id_1
   *   @user_id_2
   *   ...
   */

  // ═══════════════════════════════════════════════════════════
  // 工具函数
  // ═══════════════════════════════════════════════════════════

  /** 从 user profile URL 中提取用户 ID */
  function extractUserId(url) {
    const match = url.match(/\/user\/profile\/([^?&#]+)/);
    return match ? match[1] : null;
  }

  /** 从页面提取合集名称 */
  function extractBoardName() {
    const nameEl = document.querySelector('.board-info .name');
    if (nameEl) {
      return nameEl.textContent.trim();
    }
    // 备选：从标题或 breadcrumb 提取
    const titleEl = document.querySelector('title');
    if (titleEl) {
      const title = titleEl.textContent.trim();
      // 尝试从标题中提取，例如 "黑色拼贴 - 小红书"
      const m = title.match(/^(.+?)\s*[-–—|]\s*小红书/);
      if (m) return m[1];
    }
    return '合集';
  }

  /** 从页面提取所有唯一的用户 ID（仅笔记作者，排除合集创建者） */
  function extractUserIds() {
    const links = document.querySelectorAll('.note-item a[href*="/user/profile/"]');
    const ids = new Set();
    for (const link of links) {
      const id = extractUserId(link.getAttribute('href'));
      if (id) ids.add(id);
    }
    return [...ids];
  }

  /** 生成复制文本 */
  function formatOutput(boardName, userIds) {
    const lines = [boardName];
    for (const id of userIds) {
      lines.push(`@${id}`);
    }
    // 最后一行末尾只保留一个空格，无换行
    return lines.join('\n') + ' ';
  }

  /** 提取所有笔记的封面图 URL 与标题 */
  function extractCoverItems() {
    const items = [];
    const sections = document.querySelectorAll('.note-item');
    for (const sec of sections) {
      const img = sec.querySelector('.cover img');
      const titleEl = sec.querySelector('.footer .title span');
      const url = img?.getAttribute('src') || img?.currentSrc || '';
      const title = titleEl?.textContent?.trim() || '';
      if (url && title) {
        items.push({ url, title });
      }
    }
    return items;
  }

  /** 将标题转为合法文件名（保留中文，去掉非法字符，限长 80 字） */
  function sanitizeFilename(title) {
    return title
      .replace(/[\\/:*?"<>|]/g, '')
      .replace(/[\r\n\t]+/g, ' ')
      .trim()
      .slice(0, 80);
  }

  // ═══════════════════════════════════════════════════════════
  // 按钮 UI
  // ═══════════════════════════════════════════════════════════

  const BUTTON_ID = 'xhs-board-extract-btn';

  /** 当前按钮关联的数据（SPA 切换合集时更新） */
  let currentBoardName = '';
  let currentUserIds = [];

  /** 注入或更新按钮 */
  function upsertButton(boardName, userIds) {
    currentBoardName = boardName;
    currentUserIds = userIds;

    let btn = document.getElementById(BUTTON_ID);

    if (!btn) {
      btn = document.createElement('button');
      btn.id = BUTTON_ID;
      btn.title = '将合集用户ID复制到剪贴板';

      Object.assign(btn.style, {
        position: 'fixed',
        bottom: '20px',
        right: '20px',
        zIndex: '99999',
        padding: '10px 20px',
        background: '#ff2442',
        color: '#fff',
        border: 'none',
        borderRadius: '20px',
        fontSize: '14px',
        fontWeight: '600',
        cursor: 'pointer',
        boxShadow: '0 4px 12px rgba(255,36,66,0.35)',
        transition: 'transform 0.15s, box-shadow 0.15s',
        fontFamily: 'inherit'
      });

      btn.addEventListener('mouseenter', () => {
        btn.style.transform = 'scale(1.05)';
        btn.style.boxShadow = '0 6px 18px rgba(255,36,66,0.45)';
      });
      btn.addEventListener('mouseleave', () => {
        btn.style.transform = 'scale(1)';
        btn.style.boxShadow = '0 4px 12px rgba(255,36,66,0.35)';
      });

      btn.addEventListener('click', async () => {
        const text = formatOutput(currentBoardName, currentUserIds);
        try {
          await navigator.clipboard.writeText(text);
          btn.textContent = '✓ 已复制!';
          btn.style.background = '#2ecc71';
          btn.style.boxShadow = '0 4px 12px rgba(46,204,113,0.35)';
          setTimeout(() => {
            btn.textContent = `复制 ${currentUserIds.length} 个用户ID`;
            btn.style.background = '#ff2442';
            btn.style.boxShadow = '0 4px 12px rgba(255,36,66,0.35)';
          }, 1500);
        } catch (err) {
          // 降级：用 textarea 兜底
          const ta = document.createElement('textarea');
          ta.value = text;
          ta.style.position = 'fixed';
          ta.style.left = '-9999px';
          document.body.appendChild(ta);
          ta.select();
          document.execCommand('copy');
          document.body.removeChild(ta);
          btn.textContent = '✓ 已复制!';
          setTimeout(() => {
            btn.textContent = `复制 ${currentUserIds.length} 个用户ID`;
          }, 1500);
        }
      });

      document.body.appendChild(btn);
    }

    // 更新按钮文案
    btn.textContent = `复制 ${userIds.length} 个用户ID`;
    // 如果正在显示「已复制」，不覆盖
    if (btn.style.background === 'rgb(46, 204, 113)') {
      btn.style.background = '#ff2442';
    }
  }

  // ═══════════════════════════════════════════════════════════
  // 下载封面按钮 + 格式选择
  // ═══════════════════════════════════════════════════════════

  const DOWNLOAD_CONTAINER_ID = 'xhs-board-download-ctr';
  const DOWNLOAD_BTN_ID = 'xhs-board-download-btn';
  const FORMAT_SELECT_ID = 'xhs-board-format-select';
  let currentCoverItems = [];
  let currentFormat = 'webp';

  const SELECT_STYLE = `
  border: none;
  border-radius: 14px;
  padding: 6px 10px;
  font-size: 13px;
  font-weight: 600;
  font-family: inherit;
  background: rgba(24,144,255,0.12);
  color: #1890ff;
  cursor: pointer;
  outline: none;
  appearance: none;
  -webkit-appearance: none;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='6'%3E%3Cpath d='M0 0l5 6 5-6z' fill='%231890ff'/%3E%3C/svg%3E");
  background-repeat: no-repeat;
  background-position: right 6px center;
  padding-right: 22px;
`;

  function upsertDownloadButton(coverItems) {
    currentCoverItems = coverItems;

    let ctr = document.getElementById(DOWNLOAD_CONTAINER_ID);

    if (!ctr) {
      ctr = document.createElement('div');
      ctr.id = DOWNLOAD_CONTAINER_ID;
      Object.assign(ctr.style, {
        position: 'fixed',
        bottom: '70px',
        right: '20px',
        zIndex: '99999',
        display: 'flex',
        alignItems: 'center',
        gap: '8px'
      });

      // 格式选择器
      const select = document.createElement('select');
      select.id = FORMAT_SELECT_ID;
      select.title = '选择下载格式';
      select.style.cssText = SELECT_STYLE;
      select.innerHTML = '<option value="webp">WebP</option><option value="png">PNG</option>';
      select.addEventListener('change', () => {
        currentFormat = select.value;
      });

      // 下载按钮
      const btn = document.createElement('button');
      btn.id = DOWNLOAD_BTN_ID;
      btn.title = '下载当前合集所有封面图';
      Object.assign(btn.style, {
        padding: '10px 20px',
        background: '#1890ff',
        color: '#fff',
        border: 'none',
        borderRadius: '20px',
        fontSize: '14px',
        fontWeight: '600',
        cursor: 'pointer',
        boxShadow: '0 4px 12px rgba(24,144,255,0.35)',
        transition: 'transform 0.15s, box-shadow 0.15s',
        fontFamily: 'inherit'
      });

      [btn, select].forEach(el => {
        el.addEventListener('mouseenter', () => {
          btn.style.transform = 'scale(1.05)';
          btn.style.boxShadow = '0 6px 18px rgba(24,144,255,0.45)';
        });
        el.addEventListener('mouseleave', () => {
          btn.style.transform = 'scale(1)';
          btn.style.boxShadow = '0 4px 12px rgba(24,144,255,0.35)';
        });
      });

      btn.addEventListener('click', () => {
        downloadAllCovers(currentCoverItems, btn, select);
      });

      ctr.appendChild(select);
      ctr.appendChild(btn);
      document.body.appendChild(ctr);
    }

    const btn = document.getElementById(DOWNLOAD_BTN_ID);
    btn.textContent = `下载 ${coverItems.length} 张封面`;
  }

  /** 获取图片 data URL：优先读浏览器缓存（force-cache），失败则注入页面主世界 fetch */
  async function fetchImageAsDataUrl(url) {
    // 方案 A：从浏览器缓存读取（图片已在页面展示，缓存中一定有）
    try {
      const resp = await fetch(url, { cache: 'force-cache' });
      if (resp.ok) {
        const blob = await resp.blob();
        return await new Promise((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => resolve(reader.result);
          reader.onerror = () => reject(new Error('读取图片数据失败'));
          reader.readAsDataURL(blob);
        });
      }
    } catch (_) { /* 降级到方案 B */ }

    // 方案 B：注入页面主世界脚本发起 fetch（携带天然 Referer + Cookie）
    return new Promise((resolve, reject) => {
      const msgId = 'xhs_img_' + Math.random().toString(36).slice(2);

      const handler = (e) => {
        if (e.data?.id !== msgId) return;
        window.removeEventListener('message', handler);
        if (e.data.error) reject(new Error(e.data.error));
        else resolve(e.data.dataUrl);
      };
      window.addEventListener('message', handler);

      const code =
        `(function(){var i=${JSON.stringify(msgId)};fetch(${JSON.stringify(url)})` +
        `.then(function(r){return r.blob()})` +
        `.then(function(b){var r=new FileReader();r.onload=function(){window.postMessage({id:i,dataUrl:r.result},'*')};r.onerror=function(){window.postMessage({id:i,error:'read failed'},'*')};r.readAsDataURL(b)})` +
        `.catch(function(e){window.postMessage({id:i,error:e.message},'*')})})();`;

      const script = document.createElement('script');
      script.textContent = code;
      document.documentElement.appendChild(script);
      script.remove();

      setTimeout(() => {
        window.removeEventListener('message', handler);
        reject(new Error('fetch timeout'));
      }, 15000);
    });
  }

  /** 将图片 data URL 转为 PNG 格式（canvas 重编码，兼容不支持 WebP 的手机） */
  function convertDataUrlToPng(dataUrl) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = img.naturalWidth;
        canvas.height = img.naturalHeight;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0);
        resolve(canvas.toDataURL('image/png'));
      };
      img.onerror = () => reject(new Error('图片加载失败，无法转换格式'));
      img.src = dataUrl;
    });
  }

  /** 通过 background 逐张下载封面 */
  async function downloadAllCovers(coverItems, btn, select) {
    const total = coverItems.length;
    const fmt = select ? select.value : currentFormat;
    const ext = fmt === 'png' ? '.png' : '.webp';
    let done = 0;
    btn.textContent = `0 / ${total}`;
    btn.style.background = '#fa8c16';
    select && (select.disabled = true);

    for (const item of coverItems) {
      const filename = sanitizeFilename(item.title) + ext;
      try {
        let dataUrl = await fetchImageAsDataUrl(item.url);
        // 如果选了 PNG，通过 canvas 转换格式
        if (fmt === 'png') {
          dataUrl = await convertDataUrlToPng(dataUrl);
        }
        await new Promise((resolve, reject) => {
          chrome.runtime.sendMessage(
            { action: 'downloadImage', dataUrl, filename },
            (resp) => {
              if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
              else if (resp?.ok) resolve(resp);
              else reject(new Error(resp?.error || '下载失败'));
            }
          );
        });
      } catch (err) {
        console.warn(`下载封面失败: ${filename}`, err);
      }
      done++;
      btn.textContent = `${done} / ${total}`;
    }

    select && (select.disabled = false);
    // 完成提示
    btn.textContent = `✓ 已下载 ${done} 张`;
    btn.style.background = '#2ecc71';
    btn.style.boxShadow = '0 4px 12px rgba(46,204,113,0.35)';
    setTimeout(() => {
      btn.textContent = `下载 ${currentCoverItems.length} 张封面`;
      btn.style.background = '#1890ff';
      btn.style.boxShadow = '0 4px 12px rgba(24,144,255,0.35)';
    }, 2000);
  }

  // ═══════════════════════════════════════════════════════════
  // 入口
  // ═══════════════════════════════════════════════════════════

  /** 判断当前页面是否为小红书合集页 */
  function isBoardPage() {
    const host = location.hostname;
    const path = location.pathname;
    return (
      (host === 'www.xiaohongshu.com' || host.endsWith('.xiaohongshu.com')) &&
      path.startsWith('/board/')
    );
  }

  /** 初始化：等待页面内容加载完成后提取数据并注入按钮 */
  function init() {
    if (!isBoardPage()) return;

    // 等待合集内容区出现（feed 容器），最多等 8 秒
    const maxWait = 8000;
    const start = Date.now();

    function tryExtract() {
      const userIds = extractUserIds();
      const coverItems = extractCoverItems();
      if (userIds.length > 0 || coverItems.length > 0) {
        const boardName = extractBoardName();
        if (userIds.length > 0) upsertButton(boardName, userIds);
        if (coverItems.length > 0) upsertDownloadButton(coverItems);
        if (userIds.length > 0 || coverItems.length > 0) return;
      }
      if (Date.now() - start < maxWait) {
        // 页面可能是动态渲染的，用 MutationObserver 或轮询等待
        setTimeout(tryExtract, 500);
      }
    }

    // 先检查 DOM 是否已就绪
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => {
        // 再等一小会儿让 Vue 渲染
        setTimeout(tryExtract, 1000);
      });
    } else {
      tryExtract();
    }

    // MutationObserver 持续监听 DOM 变化：
    //   - 初次加载时注入按钮
    //   - 切换合集（SPA 路由）后自动更新按钮数据
    let pendingUpdate = null;
    const observer = new MutationObserver(() => {
      if (pendingUpdate) return; // 防抖
      pendingUpdate = requestAnimationFrame(() => {
        pendingUpdate = null;
        const userIds = extractUserIds();
        const coverItems = extractCoverItems();
        const boardName = extractBoardName();
        if (userIds.length > 0) upsertButton(boardName, userIds);
        if (coverItems.length > 0) upsertDownloadButton(coverItems);
      });
    });

    // body 出现后挂 observer，长期运行不自动断开
    const bodyCheck = setInterval(() => {
      if (document.body) {
        clearInterval(bodyCheck);
        observer.observe(document.body, { childList: true, subtree: true });
      }
    }, 200);
  }

  init();

  function getPageContent() {
      return parseWebContent({ preferSelection: true });
  }

  installGlobalErrorHandlers();

  // sidepanel / background 通过 sendMessage 调用以下能力：
  //   ping              - 健康检查
  //   getPageContent    - 提取当前页面正文
  //   openScriptPanel   - 打开脚本自动化面板
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
      try {
          if (request.action === 'ping') {
              sendResponse({ status: 'ok' });
          } else if (request.action === 'getPageContent') {
              sendResponse({ content: getPageContent() });
          } else if (request.action === 'openScriptPanel') {
              __vitePreload(() => Promise.resolve().then(() => panel$1),false             ?__VITE_PRELOAD__:void 0).then(mod => {
                  mod.openPanel();
                  sendResponse({ status: 'ok' });
              }).catch(err => {
                  sendResponse({ error: err.message });
              });
              return true; // 异步响应
          }
      } catch (error) {
          console.error('处理消息时出错:', error);
          sendResponse({ error: error.message });
      }
      return true;
  });

  // License: MIT
  // Author: Anton Medvedev <anton@medv.io>
  // Source: https://github.com/antonmedv/finder
  const acceptedAttrNames = new Set(['role', 'name', 'aria-label', 'rel', 'href']);
  /** Check if attribute name and value are word-like. */
  function attr(name, value) {
      let nameIsOk = acceptedAttrNames.has(name);
      nameIsOk ||= name.startsWith('data-') && wordLike(name);
      let valueIsOk = wordLike(value) && value.length < 100;
      valueIsOk ||= value.startsWith('#') && wordLike(value.slice(1));
      return nameIsOk && valueIsOk;
  }
  /** Check if id name is word-like. */
  function idName(name) {
      return wordLike(name);
  }
  /** Check if class name is word-like. */
  function className(name) {
      return wordLike(name);
  }
  /** Check if tag name is word-like. */
  function tagName(name) {
      return true;
  }
  /** Finds unique CSS selectors for the given element. */
  function finder(input, options) {
      if (input.nodeType !== Node.ELEMENT_NODE) {
          throw new Error(`Can't generate CSS selector for non-element node type.`);
      }
      if (input.tagName.toLowerCase() === 'html') {
          return 'html';
      }
      const defaults = {
          root: document.body,
          idName: idName,
          className: className,
          tagName: tagName,
          attr: attr,
          timeoutMs: 1000,
          seedMinLength: 3,
          optimizedMinLength: 2,
          maxNumberOfPathChecks: Infinity,
      };
      const startTime = new Date();
      const config = { ...defaults, ...options };
      const rootDocument = findRootDocument(config.root, defaults);
      let foundPath;
      let count = 0;
      for (const candidate of search(input, config, rootDocument)) {
          const elapsedTimeMs = new Date().getTime() - startTime.getTime();
          if (elapsedTimeMs > config.timeoutMs ||
              count >= config.maxNumberOfPathChecks) {
              const fPath = fallback(input, rootDocument);
              if (!fPath) {
                  throw new Error(`Timeout: Can't find a unique selector after ${config.timeoutMs}ms`);
              }
              return selector(fPath);
          }
          count++;
          if (unique(candidate, rootDocument)) {
              foundPath = candidate;
              break;
          }
      }
      if (!foundPath) {
          throw new Error(`Selector was not found.`);
      }
      const optimized = [
          ...optimize(foundPath, input, config, rootDocument, startTime),
      ];
      optimized.sort(byPenalty);
      if (optimized.length > 0) {
          return selector(optimized[0]);
      }
      return selector(foundPath);
  }
  function* search(input, config, rootDocument) {
      const stack = [];
      let paths = [];
      let current = input;
      let i = 0;
      while (current && current !== rootDocument) {
          const level = tie(current, config);
          for (const node of level) {
              node.level = i;
          }
          stack.push(level);
          current = current.parentElement;
          i++;
          paths.push(...combinations(stack));
          if (i >= config.seedMinLength) {
              paths.sort(byPenalty);
              for (const candidate of paths) {
                  yield candidate;
              }
              paths = [];
          }
      }
      paths.sort(byPenalty);
      for (const candidate of paths) {
          yield candidate;
      }
  }
  function wordLike(name) {
      if (/^[a-z\-]{3,}$/i.test(name)) {
          const words = name.split(/-|[A-Z]/);
          for (const word of words) {
              if (word.length <= 2) {
                  return false;
              }
              if (/[^aeiou]{4,}/i.test(word)) {
                  return false;
              }
          }
          return true;
      }
      return false;
  }
  function tie(element, config) {
      const level = [];
      const elementId = element.getAttribute('id');
      if (elementId && config.idName(elementId)) {
          level.push({
              name: '#' + CSS.escape(elementId),
              penalty: 0,
          });
      }
      for (let i = 0; i < element.classList.length; i++) {
          const name = element.classList[i];
          if (config.className(name)) {
              level.push({
                  name: '.' + CSS.escape(name),
                  penalty: 1,
              });
          }
      }
      for (let i = 0; i < element.attributes.length; i++) {
          const attr = element.attributes[i];
          if (config.attr(attr.name, attr.value)) {
              level.push({
                  name: `[${CSS.escape(attr.name)}="${CSS.escape(attr.value)}"]`,
                  penalty: 2,
              });
          }
      }
      const tagName = element.tagName.toLowerCase();
      if (config.tagName(tagName)) {
          level.push({
              name: tagName,
              penalty: 5,
          });
          const index = indexOf(element, tagName);
          if (index !== undefined) {
              level.push({
                  name: nthOfType(tagName, index),
                  penalty: 10,
              });
          }
      }
      const nth = indexOf(element);
      if (nth !== undefined) {
          level.push({
              name: nthChild(tagName, nth),
              penalty: 50,
          });
      }
      return level;
  }
  function selector(path) {
      let node = path[0];
      let query = node.name;
      for (let i = 1; i < path.length; i++) {
          const level = path[i].level || 0;
          if (node.level === level - 1) {
              query = `${path[i].name} > ${query}`;
          }
          else {
              query = `${path[i].name} ${query}`;
          }
          node = path[i];
      }
      return query;
  }
  function penalty(path) {
      return path.map((node) => node.penalty).reduce((acc, i) => acc + i, 0);
  }
  function byPenalty(a, b) {
      return penalty(a) - penalty(b);
  }
  function indexOf(input, tagName) {
      const parent = input.parentNode;
      if (!parent) {
          return undefined;
      }
      let child = parent.firstChild;
      if (!child) {
          return undefined;
      }
      let i = 0;
      while (child) {
          if (child.nodeType === Node.ELEMENT_NODE &&
              (tagName === undefined ||
                  child.tagName.toLowerCase() === tagName)) {
              i++;
          }
          if (child === input) {
              break;
          }
          child = child.nextSibling;
      }
      return i;
  }
  function fallback(input, rootDocument) {
      let i = 0;
      let current = input;
      const path = [];
      while (current && current !== rootDocument) {
          const tagName = current.tagName.toLowerCase();
          const index = indexOf(current, tagName);
          if (index === undefined) {
              return;
          }
          path.push({
              name: nthOfType(tagName, index),
              penalty: NaN,
              level: i,
          });
          current = current.parentElement;
          i++;
      }
      if (unique(path, rootDocument)) {
          return path;
      }
  }
  function nthChild(tagName, index) {
      if (tagName === 'html') {
          return 'html';
      }
      return `${tagName}:nth-child(${index})`;
  }
  function nthOfType(tagName, index) {
      if (tagName === 'html') {
          return 'html';
      }
      return `${tagName}:nth-of-type(${index})`;
  }
  function* combinations(stack, path = []) {
      if (stack.length > 0) {
          for (let node of stack[0]) {
              yield* combinations(stack.slice(1, stack.length), path.concat(node));
          }
      }
      else {
          yield path;
      }
  }
  function findRootDocument(rootNode, defaults) {
      if (rootNode.nodeType === Node.DOCUMENT_NODE) {
          return rootNode;
      }
      if (rootNode === defaults.root) {
          return rootNode.ownerDocument;
      }
      return rootNode;
  }
  function unique(path, rootDocument) {
      const css = selector(path);
      switch (rootDocument.querySelectorAll(css).length) {
          case 0:
              throw new Error(`Can't select any node with this selector: ${css}`);
          case 1:
              return true;
          default:
              return false;
      }
  }
  function* optimize(path, input, config, rootDocument, startTime) {
      if (path.length > 2 && path.length > config.optimizedMinLength) {
          for (let i = 1; i < path.length - 1; i++) {
              const elapsedTimeMs = new Date().getTime() - startTime.getTime();
              if (elapsedTimeMs > config.timeoutMs) {
                  return;
              }
              const newPath = [...path];
              newPath.splice(i, 1);
              if (unique(newPath, rootDocument) &&
                  rootDocument.querySelector(selector(newPath)) === input) {
                  yield newPath;
                  yield* optimize(newPath, input, config, rootDocument, startTime);
              }
          }
      }
  }

  // 多策略定位器：仿 selenium-ide 的注册式 LocatorBuilders
  // 录制时一次性产出 [locator, builderName][]，回放时按顺序尝试，第一个命中即用
  // locator 形如：
  //   id=foo
  //   name=bar
  //   css=.foo > .bar
  //   xpath=//div[@id='x']
  //   linkText=点我

  const SCRIPT_UI_PREFIX = 'webchat-script-';
  const AI_ASSISTANT_IDS = ['ai-assistant-ball', 'ai-assistant-dialog'];

  function isWebChatElement$1(el) {
      if (!el || el.nodeType !== 1) return false;
      const id = el.id || '';
      if (AI_ASSISTANT_IDS.includes(id)) return true;
      if (id.startsWith(SCRIPT_UI_PREFIX)) return true;
      const cls = el.className || '';
      if (typeof cls === 'string' && (cls.includes('webchat-script-') || cls.includes('ball-container'))) return true;
      return !!(el.closest && (
          el.closest('#ai-assistant-ball') ||
          el.closest('#ai-assistant-dialog') ||
          el.closest('[id^="webchat-script-"]')
      ));
  }

  function cssEscape$1(str) {
      if (window.CSS && typeof window.CSS.escape === 'function') return window.CSS.escape(str);
      return String(str).replace(/([!"#$%&'()*+,./:;<=>?@\[\\\]^`{|}~])/g, '\\$1');
  }

  // ====== 解析 / 查找 ======

  function parseLocator(loc) {
      if (!loc) return null;
      const m = String(loc).match(/^([A-Za-z][A-Za-z0-9_:-]*)=([\s\S]+)$/);
      if (m) return { type: m[1], string: m[2] };
      // 无前缀：兼容旧脚本里裸 CSS 选择器
      if (loc.startsWith('/') || loc.startsWith('(')) return { type: 'xpath', string: loc };
      return { type: 'css', string: loc };
  }

  function findElement(loc, doc = document) {
      const parsed = parseLocator(loc);
      if (!parsed) return null;
      const { type, string } = parsed;
      try {
          switch (type) {
              case 'id':
                  return doc.getElementById(string);
              case 'name': {
                  const els = doc.getElementsByName(string);
                  return els && els.length ? els[0] : null;
              }
              case 'linkText':
              case 'link': {
                  const anchors = doc.querySelectorAll('a');
                  for (const a of anchors) {
                      if ((a.textContent || '').replace(/\s+/g, ' ').trim() === string) return a;
                  }
                  return null;
              }
              case 'partialLinkText': {
                  const anchors = doc.querySelectorAll('a');
                  for (const a of anchors) {
                      if ((a.textContent || '').includes(string)) return a;
                  }
                  return null;
              }
              case 'css':
                  return doc.querySelector(string);
              case 'xpath': {
                  const r = doc.evaluate(string, doc, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);
                  return r.singleNodeValue || null;
              }
              default:
                  // 形如 css:data-test-id / xpath:idRelative —— 截 type 前缀
                  if (type.startsWith('css')) return doc.querySelector(string);
                  if (type.startsWith('xpath')) {
                      const r = doc.evaluate(string, doc, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);
                      return r.singleNodeValue || null;
                  }
                  return doc.querySelector(string);
          }
      } catch (e) {
          return null;
      }
  }

  // 按 [locator, builderName] 数组顺序尝试
  function findFromTargets(targets, doc = document) {
      if (!Array.isArray(targets)) return null;
      for (const item of targets) {
          const loc = Array.isArray(item) ? item[0] : item;
          const el = findElement(loc, doc);
          if (el) return el;
      }
      return null;
  }

  // ====== 工具：xpath 编码 / 节点序号 / 精确化 ======

  function attributeValue(value) {
      const v = String(value);
      if (v.indexOf("'") < 0) return `'${v}'`;
      if (v.indexOf('"') < 0) return `"${v}"`;
      // 同时含单双引号 → concat()
      let result = 'concat(';
      let rest = v;
      let first = true;
      while (rest.length > 0) {
          const apos = rest.indexOf("'");
          const quot = rest.indexOf('"');
          let part;
          if (apos < 0) { part = `'${rest}'`; rest = ''; }
          else if (quot < 0) { part = `"${rest}"`; rest = ''; }
          else if (quot < apos) { part = `'${rest.substring(0, quot)}'`; rest = rest.substring(quot); }
          else { part = `"${rest.substring(0, apos)}"`; rest = rest.substring(apos); }
          result += (first ? '' : ',') + part;
          first = false;
      }
      return result + ')';
  }

  function xpathHtmlElement(name) {
      if (document.contentType === 'application/xhtml+xml') return 'x:' + name;
      return name;
  }

  function getNodeIndex(el) {
      const siblings = el.parentNode?.childNodes || [];
      let total = 0, index = -1;
      for (let i = 0; i < siblings.length; i++) {
          const c = siblings[i];
          if (c.nodeName === el.nodeName) {
              if (c === el) index = total;
              total++;
          }
      }
      return total > 1 ? index : -1; // 只一个就不需要下标
  }

  function relativeXPathFromParent(current) {
      const idx = getNodeIndex(current);
      let part = '/' + xpathHtmlElement(current.nodeName.toLowerCase());
      if (idx >= 0) part += `[${idx + 1}]`;
      return part;
  }

  function preciseXPath(xpath, el) {
      if (findElement('xpath=' + xpath) === el) return 'xpath=' + xpath;
      try {
          const r = el.ownerDocument.evaluate(
              xpath, el.ownerDocument, null,
              XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null
          );
          for (let i = 0, len = r.snapshotLength; i < len; i++) {
              const candidate = `xpath=(${xpath})[${i + 1}]`;
              if (findElement(candidate) === el) return candidate;
          }
      } catch (e) { /* ignore */ }
      return 'xpath=' + xpath;
  }

  // ====== 注册式 builder ======

  const builders = []; // [{ name, fn }]
  const order = [];    // 默认优先级

  function add(name, fn) {
      builders.push({ name, fn });
      order.push(name);
  }

  // id
  add('id', (e) => {
      if (e.id && !/\s/.test(e.id)) return 'id=' + e.id;
      return null;
  });

  // css:data-test-id
  add('css:data-test-id', (e) => {
      const attrs = ['data-test-id', 'data-testid', 'data-test', 'data-cy', 'data-qa'];
      for (const a of attrs) {
          const v = e.getAttribute && e.getAttribute(a);
          if (v) return `css=[${a}="${String(v).replace(/"/g, '\\"')}"]`;
      }
      return null;
  });

  // linkText (anchor only)
  add('linkText', (e) => {
      if (e.nodeName !== 'A') return null;
      const text = (e.textContent || '').replace(/\xA0/g, ' ').trim();
      if (!text) return null;
      return 'linkText=' + text;
  });

  // name
  add('name', (e) => {
      const n = e.getAttribute && e.getAttribute('name');
      if (!n) return null;
      return 'name=' + n;
  });

  // css:data-attr
  add('css:data-attr', (e) => {
      const ds = e.dataset || {};
      const keys = Object.keys(ds);
      if (!keys.length) return null;
      const attr = keys[0];
      const value = ds[attr];
      const htmlAttr = 'data-' + attr.replace(/[A-Z]/g, (c) => '-' + c.toLowerCase());
      if (!value || value === 'true') return `css=[${htmlAttr}]`;
      return `css=[${htmlAttr}="${String(value).replace(/"/g, '\\"')}"]`;
  });

  // aria-label
  add('css:aria-label', (e) => {
      const v = e.getAttribute && e.getAttribute('aria-label');
      if (!v) return null;
      return `css=${e.tagName.toLowerCase()}[aria-label="${String(v).replace(/"/g, '\\"')}"]`;
  });

  // role + name (按 aria-label / textContent 任一即可)
  add('css:role', (e) => {
      const role = e.getAttribute && e.getAttribute('role');
      if (!role) return null;
      return `css=[role="${String(role).replace(/"/g, '\\"')}"]`;
  });

  // css:title —— 例：ant-select option 在外层 div 上有 title="中"，比 active 类稳
  add('css:title', (e) => {
      const t = e.getAttribute && e.getAttribute('title');
      if (!t || t.length > 60) return null;
      const tag = e.tagName.toLowerCase();
      return `css=${tag}[title="${String(t).replace(/"/g, '\\"')}"]`;
  });

  // ant-design 表单控件：按左侧 label 锚定到当前 form-item 内的具体控件。
  // 这比 .ant-select-selector / .ant-picker 这种全局重复类稳定得多。
  add('xpath:ant-form-label-control', (e) => {
      const item = e.closest && e.closest('.ant-form-item');
      if (!item) return null;
      const label = item.querySelector('.ant-form-item-label label, label');
      const labelText = (label?.textContent || '').replace(/\s+/g, ' ').trim();
      if (!labelText || labelText.length > 60) return null;

      const controlPath = antControlPath(e, item);
      if (!controlPath) return null;

      const xp = `//div[contains(@class,'ant-form-item')][.//label[normalize-space(.)=${attributeValue(labelText)}]]${controlPath}`;
      return preciseXPath(xp, e);
  });

  function antControlPath(e, item) {
      const control = item.querySelector('.ant-form-item-control');
      if (!control || !control.contains(e)) return null;

      if (e.matches('.ant-select-selector')) return `//*[contains(@class,'ant-select-selector')]`;
      if (e.matches('.ant-picker')) return `//*[contains(concat(' ', normalize-space(@class), ' '),' ant-picker ') and not(contains(@class,'ant-picker-dropdown'))]`;
      if (e.matches('.ant-upload, .ant-upload-wrapper')) return `//*[contains(@class,'ant-upload')]`;
      if (e.matches('.ant-radio-group')) return `//*[contains(@class,'ant-radio-group')]`;
      if (e.matches('.ant-checkbox-wrapper')) return `//*[contains(@class,'ant-checkbox-wrapper')]`;
      if (e.matches('button')) return `//button`;

      const tag = xpathHtmlElement(e.nodeName.toLowerCase());
      if (e.id && !isUnstableId(e.id)) return `//${tag}[@id=${attributeValue(e.id)}]`;
      const placeholder = e.getAttribute && e.getAttribute('placeholder');
      if (placeholder) return `//${tag}[@placeholder=${attributeValue(placeholder)}]`;
      const role = e.getAttribute && e.getAttribute('role');
      if (role) return `//${tag}[@role=${attributeValue(role)}]`;
      return null;
  }

  // ant-design 日期/时间范围选择器常把可点击内容放在 td 内层 div 上，真正稳定的日期在祖先 td[title]。
  // 优先生成 td[title="YYYY-MM-DD"]，避免录到 range-start/range-end/active 这类状态 class。
  add('css:date-cell-title', (e) => {
      const cell = e.closest && e.closest('td[title]');
      if (!cell) return null;
      const t = cell.getAttribute('title');
      if (!t || t.length > 60) return null;
      return `css=td[title="${String(t).replace(/"/g, '\\"')}"]`;
  });

  // 检测最近的 popup / portal / dropdown 祖先，返回该容器的稳定类锚点 (eg .ant-select-dropdown)
  // 这类容器一般 portal 到 body 末尾，div 序号每次都变，所以必须按 class 锚而不是 nth-of-type
  const POPUP_CLASS_RE = /(^|\s)(ant-[a-z-]+-(dropdown|popup|popover|tooltip)|ant-picker-dropdown|el-(select|picker|dropdown|popover|popper)-?[a-z-]*|rc-virtual-list|MuiPopover-|MuiMenu-)/i;
  function findPopupAncestor(el) {
      let cur = el.parentElement;
      while (cur && cur !== document.body) {
          const cls = (cur.className && typeof cur.className === 'string') ? cur.className : '';
          if (cls && POPUP_CLASS_RE.test(cls)) {
              // 挑稳定的：匹配 POPUP_CLASS_RE 且不含 stateful（hidden/open/placement-* 等）
              const tokens = cls.split(/\s+/).filter(Boolean)
                  .filter(t => POPUP_CLASS_RE.test(t))
                  .filter(t => !isStatefulClass(t) && !/-(placement|position|align)-/.test(t));
              if (tokens.length) {
                  // 最短的更通用
                  tokens.sort((a, b) => a.length - b.length);
                  return { node: cur, klass: tokens[0] };
              }
          }
          cur = cur.parentElement;
      }
      return null;
  }

  // xpath:innerText:scoped —— 锚到最近的 popup/dropdown 容器，对 ant-design / element-plus 这种动态 portal 有救
  // 例：xpath=//div[contains(@class,'ant-select-dropdown')]//div[normalize-space(.)='资源滥用']
  add('xpath:innerText:scoped', (e) => {
      const text = (e.innerText || '').replace(/\s+/g, ' ').trim();
      if (!text || text.length > 30) return null;
      const ancestor = findPopupAncestor(e);
      if (!ancestor) return null;
      const tag = xpathHtmlElement(e.nodeName.toLowerCase());
      const isLeaf = !Array.from(e.children || []).length;
      const eq = isLeaf
          ? `normalize-space(.)=${attributeValue(text)}`
          : `contains(normalize-space(.),${attributeValue(text)})`;
      const xp = `//div[contains(@class,${attributeValue(ancestor.klass)})]//${tag}[${eq}]`;
      const built = preciseXPath(xp, e);
      if (findElement(built) === e) return built;
      return null;
  });

  // xpath:innerText —— 含直接文本的可读 xpath（叶子节点优先）
  // 提到 finder 之前是因为对动态 UI（ant-select / DatePicker / 菜单）按文字找最准
  add('xpath:innerText', (e) => {
      const text = (e.innerText || '').replace(/\s+/g, ' ').trim();
      if (!text || text.length > 30) return null;
      // 叶子节点（无元素子节点）才用精确等于；非叶子用 contains 容错
      const isLeaf = !Array.from(e.children || []).length;
      const xp = isLeaf
          ? `//${xpathHtmlElement(e.nodeName.toLowerCase())}[normalize-space(.)=${attributeValue(text)}]`
          : `//${xpathHtmlElement(e.nodeName.toLowerCase())}[contains(normalize-space(.),${attributeValue(text)})]`;
      const built = preciseXPath(xp, e);
      if (findElement(built) === e) return built;
      return null;
  });

  // xpath:innerText:any —— 不加下标，全局第一个匹配。对 popup 已关闭只剩一处文字的回放最稳
  add('xpath:innerText:any', (e) => {
      const text = (e.innerText || '').replace(/\s+/g, ' ').trim();
      if (!text || text.length > 30) return null;
      const tag = xpathHtmlElement(e.nodeName.toLowerCase());
      const isLeaf = !Array.from(e.children || []).length;
      const xp = isLeaf
          ? `xpath=//${tag}[normalize-space(.)=${attributeValue(text)}]`
          : `xpath=//${tag}[contains(normalize-space(.),${attributeValue(text)})]`;
      // 不要求回找命中（findFirst 命中谁都行）；buildAll 那边的回找校验会决定要不要保留
      return xp;
  });

  // css:finder —— 用 @medv/finder 评分式生成
  // 注意：必须屏蔽所有 stateful class（active/hover/focus/selected/open 等），
  // 否则在 ant-design / element-plus 这种动态 UI 里录到的就是"当前高亮项"，
  // 回放时高亮位置变了就命中错元素（典型：select 下拉默认 active 第一项）
  const STATEFUL_CLASS_RE = [
      /(^|-)active$/i, /(^|-)hover(ed|ing)?$/i,
      /(^|-)focus(ed|-visible|-within)?$/i,
      /(^|-)selected$/i, /(^|-)checked$/i,
      /(^|-)open(ed)?$/i, /(^|-)expanded$/i, /(^|-)collapsed$/i,
      /(^|-)disabled$/i, /(^|-)loading$/i,
      /(^|-)error(ed)?$/i, /(^|-)invalid$/i, /(^|-)valid$/i,
      /(^|-)dragging$/i, /(^|-)draggable-over$/i,
      /(^|-)current$/i, /(^|-)now$/i, /(^|-)today$/i,
      /^is-/i, /^has-/i,
      // ant-design / element-plus 状态后缀
      /^ant-.*-(active|selected|focused|hover|open|disabled|loading|error|highlight)$/i,
      /^ant-picker-cell-(range-start|range-end|in-range|range-hover|today)$/i,
      /^el-.*-(active|selected|focus|hover|open|disabled|loading|highlight)$/i
  ];
  function isStatefulClass(name) {
      if (!name) return false;
      return STATEFUL_CLASS_RE.some(re => re.test(name));
  }

  // 自动生成的 id（如 react/hooks 的 :r1: / __next_id__123）也别用
  const UNSTABLE_ID_RE = /^[a-z]+-\d+$|^:r[0-9a-z]+:$|^id-\d+$|^__|\d{4,}/i;
  function isUnstableId(name) {
      return !!name && UNSTABLE_ID_RE.test(name);
  }

  add('css:finder', (e) => {
      try {
          const sel = finder(e, {
              root: document.body,
              seedMinLength: 1,
              optimizedMinLength: 2,
              attr: () => false,
              className: (name) => !isStatefulClass(name),
              idName: (name) => !isUnstableId(name)
          });
          return 'css=' + sel;
      } catch (err) {
          return null;
      }
  });

  // xpath:link (含部分文字的 a)
  add('xpath:link', (e) => {
      if (e.nodeName !== 'A') return null;
      const text = (e.textContent || '').trim();
      if (!text) return null;
      return preciseXPath(`//${xpathHtmlElement('a')}[contains(text(),${attributeValue(text)})]`, e);
  });

  // xpath:img
  add('xpath:img', (e) => {
      if (e.nodeName !== 'IMG') return null;
      if (e.alt) return preciseXPath(`//${xpathHtmlElement('img')}[@alt=${attributeValue(e.alt)}]`, e);
      if (e.title) return preciseXPath(`//${xpathHtmlElement('img')}[@title=${attributeValue(e.title)}]`, e);
      if (e.src) return preciseXPath(`//${xpathHtmlElement('img')}[contains(@src,${attributeValue(e.src)})]`, e);
      return null;
  });

  // xpath:attributes —— 优选 id/name/value/type/action/onclick
  add('xpath:attributes', (e) => {
      const PREFER = ['id', 'name', 'value', 'type', 'action', 'onclick'];
      if (!e.attributes) return null;
      const map = {};
      for (let i = 0; i < e.attributes.length; i++) {
          const a = e.attributes[i];
          map[a.name] = a.value;
      }
      const tagName = e.nodeName.toLowerCase();
      const used = [];
      for (const name of PREFER) {
          if (map[name] != null) {
              used.push(name);
              const conds = used.map((n) => `@${n}=${attributeValue(map[n])}`);
              if (e.textContent && name === 'type') {
                  conds.push(`text()=${attributeValue(e.textContent)}`);
              }
              const xp = `//${xpathHtmlElement(tagName)}[${conds.join(' and ')}]`;
              const built = preciseXPath(xp, e);
              if (findElement(built) === e) return built;
          }
      }
      return null;
  });

  // xpath:idRelative —— 沿父级走到最近的 id 锚点
  add('xpath:idRelative', (e) => {
      let path = '';
      let current = e;
      while (current && current.parentNode) {
          path = relativeXPathFromParent(current) + path;
          const parent = current.parentNode;
          if (parent.nodeType === 1 && parent.getAttribute && parent.getAttribute('id')) {
              const idVal = parent.getAttribute('id');
              const xp = `//${xpathHtmlElement(parent.nodeName.toLowerCase())}[@id=${attributeValue(idVal)}]${path}`;
              return preciseXPath(xp, e);
          }
          current = parent;
      }
      return null;
  });

  // xpath:href
  add('xpath:href', (e) => {
      if (!e.hasAttribute || !e.hasAttribute('href')) return null;
      const href = e.getAttribute('href');
      const isAbs = /^https?:\/\//.test(href);
      const xp = isAbs
          ? `//${xpathHtmlElement('a')}[@href=${attributeValue(href)}]`
          : `//${xpathHtmlElement('a')}[contains(@href,${attributeValue(href)})]`;
      return preciseXPath(xp, e);
  });

  // xpath:position —— 兜底完整路径
  add('xpath:position', (e) => {
      let path = '';
      let current = e;
      while (current && current.parentNode) {
          path = relativeXPathFromParent(current) + path;
          const built = 'xpath=/' + path.replace(/^\//, '');
          if (findElement(built) === e) return built;
          current = current.parentNode;
          if (!current || current.nodeType !== 1) break;
      }
      return null;
  });

  // ====== 公共 API ======

  /**
   * 录制器调用：返回 [[locator, builderName], ...] —— 已校验回找命中元素
   */
  function buildAll(el) {
      if (!el || el.nodeType !== 1) return [];
      const out = [];
      for (const { name, fn } of builders) {
          try {
              const loc = fn(el);
              if (!loc) continue;
              // 校验：解析 + 回找必须命中同一元素
              const found = findElement(loc);
              if (found === el) out.push([loc, name]);
          } catch (e) { /* ignore one builder */ }
      }
      return out;
  }

  /** 录制器调用：单个最优 locator（出错则返回 LOCATOR_DETECTION_FAILED） */
  function build(el) {
      const all = buildAll(el);
      return all.length ? all[0][0] : 'LOCATOR_DETECTION_FAILED';
  }

  const LOCATOR_BUILDER_ORDER = order.slice();

  const LB = {
      build,
      buildAll,
      findElement,
      findFromTargets,
      parseLocator,
      cssEscape: cssEscape$1,
      isWebChatElement: isWebChatElement$1,
      LOCATOR_BUILDER_ORDER
  };

  // 操作录制器（P0 升级）
  // - 仿 selenium-ide 状态机：typeLock / preventClick / preventClickTwice / preventType / enterTarget / focus / tabCheck
  // - 每一步存 target 数组：[[locator, builderName], ...]，回放端按顺序兜底
  // - 兼容旧字段：同时写 selector + selectorFallbacks，旧脚本旧执行器都能跑
  // - isTrusted 过滤：屏蔽脚本注入事件（如执行器自己 dispatch 的 click），避免自录

  const INPUT_TYPES = [
      'text', 'password', 'file', 'datetime', 'datetime-local', 'date',
      'month', 'time', 'week', 'number', 'range', 'email', 'url',
      'search', 'tel', 'color'
  ];

  function nowId() {
      return 'step_' + Date.now() + '_' + Math.floor(Math.random() * 1000);
  }

  // 把 [[locator, builderName], ...] 拆成给执行器用的 selector + selectorFallbacks
  // 优先把"最像 CSS 选择器"的放主 selector，剩下的全部填进 fallbacks（包含 xpath= 前缀的项）
  function targetsToLegacyPair(targets) {
      if (!Array.isArray(targets) || !targets.length) return { selector: null, selectorFallbacks: [] };
      const toLegacy = (loc) => {
          // id=foo -> #foo
          let m = loc.match(/^id=(.+)$/);
          if (m) {
              const id = m[1];
              if (/^[A-Za-z_][\w-]*$/.test(id)) return '#' + id;
              return `[id="${id.replace(/"/g, '\\"')}"]`;
          }
          // name=bar -> [name="bar"]
          m = loc.match(/^name=(.+)$/);
          if (m) return `[name="${m[1].replace(/"/g, '\\"')}"]`;
          // css=...  -> 去前缀
          m = loc.match(/^css(?::[^=]+)?=([\s\S]+)$/);
          if (m) return m[1];
          // xpath=...  -> 保留 xpath= 让 query() 走 evaluate
          m = loc.match(/^xpath(?::[^=]+)?=([\s\S]+)$/);
          if (m) return 'xpath=' + m[1];
          // linkText=...  -> 保留原值
          return loc;
      };
      const all = targets.map(([loc]) => toLegacy(loc));
      const seen = new Set();
      const dedup = [];
      for (const s of all) {
          if (s && !seen.has(s)) { seen.add(s); dedup.push(s); }
      }
      // 主 selector 取第一个 CSS 类（非 xpath= 开头）
      const cssIdx = dedup.findIndex(s => !s.startsWith('xpath=') && !s.startsWith('linkText='));
      const mainIdx = cssIdx >= 0 ? cssIdx : 0;
      const selector = dedup[mainIdx];
      const fallbacks = dedup.filter((_, i) => i !== mainIdx);
      return { selector, selectorFallbacks: fallbacks };
  }

  // 给步骤同时写 targets 和 selector/selectorFallbacks
  function attachLocators(stepParams, el) {
      const targets = buildAll(el);
      const legacy = targetsToLegacyPair(targets);
      stepParams.targets = targets;                // 新字段（首选）
      stepParams.selector = legacy.selector;       // 旧字段（兼容）
      stepParams.selectorFallbacks = legacy.selectorFallbacks;
      return stepParams;
  }

  // 采集"点击的命中点"+ 当时的 viewport / 滚动位置 / 元素几何，作为坐标兜底依据。
  // 回放时若 selector / targets 全部找不到元素，executor 会用这些信息做 elementFromPoint 命中。
  // 关键设计：
  //   - 存元素相对自身的命中比例 (rx, ry)，对元素尺寸变化更鲁棒
  //   - 同时存录制时元素的视口绝对坐标 (vx, vy)，用于"页面布局没动"时的快路径
  //   - 存元素 tag/role/text 摘要，命中后做语义校验，避免点到浮层挡住的别的元素
  function attachHitPoint(stepParams, el, event) {
      if (!el || el.nodeType !== 1) return stepParams;
      let rect;
      try { rect = el.getBoundingClientRect(); } catch { return stepParams; }
      if (!rect || rect.width === 0 && rect.height === 0) return stepParams;

      const ev = event || {};
      let cx = typeof ev.clientX === 'number' ? ev.clientX : null;
      let cy = typeof ev.clientY === 'number' ? ev.clientY : null;
      // 没有事件坐标（来自 picker / 程序化触发）就用元素中心点
      if (cx === null || cy === null) {
          cx = rect.left + rect.width / 2;
          cy = rect.top + rect.height / 2;
      }
      // 命中点在元素内的相对比例，clamp 到 [0,1]，避免越界
      const rx = rect.width > 0 ? Math.max(0, Math.min(1, (cx - rect.left) / rect.width)) : 0.5;
      const ry = rect.height > 0 ? Math.max(0, Math.min(1, (cy - rect.top) / rect.height)) : 0.5;

      const tagName = el.tagName ? el.tagName.toLowerCase() : '';
      stepParams.hitPoint = {
          rx: Number(rx.toFixed(4)),
          ry: Number(ry.toFixed(4)),
          vx: Math.round(cx),    // 视口坐标
          vy: Math.round(cy),
          rect: {                // 录制时元素的几何（视口坐标系）
              x: Math.round(rect.left),
              y: Math.round(rect.top),
              w: Math.round(rect.width),
              h: Math.round(rect.height)
          },
          viewport: {
              w: window.innerWidth,
              h: window.innerHeight,
              sx: window.scrollX,
              sy: window.scrollY
          },
          // 语义校验依据
          sig: {
              tag: tagName,
              role: el.getAttribute?.('role') || '',
              type: el.getAttribute?.('type') || '',
              text: shortLabel(el, 60)
          }
      };
      return stepParams;
  }

  function shortLabel(el, maxLen = 30) {
      const text = (el.textContent || el.value || el.placeholder || el.getAttribute?.('aria-label') || '')
          .replace(/\s+/g, ' ').trim();
      return text.slice(0, maxLen);
  }

  class Recorder {
      constructor(opts = {}) {
          this.steps = [];
          this.recording = false;
          this.paused = false;
          this.onChange = opts.onChange || (() => { });
          this.handlers = {};
          this.scrollTimer = null;
          this.lastScrollAt = 0;

          // selenium-ide 风格状态机
          this.state = {
              typeTarget: null,
              typeLock: 0,
              focusTarget: null,
              focusValue: null,
              tempValue: null,
              preventType: false,
              preventClick: false,
              preventClickTwice: false,
              enterTarget: null,
              enterValue: null,
              tabCheck: null,
              lastInputStep: null,
              lastInputAt: 0
          };
      }

      start() {
          if (this.recording) return;
          this.steps = [];
          this.recording = true;
          this.paused = false;

          const bind = (k, fn, capture = true) => {
              this.handlers[k] = (e) => fn.call(this, e);
              if (k === 'scroll') window.addEventListener('scroll', this.handlers[k], capture);
              else document.addEventListener(k, this.handlers[k], capture);
          };
          bind('click', this._onClick);
          bind('dblclick', this._onDblClick);
          bind('input', this._onInput);
          bind('change', this._onChange);
          bind('keydown', this._onKeyDown);
          bind('focus', this._onFocus);
          bind('blur', this._onBlur);
          bind('submit', this._onSubmit);
          bind('scroll', this._onScroll);

          this._addStep({
              type: 'navigate',
              description: '当前页面',
              params: { url: location.href },
              options: { waitUntil: 'domcontentloaded', timeout: 10000 }
          });
      }

      stop() {
          if (!this.recording) return this.steps;
          this.recording = false;
          for (const k of Object.keys(this.handlers)) {
              if (k === 'scroll') window.removeEventListener('scroll', this.handlers[k], true);
              else document.removeEventListener(k, this.handlers[k], true);
          }
          this.handlers = {};
          return this.steps;
      }

      pause() { this.paused = true; }
      resume() { this.paused = false; }

      _ignored(target, event) {
          if (!target || target.nodeType !== 1) return true;
          if (event && event.isTrusted === false) return true; // 屏蔽脚本注入事件
          if (isWebChatElement$1(target)) return true;
          return false;
      }

      _addStep(step) {
          step.id = step.id || nowId();
          this.steps.push(step);
          this.onChange(this.steps.slice());
      }

      _replaceLast(step) {
          if (!this.steps.length) return this._addStep(step);
          step.id = step.id || this.steps[this.steps.length - 1].id || nowId();
          this.steps[this.steps.length - 1] = step;
          this.onChange(this.steps.slice());
      }

      // ---------- focus / blur ----------
      _onFocus(event) {
          const t = event.target;
          if (!t || t.nodeType !== 1) return;
          const tag = t.tagName ? t.tagName.toLowerCase() : '';
          if (tag !== 'input' && tag !== 'textarea' && t.isContentEditable !== true) return;
          this.state.focusTarget = t;
          this.state.focusValue = t.value || '';
          this.state.tempValue = this.state.focusValue;
          this.state.preventType = false;
      }

      _onBlur() {
          this.state.focusTarget = null;
          this.state.focusValue = null;
          this.state.tempValue = null;
      }

      // ---------- click ----------
      _onClick(event) {
          if (!this.recording || this.paused) return;
          if (this._ignored(event.target, event)) return;
          if (event.button !== 0) return;
          if (this.state.preventClick) return;

          const target = event.target;
          const tag = target.tagName ? target.tagName.toLowerCase() : '';

          // 紧接 input/type 的同元素 click 抑制（避免文本框被点两次记录）
          const last = this.steps[this.steps.length - 1];
          if (last && last.type === 'input' && tag === 'input') {
              const lastSel = last.params?.selector;
              const built = LB.buildAll(target);
              if (built.length && built[0][0]) {
                  const sameId = lastSel && (lastSel === built[0][0] || lastSel === '#' + (target.id || ''));
                  if (sameId) return;
              }
          }

          if (!this.state.preventClickTwice) {
              const params = attachLocators({}, target);
              attachHitPoint(params, target, event);
              this._addStep({
                  type: 'click',
                  description: `点击 ${tag}${shortLabel(target) ? ' "' + shortLabel(target) + '"' : ''}`,
                  params
              });
              this.state.preventClickTwice = true;
              setTimeout(() => { this.state.preventClickTwice = false; }, 30);
          }
      }

      _onDblClick(event) {
          if (!this.recording || this.paused) return;
          if (this._ignored(event.target, event)) return;
          // 抹掉前置的两次 click（dblclick 总会先来 click click）
          const popClickIfMatch = () => {
              const last = this.steps[this.steps.length - 1];
              if (last && last.type === 'click') this.steps.pop();
          };
          popClickIfMatch();
          popClickIfMatch();

          const params = attachLocators({}, event.target);
          attachHitPoint(params, event.target, event);
          this._addStep({
              type: 'dblclick',
              description: `双击 ${event.target.tagName.toLowerCase()}`,
              params
          });
      }

      // ---------- input / change (type) ----------
      _onInput(event) {
          if (!this.recording || this.paused) return;
          const target = event.target;
          if (this._ignored(target, event)) return;
          const tag = target.tagName ? target.tagName.toLowerCase() : '';
          if (tag !== 'input' && tag !== 'textarea' && !target.isContentEditable) return;

          this.state.typeTarget = target;
          const isPassword = tag === 'input' && target.type === 'password';
          const value = target.isContentEditable ? target.innerText : (target.value || '');
          const params = attachLocators({}, target);
          const sel = params.selector;
          const now = Date.now();

          // 同一目标 1.5s 内连续输入 -> 合并为一条
          const last = this.state.lastInputStep;
          if (last && last.params.selector === sel && now - this.state.lastInputAt < 1500) {
              last.params.value = isPassword ? '{{password}}' : value;
              last.description = `输入到 ${sel || tag}`;
              this.state.lastInputAt = now;
              this.onChange(this.steps.slice());
              return;
          }

          const step = {
              type: 'input',
              description: `输入到 ${sel || tag}`,
              params: {
                  ...params,
                  value: isPassword ? '{{password}}' : value,
                  clearBefore: true,
                  inputType: isPassword ? 'password' : 'text'
              }
          };
          this._addStep(step);
          this.state.lastInputStep = step;
          this.state.lastInputAt = now;
      }

      _onChange(event) {
          if (!this.recording || this.paused) return;
          const target = event.target;
          if (this._ignored(target, event)) return;
          const tag = target.tagName ? target.tagName.toLowerCase() : '';

          if (tag === 'select') {
              const params = attachLocators({}, target);
              const opt = target.options?.[target.selectedIndex];
              this._addStep({
                  type: 'select',
                  description: `选择 ${opt?.text || target.value}`,
                  params: { ...params, value: target.value }
              });
          } else if (tag === 'input' && (target.type === 'checkbox' || target.type === 'radio')) {
              const params = attachLocators({}, target);
              this._addStep({
                  type: 'checkbox',
                  description: (target.checked ? '勾选 ' : '取消勾选 ') + (params.selector || tag),
                  params: { ...params, checked: target.checked }
              });
          }
      }

      // ---------- keydown ----------
      _onKeyDown(event) {
          if (!this.recording || this.paused) return;
          if (this._ignored(event.target, event)) return;

          const target = event.target;
          const tag = target.tagName ? target.tagName.toLowerCase() : '';
          const key = event.key;
          const isEnter = key === 'Enter';
          const isTab = key === 'Tab';

          // Enter on input/textarea —— 标记 enterTarget，配合 change 事件再决定是否产出 sendKeys
          if (isEnter && (tag === 'input' || tag === 'textarea') && INPUT_TYPES.includes(target.type || 'text')) {
              this.state.enterTarget = target;
              this.state.enterValue = target.value;
          }
          if (isTab) {
              this.state.tabCheck = target;
          }

          const SPECIAL = ['Enter', 'Tab', 'Escape', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Backspace', 'Delete'];
          const isSpecial = SPECIAL.includes(key);
          const hasMod = event.ctrlKey || event.altKey || event.metaKey;
          if (!isSpecial && !hasMod) return;

          // 在文本输入控件里按 Enter / Tab —— 已由 enterTarget 流程处理，不重复记 keypress
          if ((isEnter || isTab) && (tag === 'input' || tag === 'textarea')) {
              const params = attachLocators({}, target);
              this._addStep({
                  type: 'keypress',
                  description: `按下 ${key}`,
                  params: { ...params, key, modifiers: this._modifiers(event) }
              });
              return;
          }

          const modifiers = this._modifiers(event);
          if (hasMod && key.length === 1) {
              this._addStep({
                  type: 'hotkey',
                  description: `快捷键 ${[...modifiers, key].join('+')}`,
                  params: { keys: [...modifiers.map(m => m[0].toUpperCase() + m.slice(1)), key.toUpperCase()] }
              });
          } else {
              this._addStep({
                  type: 'keypress',
                  description: `按下 ${key}`,
                  params: { key, modifiers }
              });
          }
      }

      _modifiers(e) {
          const m = [];
          if (e.ctrlKey) m.push('ctrl');
          if (e.shiftKey) m.push('shift');
          if (e.altKey) m.push('alt');
          if (e.metaKey) m.push('meta');
          return m;
      }

      _onSubmit() { /* 由 click 提交按钮覆盖 */ }

      // ---------- scroll ----------
      _onScroll() {
          if (!this.recording || this.paused) return;
          const now = Date.now();
          if (now - this.lastScrollAt < 500) return;
          this.lastScrollAt = now;
          clearTimeout(this.scrollTimer);
          this.scrollTimer = setTimeout(() => {
              if (!this.recording) return;
              const last = this.steps[this.steps.length - 1];
              const x = window.scrollX;
              const y = window.scrollY;
              if (last && last.type === 'scroll') {
                  last.params.x = x;
                  last.params.y = y;
                  this.onChange(this.steps.slice());
              } else {
                  this._addStep({
                      type: 'scroll',
                      description: `滚动到 (${x}, ${y})`,
                      params: { x, y, behavior: 'smooth' }
                  });
              }
          }, 600);
      }

      getScript(meta = {}) {
          return {
              meta: {
                  id: 'script_' + Date.now(),
                  name: meta.name || '未命名脚本',
                  description: meta.description || '',
                  version: '1.0',
                  createdAt: new Date().toISOString(),
                  updatedAt: new Date().toISOString(),
                  author: 'user',
                  source: 'record',
                  targetUrl: location.href,
                  ...meta
              },
              variables: {},
              steps: this.steps.slice()
          };
      }
  }

  // 选择器生成器 —— 兼容旧 API，内部委托给 locator-builders.js（多策略）
  // 旧 API:
  //   generateSelector(el) -> { primary, fallbacks, xpath }
  //   querySelector(selector, fallbacks) -> Element | null
  //   isWebChatElement(el) -> boolean
  //   cssEscape(str) -> string
  // 新 API:
  //   buildAllTargets(el)  -> [[locator, builderName], ...]   // selenium-ide 风格 target 数组
  //   findFromTargets(targets) -> Element | null

  const cssEscape = cssEscape$1;
  const isWebChatElement = isWebChatElement$1;

  /** 录制时使用：返回 [[locator, builderName], ...]，每条 locator 形如 id=xxx / css=... / xpath=... */
  function buildAllTargets(el) {
      return buildAll(el);
  }

  /**
   * 旧 API：返回 { primary, fallbacks, xpath }
   *  - primary：第一条命中的 locator（不带 prefix 时是裸 CSS，带 prefix 时保持 selenium 形式）
   *  - fallbacks：剩余 locator 数组
   *  - xpath：xpath:position 兜底路径（保持原行为）
   *
   * 注意：为了兼容旧脚本的 querySelector(selector, fallbacks) 直接用 doc.querySelector，
   * 我们对 primary/fallbacks 做格式归一：
   *   - id=foo  ->  #foo
   *   - name=bar -> [name="bar"]
   *   - css=...  -> 去掉 css= 前缀
   *   - xpath=.. -> 保留原值，querySelector 时由 query() 自动用 evaluate
   */
  function locatorToCssOrXPath(loc) {
      const p = parseLocator(loc);
      if (!p) return loc;
      if (p.type === 'id') return '#' + cssEscape(p.string);
      if (p.type === 'name') return `[name="${p.string.replace(/"/g, '\\"')}"]`;
      if (p.type === 'linkText' || p.type === 'partialLinkText') return loc; // 保留 selenium 形式
      if (p.type === 'css' || p.type.startsWith('css')) return p.string;
      if (p.type === 'xpath' || p.type.startsWith('xpath')) return 'xpath=' + p.string;
      return loc;
  }

  function generateSelector(el) {
      if (!el || el.nodeType !== 1) {
          return { primary: null, fallbacks: [], xpath: null };
      }
      const targets = buildAll(el);
      if (!targets.length) return { primary: null, fallbacks: [], xpath: null };

      const cssLike = targets
          .filter(([, name]) => name === 'id' || name.startsWith('css'))
          .map(([loc]) => locatorToCssOrXPath(loc));

      const xpathLike = targets
          .filter(([, name]) => name.startsWith('xpath') || name === 'linkText')
          .map(([loc]) => locatorToCssOrXPath(loc));

      const primary = cssLike[0] || xpathLike[0] || locatorToCssOrXPath(targets[0][0]);
      const seen = new Set([primary]);
      const fallbacks = [];
      for (const c of [...cssLike, ...xpathLike]) {
          if (!seen.has(c)) { seen.add(c); fallbacks.push(c); }
      }
      const xpathTarget = targets.find(([, n]) => n === 'xpath:position') || targets.find(([, n]) => n.startsWith('xpath'));
      const xpath = xpathTarget ? locatorToCssOrXPath(xpathTarget[0]) : null;
      return { primary, fallbacks, xpath, targets };
  }

  /**
   * 旧 API：兼容裸 CSS 选择器、xpath= 前缀、selenium 风格 locator
   */
  function querySelector(selector, fallbacks = []) {
      const tryOne = (s) => {
          if (!s) return null;
          // selenium 风格：id= / name= / css= / xpath= / linkText=
          if (/^[A-Za-z][A-Za-z0-9_:-]*=/.test(s)) return findElement(s);
          // xpath 裸路径
          if (s.startsWith('/') || s.startsWith('(/')) return findElement('xpath=' + s);
          // 裸 CSS
          try { return document.querySelector(s); } catch (e) { return null; }
      };
      const el = tryOne(selector);
      if (el) return el;
      for (const f of fallbacks) {
          const r = tryOne(f);
          if (r) return r;
      }
      return null;
  }

  const Selector = {
      generate: generateSelector,
      query: querySelector,
      buildAllTargets,
      findFromTargets,
      isWebChatElement,
      cssEscape
  };

  // 脚本执行器：解析并执行脚本步骤

  const sleep = (ms) => new Promise(r => setTimeout(r, ms));
  const POPUP_WAIT_SELECTOR = '[role="dialog"], [role="listbox"], [role="menu"], .ant-picker-dropdown, .ant-select-dropdown, .el-picker-panel, .el-select-dropdown, .el-popper, .MuiPopover-root, .MuiMenu-root';

  // 把 params 里所有 locator 来源展平成统一格式：[{ locator, source, find }]
  // - source 仅做日志/调试用
  // - find 是闭包：调用即返回当前 DOM 命中的元素（每次都重新查）
  function enumerateCandidates(params) {
      if (!params) return [];
      const out = [];
      const seen = new Set();
      const push = (key, source, finder) => {
          if (!key || seen.has(key)) return;
          seen.add(key);
          out.push({ locator: key, source, find: finder });
      };

      if (Array.isArray(params.targets)) {
          for (const item of params.targets) {
              const loc = Array.isArray(item) ? item[0] : item;
              const builder = Array.isArray(item) ? (item[1] || 'target') : 'target';
              if (!loc) continue;
              push(loc, `target:${builder}`, () => findElement(loc));
          }
      }
      if (params.selector) {
          push(params.selector, 'selector', () => Selector.query(params.selector));
      }
      if (Array.isArray(params.selectorFallbacks)) {
          for (const f of params.selectorFallbacks) {
              if (!f) continue;
              push(f, 'fallback', () => Selector.query(f));
          }
      }
      // 坐标兜底：所有 selector / targets 都失效时，靠录制时存的 hitPoint 做 elementFromPoint。
      // 按"先用录制时的 viewport 绝对坐标"+"再用元素中心点比例换算"两种策略尝试。
      if (params.hitPoint) {
          push('hitPoint', 'hitPoint:absolute', () => findByHitPoint(params.hitPoint, 'absolute'));
          push('hitPoint', 'hitPoint:scaled', () => findByHitPoint(params.hitPoint, 'scaled'));
      }
      return out;
  }

  // 统一的元素查找：优先 step.params.targets（[[locator, builderName], ...]），
  // 否则回退到 selector + selectorFallbacks。
  function findByParams(params) {
      if (!params) return null;
      if (Array.isArray(params.targets) && params.targets.length) {
          const el = findFromTargets(params.targets);
          if (el) return el;
      }
      const bySel = Selector.query(params.selector, params.selectorFallbacks || []);
      if (bySel) return bySel;
      if (params.hitPoint) {
          return findByHitPoint(params.hitPoint, 'absolute') || findByHitPoint(params.hitPoint, 'scaled');
      }
      return null;
  }

  // 坐标兜底：根据录制时记录的 hitPoint 信息找元素。
  // mode = 'absolute'：用录制时的视口坐标 (vx, vy) 直接命中——页面布局没变时最准。
  // mode = 'scaled'：按当前 viewport 与录制 viewport 的比例缩放后命中——抗 viewport 尺寸变化。
  // 命中后必须通过 sigMatch 校验语义（tag/role/text），否则视为找错元素，避免点到浮层挡住的别的对象。
  function findByHitPoint(hp, mode) {
      if (!hp || typeof hp !== 'object') return null;
      let x, y;
      if (mode === 'absolute') {
          x = hp.vx;
          y = hp.vy;
      } else if (mode === 'scaled') {
          const recW = hp.viewport?.w || window.innerWidth;
          const recH = hp.viewport?.h || window.innerHeight;
          if (!recW || !recH) return null;
          const scaleX = window.innerWidth / recW;
          const scaleY = window.innerHeight / recH;
          x = Math.round(hp.vx * scaleX);
          y = Math.round(hp.vy * scaleY);
      } else {
          return null;
      }
      if (typeof x !== 'number' || typeof y !== 'number') return null;
      if (x < 0 || y < 0 || x > window.innerWidth || y > window.innerHeight) return null;

      let el;
      try { el = document.elementFromPoint(x, y); }
      catch { return null; }
      if (!el) return null;

      // 命中点落在了我们自己的浮层 / picker / panel 上时，跳过这一层继续往下找
      el = climbToInteractive(el);
      if (!el) return null;

      if (!sigMatch(el, hp.sig)) return null;
      return el;
  }

  function climbToInteractive(el) {
      let cur = el;
      let safety = 0;
      while (cur && safety < 8) {
          if (cur.nodeType !== 1) return null;
          // 跳过 webchat 自己的 UI 节点（picker 浮层、面板等）
          if (cur.id === 'webchat-script-panel' || cur.closest?.('#webchat-script-panel')) {
              cur = cur.parentElement;
              safety++;
              continue;
          }
          if (cur.classList && (cur.classList.contains('webchat-picker-overlay') || cur.classList.contains('webchat-picker-popup'))) {
              cur = cur.parentElement;
              safety++;
              continue;
          }
          return cur;
      }
      return null;
  }

  function sigMatch(el, sig) {
      if (!sig) return true; // 老脚本没有 sig，宽松通过
      const tag = el.tagName ? el.tagName.toLowerCase() : '';
      if (sig.tag && tag !== sig.tag) {
          // tag 不一致时再放一刀机会：录制时 button，实际命中包了一层 span 之类
          // 用 closest 同 tag 兜一次
          try {
              const fix = el.closest(sig.tag);
              if (fix) el = fix;
              else return false;
          } catch { return false; }
      }
      if (sig.role) {
          const role = el.getAttribute?.('role') || '';
          if (role && sig.role && role !== sig.role) return false;
      }
      if (sig.text) {
          const text = (el.textContent || el.value || el.placeholder || el.getAttribute?.('aria-label') || '')
              .replace(/\s+/g, ' ').trim();
          // 用包含关系即可——录制时 shortLabel 截了 60 字，重放时可能更长或更短
          const a = text.slice(0, 80).toLowerCase();
          const b = sig.text.slice(0, 80).toLowerCase();
          if (a && b && !a.includes(b) && !b.includes(a)) return false;
      }
      return true;
  }

  function countPopups() {
      try { return document.querySelectorAll(POPUP_WAIT_SELECTOR).length; }
      catch (e) { return 0; }
  }

  async function waitForPopupAppeared(baseline, timeout = 800) {
      const start = Date.now();
      while (Date.now() - start < timeout) {
          if (countPopups() > baseline) return true;
          await sleep(50);
      }
      return false;
  }

  // 用候选 locator 列表逐个尝试执行 action(el)：返回 ok=true 即成功；
  // 全部失败时再抛错。action 失败有两种途径：返回 { ok:false } 或抛异常。
  async function tryWithCandidates(params, action, { timeout = 5000, label = 'action' } = {}) {
      const candidates = enumerateCandidates(params);
      if (!candidates.length) {
          throw new Error(`${label}: 缺少 selector/targets`);
      }
      const errors = [];
      // 先等到至少有一个候选能命中元素，否则没必要 N 次轮询
      const firstHit = await (async () => {
          const start = Date.now();
          while (Date.now() - start < timeout) {
              for (const c of candidates) {
                  const el = c.find();
                  if (el) return true;
              }
              await sleep(100);
          }
          return false;
      })();
      if (!firstHit) {
          throw new Error(`${label}: 等待元素超时 ${candidates[0].locator}`);
      }

      for (const c of candidates) {
          const el = c.find();
          if (!el) { errors.push(`${c.source}:not-found`); continue; }
          try {
              const res = await action(el, c);
              if (res && res.ok === false) {
                  errors.push(`${c.source}:${res.reason || 'reject'}`);
                  continue;
              }
              return { el, candidate: c, result: res };
          } catch (err) {
              errors.push(`${c.source}:${err.message}`);
          }
      }
      throw new Error(`${label} 全部候选失败：${errors.join(' | ')}`);
  }

  async function waitForElement(params, timeout = 5000) {
      // 兼容旧调用：waitForElement(selectorString, fallbacksArray, timeout)
      let pms;
      if (typeof params === 'string') pms = { selector: params, selectorFallbacks: arguments[1] || [] };
      else pms = params;
      const realTimeout = (typeof params === 'string') ? (arguments[2] ?? 5000) : timeout;

      const start = Date.now();
      let nudged = false;
      while (Date.now() - start < realTimeout) {
          const el = findByParams(pms);
          if (el) return el;
          if (!nudged && Date.now() - start > Math.min(800, realTimeout / 3)) {
              nudged = true;
              try { nudgeOpenDropdown(); } catch (e) { /* ignore */ }
          }
          await sleep(100);
      }
      throw new Error(`等待元素超时：${pms.selector || (pms.targets && pms.targets[0]?.[0]) || '?'}`);
  }

  function nudgeOpenDropdown() {
      const el = document.activeElement;
      if (!el || el === document.body) return;
      const tag = el.tagName ? el.tagName.toLowerCase() : '';
      if (tag !== 'input' && tag !== 'textarea' && el.contentEditable !== 'true') return;
      const init = { key: 'ArrowDown', code: 'ArrowDown', bubbles: true, cancelable: true, composed: true };
      el.dispatchEvent(new KeyboardEvent('keydown', init));
      el.dispatchEvent(new KeyboardEvent('keyup', init));
  }

  async function waitForElementState(params, state, timeout) {
      const start = Date.now();
      while (Date.now() - start < timeout) {
          const el = findByParams(params);
          if (state === 'visible') {
              if (el && isVisible(el)) return el;
          } else if (state === 'hidden') {
              if (!el || !isVisible(el)) return el;
          } else if (state === 'attached') {
              if (el) return el;
          } else if (state === 'detached') {
              if (!el) return null;
          }
          await sleep(100);
      }
      throw new Error(`等待元素状态(${state})超时：${params.selector || (params.targets && params.targets[0]?.[0]) || '?'}`);
  }

  function isVisible(el) {
      if (!el || !el.getBoundingClientRect) return false;
      const rect = el.getBoundingClientRect();
      if (rect.width === 0 || rect.height === 0) return false;
      const style = window.getComputedStyle(el);
      if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') return false;
      return true;
  }

  function getElementCenter(el) {
      const rect = el.getBoundingClientRect();
      return {
          clientX: Math.round(rect.left + rect.width / 2),
          clientY: Math.round(rect.top + rect.height / 2)
      };
  }

  function dispatchPointerLike(el, type, coords, button = 0) {
      const { clientX, clientY } = coords;
      const common = {
          bubbles: true,
          cancelable: true,
          composed: true,
          view: window,
          clientX,
          clientY,
          screenX: clientX,
          screenY: clientY,
          button,
          buttons: type === 'mousedown' || type === 'pointerdown' ? 1 : 0
      };
      const pointerMap = {
          mousedown: 'pointerdown',
          mouseup: 'pointerup',
          mousemove: 'pointermove',
          mouseover: 'pointerover',
          mouseenter: 'pointerenter',
          mouseout: 'pointerout',
          mouseleave: 'pointerleave'
      };
      const pointerType = pointerMap[type];
      if (pointerType && typeof PointerEvent === 'function') {
          try {
              el.dispatchEvent(new PointerEvent(pointerType, {
                  ...common,
                  pointerId: 1,
                  pointerType: 'mouse',
                  isPrimary: true,
                  width: 1,
                  height: 1,
                  pressure: type === 'mousedown' || type === 'pointerdown' ? 0.5 : 0
              }));
          } catch (e) { /* ignore */ }
      }
      el.dispatchEvent(new MouseEvent(type, common));
  }

  async function performClick(el, { button = 0, count = 1 } = {}) {
      const coords = getElementCenter(el);
      dispatchPointerLike(el, 'mouseover', coords, button);
      dispatchPointerLike(el, 'mouseenter', coords, button);
      dispatchPointerLike(el, 'mousemove', coords, button);
      for (let i = 0; i < count; i++) {
          dispatchPointerLike(el, 'mousedown', coords, button);
          if (typeof el.focus === 'function') {
              try { el.focus({ preventScroll: true }); } catch (e) { try { el.focus(); } catch (_) { } }
          }
          dispatchPointerLike(el, 'mouseup', coords, button);
          el.dispatchEvent(new MouseEvent('click', {
              bubbles: true, cancelable: true, composed: true, view: window,
              clientX: coords.clientX, clientY: coords.clientY,
              screenX: coords.clientX, screenY: coords.clientY,
              button, buttons: 0, detail: i + 1
          }));
          if (count > 1) await sleep(50);
      }
  }

  const HIGHLIGHT_CLASS = 'webchat-script-highlight';
  const HIGHLIGHT_STYLE_ID = 'webchat-script-highlight-style';

  function ensureHighlightStyle() {
      if (document.getElementById(HIGHLIGHT_STYLE_ID)) return;
      const style = document.createElement('style');
      style.id = HIGHLIGHT_STYLE_ID;
      style.textContent = `
        .${HIGHLIGHT_CLASS} {
            outline: 2px solid #ff7a00 !important;
            outline-offset: 2px !important;
            box-shadow: 0 0 0 4px rgba(255, 122, 0, 0.25), 0 0 12px rgba(255, 122, 0, 0.6) !important;
            transition: outline-color 0.2s, box-shadow 0.2s !important;
            animation: webchat-script-pulse 1s ease-in-out infinite !important;
        }
        @keyframes webchat-script-pulse {
            0%, 100% { box-shadow: 0 0 0 4px rgba(255, 122, 0, 0.25), 0 0 12px rgba(255, 122, 0, 0.6); }
            50%      { box-shadow: 0 0 0 6px rgba(255, 122, 0, 0.45), 0 0 18px rgba(255, 122, 0, 0.9); }
        }
    `;
      document.documentElement.appendChild(style);
  }

  function highlightElement(el, durationMs = 0) {
      if (!el || !el.classList) return () => { };
      ensureHighlightStyle();
      el.classList.add(HIGHLIGHT_CLASS);
      let removed = false;
      const remove = () => {
          if (removed) return;
          removed = true;
          try { el.classList.remove(HIGHLIGHT_CLASS); } catch (e) { /* ignore */ }
      };
      if (durationMs > 0) setTimeout(remove, durationMs);
      return remove;
  }

  async function waitForUiSettled({ quietMs = 250, maxMs = 1500 } = {}) {
      return new Promise((resolve) => {
          const start = Date.now();
          let lastChange = Date.now();
          const observer = new MutationObserver(() => {
              lastChange = Date.now();
          });
          observer.observe(document.body, {
              childList: true,
              subtree: true,
              attributes: true,
              attributeFilter: ['class', 'style', 'aria-hidden', 'aria-expanded', 'data-state']
          });
          const tick = () => {
              const now = Date.now();
              if (now - lastChange >= quietMs || now - start >= maxMs) {
                  observer.disconnect();
                  resolve();
              } else {
                  setTimeout(tick, 50);
              }
          };
          setTimeout(tick, 50);
      });
  }

  function setNativeValue(el, value) {
      const proto = Object.getPrototypeOf(el);
      const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
      const protoSetter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set
          || Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value')?.set;
      if (setter && setter !== protoSetter) {
          protoSetter.call(el, value);
      } else if (setter) {
          setter.call(el, value);
      } else {
          el.value = value;
      }
  }

  function findVisibleOption(text) {
      const normalized = String(text).replace(/\s+/g, ' ').trim();
      if (!normalized) return null;
      const selectors = [
          '.ant-select-dropdown [role="option"]',
          '.ant-select-dropdown .ant-select-item-option-content',
          '[role="listbox"] [role="option"]',
          '.el-select-dropdown__item',
          '.MuiMenu-paper [role="option"]',
          '.MuiMenu-paper [role="menuitem"]'
      ];
      const candidates = [];
      for (const selector of selectors) {
          try { candidates.push(...document.querySelectorAll(selector)); } catch (e) { /* ignore */ }
      }
      for (const el of candidates) {
          if (!isVisible(el)) continue;
          const value = (el.getAttribute('title') || el.getAttribute('aria-label') || el.textContent || '')
              .replace(/\s+/g, ' ')
              .trim();
          if (value === normalized) return el;
      }
      for (const el of candidates) {
          if (!isVisible(el)) continue;
          const value = (el.getAttribute('title') || el.getAttribute('aria-label') || el.textContent || '')
              .replace(/\s+/g, ' ')
              .trim();
          if (value.includes(normalized)) return el;
      }
      return null;
  }

  // 特殊键映射（仿 selenium-ide）：${KEY_ENTER} / ${KEY_TAB} 等
  const SPECIAL_KEY_MAP = {
      KEY_ENTER: '', KEY_RETURN: '',
      KEY_TAB: '',
      KEY_ESC: '', KEY_ESCAPE: '',
      KEY_BACKSPACE: '', KEY_BKSP: '',
      KEY_DELETE: '', KEY_DEL: '',
      KEY_SPACE: ' ', KEY_SPC: ' ',
      KEY_UP: '', KEY_DOWN: '',
      KEY_LEFT: '', KEY_RIGHT: '',
      KEY_HOME: '', KEY_END: '',
      KEY_PAGE_UP: '', KEY_PAGE_DOWN: ''
  };

  // 反查：给 input handler 用，把  还原为 'Enter' 这种 KeyboardEvent.key
  const UNICODE_TO_KEY = {
      '': 'Enter', '': 'Tab', '': 'Escape',
      '': 'Backspace', '': 'Delete',
      '': 'ArrowUp', '': 'ArrowDown',
      '': 'ArrowLeft', '': 'ArrowRight',
      '': 'Home', '': 'End',
      '': 'PageUp', '': 'PageDown'
  };

  function splitSpecialKeys(value) {
      if (!value) return [{ kind: 'text', text: '' }];
      const out = [];
      let buf = '';
      for (const ch of String(value)) {
          if (UNICODE_TO_KEY[ch]) {
              if (buf) { out.push({ kind: 'text', text: buf }); buf = ''; }
              out.push({ kind: 'key', key: UNICODE_TO_KEY[ch] });
          } else {
              buf += ch;
          }
      }
      if (buf) out.push({ kind: 'text', text: buf });
      return out;
  }

  function interpolate(text, variables) {
      if (typeof text !== 'string') return text;
      // 先替换 ${...}：先尝试特殊键，再变量；变量支持 a.b.c
      let out = text.replace(/\$\{\s*([^}]+?)\s*\}/g, (m, key) => {
          if (Object.prototype.hasOwnProperty.call(SPECIAL_KEY_MAP, key)) return SPECIAL_KEY_MAP[key];
          const parts = key.split('.');
          let val = variables;
          for (const p of parts) {
              if (val == null) return m;
              val = val[p];
          }
          return val == null ? m : String(val);
      });
      // 兼容旧 {{var}}
      out = out.replace(/\{\{\s*([^}]+?)\s*\}\}/g, (m, key) => {
          const parts = key.split('.');
          let val = variables;
          for (const p of parts) {
              if (val == null) return m;
              val = val[p];
          }
          return val == null ? m : String(val);
      });
      return out;
  }

  function resolveStep(step, variables) {
      const cloned = JSON.parse(JSON.stringify(step));
      const walk = (obj) => {
          if (obj == null) return;
          if (Array.isArray(obj)) {
              obj.forEach((v, i) => {
                  if (typeof v === 'string') obj[i] = interpolate(v, variables);
                  else walk(v);
              });
          } else if (typeof obj === 'object') {
              for (const k of Object.keys(obj)) {
                  if (typeof obj[k] === 'string') obj[k] = interpolate(obj[k], variables);
                  else walk(obj[k]);
              }
          }
      };
      walk(cloned);
      return cloned;
  }

  const actions = {
      async navigate(params) {
          // 如果已在目标页面（忽略末尾斜杠），跳过导航避免刷新导致脚本中断
          const target = String(params.url || '').replace(/\/+$/, '');
          const current = window.location.href.replace(/\/+$/, '');
          if (target && current === target) {
              return;
          }
          window.location.href = params.url;
          await sleep(200);
      },
      async reload() { window.location.reload(); await sleep(200); },
      async back() { window.history.back(); await sleep(200); },
      async forward() { window.history.forward(); await sleep(200); },

      async wait(params, options) {
          const timeout = options?.timeout ?? 5000;
          const state = params.state || 'visible';
          await waitForElementState(params, state, timeout);
      },
      async waitTime(params) { await sleep(params.duration || 1000); },

      async click(params, options) {
          const timeout = options?.timeout ?? 5000;
          const button = params.button === 'right' ? 2 : params.button === 'middle' ? 1 : 0;
          const count = params.clickCount || 1;
          // expect: 'popup' 表示这一步语义是"打开下拉/弹层"，点完要校验 popup 数量增加；
          // 未指定时按"无期望"处理，等价于历史行为
          const expect = params.expect || 'auto';
          const wantPopup = expect === 'popup';

          await tryWithCandidates(params, async (el) => {
              el.scrollIntoView({ behavior: 'smooth', block: 'center' });
              await sleep(150);
              const baseline = wantPopup ? countPopups() : 0;
              await performClick(el, { button, count });
              await new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)));
              await waitForUiSettled();
              if (wantPopup) {
                  const opened = await waitForPopupAppeared(baseline, 800);
                  if (!opened) return { ok: false, reason: 'popup-not-opened' };
              }
              return { ok: true };
          }, { timeout, label: 'click' });

          return { ok: true };
      },

      async dblclick(params, options) {
          const timeout = options?.timeout ?? 5000;
          const el = await waitForElement(params, timeout);
          el.scrollIntoView({ behavior: 'smooth', block: 'center' });
          await sleep(150);
          await performClick(el, { count: 2 });
          const coords = getElementCenter(el);
          el.dispatchEvent(new MouseEvent('dblclick', {
              bubbles: true, cancelable: true, composed: true, view: window,
              clientX: coords.clientX, clientY: coords.clientY, detail: 2
          }));
          await waitForUiSettled();
      },

      async input(params, options) {
          const timeout = options?.timeout ?? 5000;
          const el = await waitForElement(params, timeout);
          el.scrollIntoView({ behavior: 'smooth', block: 'center' });
          await sleep(80);
          const coords = getElementCenter(el);
          dispatchPointerLike(el, 'mouseover', coords);
          dispatchPointerLike(el, 'mousemove', coords);
          dispatchPointerLike(el, 'mousedown', coords);
          try { el.focus({ preventScroll: true }); } catch (e) { try { el.focus(); } catch (_) { } }
          dispatchPointerLike(el, 'mouseup', coords);
          el.dispatchEvent(new MouseEvent('click', {
              bubbles: true, cancelable: true, composed: true, view: window,
              clientX: coords.clientX, clientY: coords.clientY, button: 0, detail: 1
          }));
          await new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)));

          if (params.clearBefore) {
              setNativeValue(el, '');
              el.dispatchEvent(new Event('input', { bubbles: true }));
          }
          const value = String(params.value ?? '');
          // 把 unicode 特殊键（如  Enter）切成 [{kind:'text', text}, {kind:'key', key:'Enter'}, ...]
          const segments = splitSpecialKeys(value);
          if (params.simulateTyping === false) {
              // 非模拟：只把文本段拼回 value，键段单独 dispatch keydown/keyup
              let plain = '';
              for (const seg of segments) if (seg.kind === 'text') plain += seg.text;
              setNativeValue(el, (params.clearBefore ? '' : el.value || '') + plain);
              el.dispatchEvent(new Event('input', { bubbles: true }));
              for (const seg of segments) {
                  if (seg.kind === 'key') {
                      el.dispatchEvent(new KeyboardEvent('keydown', { key: seg.key, bubbles: true, cancelable: true }));
                      el.dispatchEvent(new KeyboardEvent('keyup', { key: seg.key, bubbles: true, cancelable: true }));
                  }
              }
          } else {
              let current = params.clearBefore ? '' : (el.value || '');
              for (const seg of segments) {
                  if (seg.kind === 'text') {
                      for (const ch of seg.text) {
                          current += ch;
                          setNativeValue(el, current);
                          el.dispatchEvent(new KeyboardEvent('keydown', { key: ch, bubbles: true, cancelable: true }));
                          el.dispatchEvent(new Event('input', { bubbles: true }));
                          el.dispatchEvent(new KeyboardEvent('keyup', { key: ch, bubbles: true, cancelable: true }));
                          if (params.delay) await sleep(params.delay);
                      }
                  } else {
                      el.dispatchEvent(new KeyboardEvent('keydown', { key: seg.key, bubbles: true, cancelable: true }));
                      el.dispatchEvent(new KeyboardEvent('keyup', { key: seg.key, bubbles: true, cancelable: true }));
                      if (params.delay) await sleep(params.delay);
                  }
              }
          }
          el.dispatchEvent(new Event('change', { bubbles: true }));
          await waitForUiSettled();
      },

      async type(params, options) {
          return actions.input({
              selector: params.selector,
              value: params.text,
              delay: params.delay ?? 50,
              clearBefore: !!params.clearBefore
          }, options);
      },

      async select(params, options) {
          const timeout = options?.timeout ?? 5000;
          const el = await waitForElement(params, timeout);
          if (el.tagName?.toLowerCase() !== 'select') {
              const text = params.text ?? params.value ?? params.label;
              if (text == null) throw new Error('select 缺少 value/text');
              // 点 trigger：要求 popup 真的弹出来；不弹就换候选 locator
              await actions.click({ ...params, expect: 'popup' }, options);
              const popupSel = params.popupSelector || POPUP_WAIT_SELECTOR;
              await waitForElementState({ selector: popupSel }, 'visible', timeout).catch(() => null);
              const option = findVisibleOption(String(text));
              if (!option) throw new Error(`未找到选项：${text}`);
              await performClick(option);
              await waitForUiSettled();
              return { ok: true };
          }
          if (params.value != null) el.value = params.value;
          else if (params.text != null) {
              const opt = Array.from(el.options || []).find(o => o.text === params.text);
              if (opt) el.value = opt.value;
          } else if (params.index != null) el.selectedIndex = params.index;
          el.dispatchEvent(new Event('change', { bubbles: true }));
      },

      async checkbox(params, options) {
          const timeout = options?.timeout ?? 5000;
          const el = await waitForElement(params, timeout);
          if (el.checked !== !!params.checked) el.click();
      },

      async scroll(params) {
          if (params.selector || (Array.isArray(params.targets) && params.targets.length)) {
              const el = findByParams(params);
              if (el) el.scrollTo({ left: params.x || 0, top: params.y || 0, behavior: params.behavior || 'smooth' });
          } else {
              window.scrollTo({ left: params.x || 0, top: params.y || 0, behavior: params.behavior || 'smooth' });
          }
          await sleep(200);
      },

      async hover(params, options) {
          const timeout = options?.timeout ?? 5000;
          const el = await waitForElement(params, timeout);
          el.scrollIntoView({ behavior: 'smooth', block: 'center' });
          await sleep(100);
          const coords = getElementCenter(el);
          dispatchPointerLike(el, 'mouseover', coords);
          dispatchPointerLike(el, 'mouseenter', coords);
          dispatchPointerLike(el, 'mousemove', coords);
          if (params.duration) await sleep(params.duration);
      },

      async keypress(params, options) {
          const target = params.selector
              ? await waitForElement(params.selector, params.selectorFallbacks || [], options?.timeout ?? 5000)
              : document.activeElement || document.body;
          const init = {
              key: params.key,
              code: params.key,
              bubbles: true,
              cancelable: true,
              ctrlKey: !!(params.modifiers && params.modifiers.includes('ctrl')),
              shiftKey: !!(params.modifiers && params.modifiers.includes('shift')),
              altKey: !!(params.modifiers && params.modifiers.includes('alt')),
              metaKey: !!(params.modifiers && params.modifiers.includes('meta'))
          };
          target.dispatchEvent(new KeyboardEvent('keydown', init));
          target.dispatchEvent(new KeyboardEvent('keypress', init));
          target.dispatchEvent(new KeyboardEvent('keyup', init));
      },

      async hotkey(params) {
          const keys = params.keys || [];
          const modifiers = keys.slice(0, -1).map(k => k.toLowerCase());
          const key = keys[keys.length - 1];
          return actions.keypress({ key, modifiers });
      },

      async drag(params, options) {
          const timeout = options?.timeout ?? 5000;
          const source = await waitForElement(params.sourceSelector, params.sourceFallbacks || [], timeout);
          const sRect = source.getBoundingClientRect();
          const sX = sRect.left + sRect.width / 2;
          const sY = sRect.top + sRect.height / 2;
          let tX, tY;
          if (params.targetSelector) {
              const target = await waitForElement(params.targetSelector, params.targetFallbacks || [], timeout);
              const tRect = target.getBoundingClientRect();
              tX = tRect.left + tRect.width / 2;
              tY = tRect.top + tRect.height / 2;
          } else if (params.targetPosition) {
              tX = params.targetPosition.x;
              tY = params.targetPosition.y;
          } else {
              throw new Error('drag 缺少目标参数');
          }
          const dt = new DataTransfer();
          source.dispatchEvent(new DragEvent('dragstart', { bubbles: true, clientX: sX, clientY: sY, dataTransfer: dt }));
          source.dispatchEvent(new DragEvent('drag', { bubbles: true, clientX: sX, clientY: sY, dataTransfer: dt }));
          const overTarget = document.elementFromPoint(tX, tY) || document.body;
          overTarget.dispatchEvent(new DragEvent('dragenter', { bubbles: true, clientX: tX, clientY: tY, dataTransfer: dt }));
          overTarget.dispatchEvent(new DragEvent('dragover', { bubbles: true, clientX: tX, clientY: tY, dataTransfer: dt }));
          overTarget.dispatchEvent(new DragEvent('drop', { bubbles: true, clientX: tX, clientY: tY, dataTransfer: dt }));
          source.dispatchEvent(new DragEvent('dragend', { bubbles: true, clientX: tX, clientY: tY, dataTransfer: dt }));
      },

      async screenshot(params) {
          return new Promise((resolve, reject) => {
              chrome.runtime.sendMessage({
                  action: 'captureScreenshot',
                  options: { format: params.format || 'png' }
              }, (resp) => {
                  if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
                  else if (resp && resp.dataUrl) resolve({ dataUrl: resp.dataUrl });
                  else reject(new Error('截图失败'));
              });
          });
      },

      async extract(params, options, ctx) {
          const timeout = options?.timeout ?? 5000;
          const el = await waitForElement(params, timeout);
          let value;
          const attr = params.attribute || 'text';
          if (attr === 'text') value = el.textContent.trim();
          else if (attr === 'html') value = el.innerHTML;
          else if (attr === 'value') value = el.value;
          else value = el.getAttribute(attr);
          if (params.saveTo && ctx) ctx.variables[params.saveTo] = value;
          return { value };
      },

      async extractList(params, options, ctx) {
          const timeout = options?.timeout ?? 5000;
          await waitForElement(params, timeout).catch(() => null);
          const items = Array.from(document.querySelectorAll(params.selector));
          const fields = params.fields || [];
          const result = items.map(item => {
              const row = {};
              for (const field of fields) {
                  const sub = field.subSelector ? item.querySelector(field.subSelector) : item;
                  if (!sub) { row[field.name] = null; continue; }
                  const a = field.attribute || 'text';
                  if (a === 'text') row[field.name] = sub.textContent.trim();
                  else if (a === 'html') row[field.name] = sub.innerHTML;
                  else row[field.name] = sub.getAttribute(a);
              }
              return row;
          });
          if (params.saveTo && ctx) ctx.variables[params.saveTo] = result;
          return { value: result };
      },

      async extractTable(params, options, ctx) {
          const timeout = options?.timeout ?? 5000;
          const table = await waitForElement(params, timeout);
          const rows = Array.from(table.querySelectorAll('tr'));
          let headers = [];
          let dataRows = rows;
          if (params.headers !== false) {
              const headerRow = rows[0];
              if (headerRow) {
                  headers = Array.from(headerRow.querySelectorAll('th, td')).map(c => c.textContent.trim());
                  dataRows = rows.slice(1);
              }
          }
          const result = dataRows.map(row => {
              const cells = Array.from(row.querySelectorAll('td, th')).map(c => c.textContent.trim());
              if (headers.length) {
                  const obj = {};
                  headers.forEach((h, i) => { obj[h] = cells[i] ?? null; });
                  return obj;
              }
              return cells;
          });
          if (params.saveTo && ctx) ctx.variables[params.saveTo] = result;
          return { value: result };
      },

      async assert(params, options) {
          const onFail = options?.onFail || 'stop';
          const timeout = options?.timeout ?? 5000;
          const condition = params.condition;
          let pass = false;
          try {
              if (condition === 'elementVisible') {
                  const el = await waitForElementState(params, 'visible', timeout);
                  pass = !!el;
              } else if (condition === 'elementHidden') {
                  await waitForElementState(params, 'hidden', timeout);
                  pass = true;
              } else if (condition === 'textEquals') {
                  const el = await waitForElement(params, timeout);
                  pass = el.textContent.trim() === params.expected;
              } else if (condition === 'textContains') {
                  const el = await waitForElement(params, timeout);
                  pass = el.textContent.includes(params.expected);
              } else if (condition === 'urlContains') {
                  pass = location.href.includes(params.expected);
              }
          } catch (e) {
              pass = false;
          }
          if (!pass) {
              const message = params.message || `断言失败：${condition}`;
              if (onFail === 'stop') throw new Error(message);
              if (onFail === 'warn') console.warn('[WebChat]', message);
          }
          return { pass };
      },

      async setVariable(params, options, ctx) {
          if (!ctx) return;
          ctx.variables[params.name] = params.value;
      },

      async log(params) {
          const level = params.level || 'info';
          (console[level] || console.log)('[WebChat脚本]', params.message);
      },

      async condition(params, options, ctx, runner) {
          const expr = params.if;
          let result = false;
          try {
              const text = interpolate(expr, ctx.variables || {});
              const eqMatch = text.match(/^\s*(.+?)\s*(==|!=)\s*(.+?)\s*$/);
              if (eqMatch) {
                  const [, a, op, b] = eqMatch;
                  result = op === '==' ? a === b : a !== b;
              } else {
                  result = !!text && text !== 'false' && text !== '0';
              }
          } catch (e) {
              result = false;
          }
          const branch = result ? params.then : params.else;
          if (Array.isArray(branch)) await runner(branch);
      },

      async loop(params, options, ctx, runner) {
          const type = params.type || 'count';
          if (type === 'count') {
              const n = Number(params.count) || 0;
              for (let i = 0; i < n; i++) {
                  ctx.variables.$index = i;
                  await runner(params.steps || []);
              }
          } else if (type === 'forEach') {
              const items = Array.isArray(params.items) ? params.items
                  : (typeof params.items === 'string' && ctx.variables[params.items]) || [];
              for (let i = 0; i < items.length; i++) {
                  ctx.variables.$item = items[i];
                  ctx.variables.$index = i;
                  await runner(params.steps || []);
              }
          } else if (type === 'while') {
              let safety = params.maxIterations || 100;
              while (safety-- > 0) {
                  const expr = interpolate(params.condition || '', ctx.variables);
                  if (!expr || expr === 'false' || expr === '0') break;
                  await runner(params.steps || []);
              }
          }
      },

      async aiRead(params, options, ctx) {
          let content = '';
          if (params.selector || (Array.isArray(params.targets) && params.targets.length)) {
              const el = findByParams(params);
              content = el ? el.innerText : '';
          } else {
              content = document.body.innerText.slice(0, 5000);
          }
          const result = await chrome.runtime.sendMessage({
              action: 'aiAssist',
              mode: 'read',
              prompt: params.prompt,
              content
          });
          if (result && params.saveTo && ctx) ctx.variables[params.saveTo] = result.text;
          return result;
      },

      async aiLocate(params) {
          const elements = collectInteractiveElements();
          const result = await chrome.runtime.sendMessage({
              action: 'aiAssist',
              mode: 'locate',
              description: params.description,
              elements
          });
          if (result && result.selector) {
              const el = Selector.query(result.selector);
              if (el) {
                  if (params.action === 'click') return actions.click({ selector: result.selector });
                  return { selector: result.selector };
              }
          }
          throw new Error('AI 未能定位到元素');
      },

      // ====== P1: 存值 / 调试动作 ======
      async storeText(params, options, ctx) {
          const timeout = options?.timeout ?? 5000;
          const el = await waitForElement(params, timeout);
          const text = (el.textContent || '').trim();
          if (params.saveTo && ctx) ctx.variables[params.saveTo] = text;
          return { value: text };
      },

      async storeValue(params, options, ctx) {
          const timeout = options?.timeout ?? 5000;
          const el = await waitForElement(params, timeout);
          const v = el.value ?? el.getAttribute('value') ?? '';
          if (params.saveTo && ctx) ctx.variables[params.saveTo] = v;
          return { value: v };
      },

      async storeAttribute(params, options, ctx) {
          const timeout = options?.timeout ?? 5000;
          const el = await waitForElement(params, timeout);
          const v = el.getAttribute(params.attribute) ?? '';
          if (params.saveTo && ctx) ctx.variables[params.saveTo] = v;
          return { value: v };
      },

      async storeCount(params, options, ctx) {
          // 不要求元素存在；查不到就存 0
          let n = 0;
          try {
              if (Array.isArray(params.targets) && params.targets.length) {
                  // targets 数组目前只返回第一个匹配；回退到 selector 查全部
                  const sel = params.selector;
                  if (sel) n = document.querySelectorAll(sel).length;
                  else n = findByParams(params) ? 1 : 0;
              } else if (params.selector) {
                  n = document.querySelectorAll(params.selector).length;
              }
          } catch (e) { n = 0; }
          if (params.saveTo && ctx) ctx.variables[params.saveTo] = n;
          return { count: n };
      },

      async executeScript(params, options, ctx) {
          // 在页面里执行一段 JS；可访问 ctx.variables 作为 vars
          // 安全限制：只执行用户脚本里写死的函数体，不接受 eval 用户输入字符串以外的来源
          const fn = new Function('vars', 'utils', `"use strict"; return (async () => { ${params.code || 'return null;'} })();`);
          const result = await fn(ctx ? ctx.variables : {}, { sleep, isVisible });
          if (params.saveTo && ctx) ctx.variables[params.saveTo] = result;
          return { value: result };
      },

      async echo(params, options, ctx) {
          const msg = String(params.message ?? '');
          // 主流程上的 onLog 会接到
          if (ctx && ctx._onLog) ctx._onLog({ level: 'info', message: msg });
          else console.log('[WebChat echo]', msg);
          return { message: msg };
      },

      async pause(params) {
          const ms = Number(params.duration) || 0;
          if (ms > 0) await sleep(ms);
          return { paused: ms };
      }
  };

  function collectInteractiveElements() {
      return collectInteractiveElementsImpl({ async: false });
  }

  async function collectInteractiveElementsAsync({ onProgress, batchSize = 24 } = {}) {
      return collectInteractiveElementsImpl({ async: true, onProgress, batchSize });
  }

  function collectInteractiveElementsImpl({ async: isAsync, onProgress, batchSize = 24 }) {
      const fieldElements = collectFormFieldElements();
      const fieldElementSet = new Set(fieldElements);
      const els = [
          ...fieldElements,
          ...document.querySelectorAll('a, button, input, select, textarea, [role], [onclick], [tabindex], [contenteditable="true"]')
      ];
      const out = [];
      const limit = 140;
      let count = 0;
      let scanned = 0;
      const seen = new Set();
      Math.min(els.length, limit + 200); // 上限粗估，主要给进度条用
      const yieldFrame = () => new Promise(r => setTimeout(r, 0));

      const processOne = (el) => {
          scanned++;
          if (count >= limit) return false;
          if (seen.has(el)) return true;
          seen.add(el);
          if (Selector.isWebChatElement(el)) return true;
          if (!fieldElementSet.has(el) && isInsideCollectedField(el, fieldElements)) return true;
          if (isDecorativeRole(el)) return true;
          if (!isVisible(el)) return true;
          const sel = Selector.generate(el);
          const options = collectOptions(el);
          out.push({
              tag: el.tagName.toLowerCase(),
              type: el.type || null,
              role: el.getAttribute('role') || null,
              id: el.id || null,
              name: el.name || null,
              label: getElementLabel(el),
              text: (el.textContent || '').trim().slice(0, 50),
              placeholder: el.placeholder || null,
              ariaLabel: el.getAttribute('aria-label') || null,
              title: el.getAttribute('title') || null,
              value: el.value || el.getAttribute('value') || null,
              required: !!(el.required || el.getAttribute('aria-required') === 'true'),
              disabled: !!(el.disabled || el.getAttribute('aria-disabled') === 'true'),
              readOnly: !!(el.readOnly || el.getAttribute('aria-readonly') === 'true'),
              contentEditable: el.isContentEditable === true,
              pattern: el.getAttribute('pattern') || null,
              min: el.getAttribute('min') || null,
              max: el.getAttribute('max') || null,
              step: el.getAttribute('step') || null,
              inputMode: el.getAttribute('inputmode') || null,
              autocomplete: el.getAttribute('autocomplete') || null,
              formatHint: inferFormatHint(el),
              options,
              ariaHasPopup: el.getAttribute('aria-haspopup') || null,
              ariaExpanded: el.getAttribute('aria-expanded') || null,
              popupSelector: inferPopupSelector(el),
              selector: sel.primary,
              selectorFallbacks: sel.fallbacks || [],
              targets: sel.targets || []
          });
          count++;
          return true;
      };

      if (!isAsync) {
          for (const el of els) {
              if (!processOne(el)) break;
          }
          return out;
      }
      // 异步：分批 yield，定时上报进度
      return (async () => {
          for (let i = 0; i < els.length; i += batchSize) {
              const slice = els.slice(i, i + batchSize);
              for (const el of slice) {
                  if (!processOne(el)) {
                      if (onProgress) onProgress({ scanned, total: els.length, kept: count, done: true });
                      return out;
                  }
              }
              if (onProgress) onProgress({ scanned, total: els.length, kept: count, done: false });
              await yieldFrame();
          }
          if (onProgress) onProgress({ scanned, total: els.length, kept: count, done: true });
          return out;
      })();
  }

  function isInsideCollectedField(el, fieldElements) {
      return fieldElements.some(field => field !== el && field.contains && field.contains(el));
  }

  function isDecorativeRole(el) {
      const role = el.getAttribute && el.getAttribute('role');
      if (role !== 'img' && role !== 'presentation' && role !== 'none') return false;
      return !el.getAttribute('aria-controls') && !el.getAttribute('aria-haspopup') && !el.onclick;
  }

  function collectFormFieldElements() {
      const fields = [];
      const items = document.querySelectorAll('.ant-form-item, .el-form-item, .form-item');
      for (const item of items) {
          if (Selector.isWebChatElement(item) || !isVisibleEnough(item)) continue;
          const control = getBestFieldControl(item);
          if (control && !fields.includes(control)) fields.push(control);
      }
      return fields;
  }

  function getBestFieldControl(item) {
      return item.querySelector('.ant-select-selector')
          || item.querySelector('.ant-picker')
          || item.querySelector('.ant-upload, .ant-upload-wrapper')
          || item.querySelector('.ant-radio-group')
          || item.querySelector('.ant-checkbox-wrapper')
          || item.querySelector('.el-select, .el-date-editor')
          || item.querySelector('textarea, input:not([type="hidden"]), select, button, [contenteditable="true"]');
  }

  function isVisibleEnough(el) {
      if (!el || !el.getBoundingClientRect) return false;
      const rect = el.getBoundingClientRect();
      const style = window.getComputedStyle(el);
      return rect.width > 0 && rect.height > 0 && style.display !== 'none' && style.visibility !== 'hidden';
  }

  function getElementLabel(el) {
      const labelledBy = el.getAttribute('aria-labelledby');
      if (labelledBy) {
          const text = labelledBy.split(/\s+/)
              .map(id => document.getElementById(id)?.textContent || '')
              .join(' ')
              .replace(/\s+/g, ' ')
              .trim();
          if (text) return text.slice(0, 80);
      }
      const aria = el.getAttribute('aria-label');
      if (aria) return aria.trim().slice(0, 80);
      if (el.id) {
          const label = document.querySelector(`label[for="${cssStringEscape(el.id)}"]`);
          if (label?.textContent?.trim()) return label.textContent.replace(/\s+/g, ' ').trim().slice(0, 80);
      }
      const wrappingLabel = el.closest('label');
      if (wrappingLabel?.textContent?.trim()) return wrappingLabel.textContent.replace(/\s+/g, ' ').trim().slice(0, 80);
      const title = el.getAttribute('title');
      if (title) return title.trim().slice(0, 80);
      const placeholder = el.getAttribute('placeholder');
      if (placeholder) return placeholder.trim().slice(0, 80);
      return nearbyLabelText(el);
  }

  function nearbyLabelText(el) {
      const candidates = [];
      let cur = el.parentElement;
      for (let depth = 0; cur && depth < 3; depth++, cur = cur.parentElement) {
          const label = cur.querySelector('label');
          if (label && !label.contains(el)) candidates.push(label.textContent || '');
          for (const cls of ['.ant-form-item-label', '.el-form-item__label', '.form-label', '.label']) {
              const node = cur.querySelector(cls);
              if (node && !node.contains(el)) candidates.push(node.textContent || '');
          }
          const prev = cur.previousElementSibling;
          if (prev) candidates.push(prev.textContent || '');
      }
      const text = candidates.map(s => String(s).replace(/\s+/g, ' ').trim()).find(Boolean);
      return text ? text.slice(0, 80) : null;
  }

  function collectOptions(el) {
      const searchInput = findRelatedComboboxInput(el);
      if (searchInput?.getAttribute('aria-controls')) {
          return collectPortalOptions(searchInput.getAttribute('aria-controls'));
      }
      if (el.tagName?.toLowerCase() === 'select') {
          return Array.from(el.options || []).slice(0, 30).map(option => ({
              value: option.value,
              text: option.textContent.trim()
          }));
      }
      const listId = el.getAttribute('list');
      if (listId) {
          const datalist = document.getElementById(listId);
          if (datalist) {
              return Array.from(datalist.querySelectorAll('option')).slice(0, 30).map(option => ({
                  value: option.value,
                  text: option.label || option.textContent.trim()
              }));
          }
      }
      return [];
  }

  function findRelatedComboboxInput(el) {
      if (el.getAttribute('role') === 'combobox') return el;
      const item = el.closest('.ant-form-item, .el-form-item, .form-item') || el.parentElement;
      return item?.querySelector('input[role="combobox"][aria-controls]') || null;
  }

  function collectPortalOptions(id) {
      const root = document.getElementById(id);
      if (!root) return [];
      return Array.from(root.querySelectorAll('[role="option"], .ant-select-item-option-content, .el-select-dropdown__item'))
          .slice(0, 30)
          .map(option => ({
              value: option.getAttribute('title') || option.getAttribute('data-value') || option.textContent.trim(),
              text: option.textContent.trim()
          }))
          .filter(option => option.text || option.value);
  }

  function inferFormatHint(el) {
      const explicit = el.getAttribute('data-format')
          || el.getAttribute('data-format-hint')
          || el.getAttribute('format')
          || '';
      if (explicit) return explicit;
      const type = (el.type || '').toLowerCase();
      const cls = typeof el.className === 'string' ? el.className : '';
      if (/ant-picker-range|date-range|range-picker/i.test(cls)) return 'YYYY-MM-DD ~ YYYY-MM-DD';
      if (/ant-picker|date-picker/i.test(cls)) return 'YYYY-MM-DD';
      if (type === 'date') return 'YYYY-MM-DD';
      if (type === 'datetime-local') return 'YYYY-MM-DDTHH:mm';
      if (type === 'time') return 'HH:mm';
      if (type === 'month') return 'YYYY-MM';
      if (type === 'number' || type === 'range') return 'number';
      const placeholder = el.getAttribute('placeholder') || '';
      if (/yyyy-mm-dd\s*[~至到-]\s*yyyy-mm-dd/i.test(placeholder)) return 'YYYY-MM-DD ~ YYYY-MM-DD';
      if (/yyyy-mm-dd/i.test(placeholder)) return 'YYYY-MM-DD';
      if (/\d{4}[-/]\d{1,2}[-/]\d{1,2}\s*[~至到-]\s*\d{4}[-/]\d{1,2}[-/]\d{1,2}/.test(placeholder)) return 'YYYY-MM-DD ~ YYYY-MM-DD';
      if (/\d{4}[-/]\d{1,2}[-/]\d{1,2}/.test(placeholder)) return 'YYYY-MM-DD';
      return null;
  }

  function inferPopupSelector(el) {
      const relatedCombo = findRelatedComboboxInput(el);
      if (relatedCombo?.getAttribute('aria-controls')) return `#${cssStringEscape(relatedCombo.getAttribute('aria-controls'))}`;
      const controls = el.getAttribute('aria-controls');
      if (controls) return `#${cssStringEscape(controls)}`;
      const owns = el.getAttribute('aria-owns');
      if (owns) return `#${cssStringEscape(owns)}`;
      const role = el.getAttribute('role');
      const type = (el.type || '').toLowerCase();
      const cls = typeof el.className === 'string' ? el.className : '';
      if (
          el.getAttribute('aria-haspopup') ||
          role === 'combobox' ||
          type === 'date' ||
          type === 'datetime-local' ||
          /picker|select|dropdown|range/i.test(cls)
      ) {
          return '[role="dialog"], [role="listbox"], [role="menu"], .ant-picker-dropdown, .ant-select-dropdown, .el-picker-panel, .el-select-dropdown, .el-popper, .MuiPopover-root, .MuiMenu-root';
      }
      return null;
  }

  function cssStringEscape(value) {
      return String(value).replace(/\\/g, '\\\\').replace(/"/g, '\\"');
  }

  class ScriptExecutor {
      constructor(opts = {}) {
          this.mode = opts.mode || 'run';
          this.onBeforeStep = opts.onBeforeStep || (async () => { });
          this.onAfterStep = opts.onAfterStep || (async () => { });
          this.onError = opts.onError || (async () => { });
          this.onLog = opts.onLog || (() => { });
          this.aborted = false;
          this.stepDelay = Number.isFinite(opts.stepDelay) ? opts.stepDelay : 600;
          this.highlight = opts.highlight !== false;
          this.highlightLeadMs = Number.isFinite(opts.highlightLeadMs) ? opts.highlightLeadMs : 250;
      }

      abort() { this.aborted = true; }

      async _previewStep(step) {
          if (!this.highlight) return () => { };
          const sel = step?.params?.selector;
          if (!sel) return () => { };
          const fallbacks = step?.params?.selectorFallbacks || [];
          const el = Selector.query(sel, fallbacks);
          if (!el) return () => { };
          try { el.scrollIntoView({ behavior: 'smooth', block: 'center' }); } catch (e) { /* ignore */ }
          const remove = highlightElement(el);
          if (this.highlightLeadMs > 0) await sleep(this.highlightLeadMs);
          return remove;
      }

      async execute(script) {
          const ctx = {
              variables: { ...(script.variables || {}) },
              results: [],
              _onLog: (entry) => this.onLog(entry)
          };
          // 嗅探：当前是 click/未声明 expect，且下一步是 wait 一个 popup 类 selector
          // → 自动给 click 注入 expect:'popup'，让候选切换机制接管
          const looksLikePopupSelector = (sel) => {
              if (!sel) return false;
              return /role=["']?(dialog|listbox|menu)|ant-(picker|select|cascader)-dropdown|el-(picker|select|dropdown|popper)|MuiPopover|MuiMenu/i.test(sel);
          };
          const inferExpect = (step, next) => {
              if (!step || step.type !== 'click') return;
              if (step.params && step.params.expect) return;
              if (!next) return;
              if (next.type !== 'wait') return;
              const sel = next.params?.selector;
              if (looksLikePopupSelector(sel)) {
                  step.params = step.params || {};
                  step.params.expect = 'popup';
              }
          };
          const runSteps = async (steps) => {
              for (let idx = 0; idx < steps.length; idx++) {
                  const step = steps[idx];
                  if (this.aborted) throw new Error('已中止');
                  const resolved = resolveStep(step, ctx.variables);
                  inferExpect(resolved, steps[idx + 1]);
                  await this.onBeforeStep(resolved);
                  const removeHighlight = await this._previewStep(resolved);
                  const handler = actions[resolved.type];
                  if (!handler) {
                      this.onLog({ level: 'warn', step: resolved, message: `未知动作类型：${resolved.type}` });
                      removeHighlight();
                      continue;
                  }
                  try {
                      const result = await handler(resolved.params || {}, resolved.options || {}, ctx, runSteps);
                      ctx.results.push({ step: resolved, result, ok: true });
                      await this.onAfterStep(resolved, { ok: true, result });
                  } catch (err) {
                      ctx.results.push({ step: resolved, error: err.message, ok: false });
                      await this.onAfterStep(resolved, { ok: false, error: err.message });
                      const policy = (resolved.options && resolved.options.onFail) || 'stop';
                      await this.onError(resolved, err);
                      removeHighlight();
                      if (policy === 'stop') throw err;
                      if (policy === 'skip') continue;
                  }
                  removeHighlight();
                  if (this.mode === 'debug') {
                      await new Promise(r => setTimeout(r, 0));
                  }
                  if (idx < steps.length - 1 && this.stepDelay > 0) {
                      await sleep(this.stepDelay);
                  }
              }
          };
          await runSteps(script.steps || []);
          return ctx;
      }
  }

  const utils = { sleep, isVisible, interpolate, waitForElement, collectInteractiveElements, collectInteractiveElementsAsync };

  // 暴露到 window 供导出的独立 JS 脚本使用
  if (typeof window !== 'undefined') {
      window.WebChatExecutor = { ScriptExecutor, actions, utils };
  }

  // 页面元素选取器：高亮悬停元素 + 显示候选 locator + Shift+点击挑选 primary

  class ElementPicker {
      constructor() {
          this.active = false;
          this.overlay = null;
          this.tooltip = null;
          this.popup = null;
          this.lastHovered = null;
          this.callback = null;
          this._handlers = {};
          this._currentTargets = null; // 悬停元素当前的 [[locator, name], ...]
      }

      start(callback) {
          if (this.active) return;
          this.active = true;
          this.callback = callback;

          this.overlay = document.createElement('div');
          this.overlay.id = 'webchat-script-picker-overlay';
          document.body.appendChild(this.overlay);

          this.tooltip = document.createElement('div');
          this.tooltip.id = 'webchat-script-picker-tooltip';
          document.body.appendChild(this.tooltip);

          this._handlers.move = (e) => this._onMove(e);
          this._handlers.click = (e) => this._onClick(e);
          this._handlers.mousedown = (e) => this._onMouseDown(e);
          this._handlers.key = (e) => this._onKey(e);

          document.addEventListener('mousemove', this._handlers.move, true);
          document.addEventListener('mousedown', this._handlers.mousedown, true);
          document.addEventListener('click', this._handlers.click, true);
          document.addEventListener('keydown', this._handlers.key, true);
      }

      stop() {
          if (!this.active) return;
          this.active = false;
          document.removeEventListener('mousemove', this._handlers.move, true);
          document.removeEventListener('mousedown', this._handlers.mousedown, true);
          document.removeEventListener('click', this._handlers.click, true);
          document.removeEventListener('keydown', this._handlers.key, true);
          if (this.overlay) this.overlay.remove();
          if (this.tooltip) this.tooltip.remove();
          if (this.popup) this.popup.remove();
          this.overlay = null;
          this.tooltip = null;
          this.popup = null;
          this.lastHovered = null;
          this._currentTargets = null;
      }

      _onMove(e) {
          // popup 打开时不再跟随鼠标移动
          if (this.popup) return;
          const target = document.elementFromPoint(e.clientX, e.clientY);
          if (!target || target === this.overlay || target === this.tooltip) return;
          if (Selector.isWebChatElement(target)) {
              this.overlay.style.display = 'none';
              this.tooltip.style.display = 'none';
              return;
          }
          this.lastHovered = target;
          const rect = target.getBoundingClientRect();
          this.overlay.style.display = 'block';
          this.overlay.style.left = `${rect.left + window.scrollX}px`;
          this.overlay.style.top = `${rect.top + window.scrollY}px`;
          this.overlay.style.width = `${rect.width}px`;
          this.overlay.style.height = `${rect.height}px`;

          const sel = Selector.generate(target);
          this._currentTargets = sel.targets || [];
          const total = this._currentTargets.length;
          const head = sel.primary || sel.xpath || '(无法生成选择器)';
          const extra = total > 1 ? ` ｜ +${total - 1} 候选 (Shift+点击查看)` : '';
          this.tooltip.style.display = 'block';
          this.tooltip.style.left = `${rect.left + window.scrollX}px`;
          this.tooltip.style.top = `${rect.bottom + window.scrollY + 4}px`;
          this.tooltip.textContent = head + extra;
      }

      _onMouseDown(e) {
          // popup 打开时拦掉所有 mousedown，避免页面元素抢焦点导致 popup 被关闭
          if (!this.active) return;
          if (this.popup && this.popup.contains(e.target)) {
              // 落在 popup 内部的 mousedown：阻止冒泡给页面，但不阻止 popup 自己接收
              e.stopPropagation();
              e.stopImmediatePropagation();
              return;
          }
          // 选取过程中页面其他位置的 mousedown 也吃掉，避免触发页面 focus/blur
          e.preventDefault();
          e.stopPropagation();
          e.stopImmediatePropagation();
      }

      _onClick(e) {
          if (!this.active) return;

          // popup 已打开：捕获阶段先于任何页面监听器触发，统一在这里分流
          if (this.popup) {
              e.preventDefault();
              e.stopPropagation();
              e.stopImmediatePropagation();
              const li = e.target.closest && e.target.closest('#webchat-script-picker-popup li[data-idx]');
              if (li) {
                  const idx = Number(li.dataset.idx);
                  const target = this.lastHovered;
                  this._finish(target, idx);
                  return;
              }
              // 点在 popup 内部其他区域（标题/底注）：忽略，等用户继续选
              if (this.popup.contains(e.target)) return;
              // 点在 popup 外：关闭 popup，回到悬停选择状态，不 finish
              this.popup.remove();
              this.popup = null;
              return;
          }

          if (!this.lastHovered) return;
          e.preventDefault();
          e.stopPropagation();
          e.stopImmediatePropagation();

          if (e.shiftKey && this._currentTargets && this._currentTargets.length > 1) {
              this._showPopup(this.lastHovered, this._currentTargets);
              return;
          }

          this._finish(this.lastHovered, null);
      }

      _showPopup(target, targets) {
          const rect = target.getBoundingClientRect();
          const popup = document.createElement('div');
          popup.id = 'webchat-script-picker-popup';
          popup.style.left = `${rect.left + window.scrollX}px`;
          popup.style.top = `${rect.bottom + window.scrollY + 4}px`;
          popup.innerHTML = `
            <div class="wc-pick-pop-title">挑选要作为 primary 的 locator</div>
            <ul class="wc-pick-pop-list">
                ${targets.map(([loc, name], i) => `
                    <li data-idx="${i}" tabindex="0">
                        <span class="wc-pick-pop-tag">${escapeHtml$1(name)}</span>
                        <code>${escapeHtml$1(loc)}</code>
                    </li>
                `).join('')}
            </ul>
            <div class="wc-pick-pop-foot">Esc 取消 ｜ 点击候选项即应用 ｜ 点击外部关闭</div>
        `;
          document.body.appendChild(popup);
          this.popup = popup;
      }

      _finish(target, primaryIdx) {
          const sel = Selector.generate(target);
          let targets = sel.targets || [];
          // 用户挑选了某条候选时，把它放到首位
          if (primaryIdx != null && primaryIdx > 0 && primaryIdx < targets.length) {
              const picked = targets[primaryIdx];
              targets = [picked, ...targets.filter((_, i) => i !== primaryIdx)];
          }
          const cb = this.callback;
          this.stop();
          if (cb) cb({
              selector: sel.primary,
              fallbacks: sel.fallbacks,
              xpath: sel.xpath,
              targets,
              element: target
          });
      }

      _onKey(e) {
          if (e.key === 'Escape') {
              const cb = this.callback;
              this.stop();
              if (cb) cb(null);
          }
      }
  }

  function escapeHtml$1(s) {
      return String(s).replace(/[&<>"']/g, ch => ({
          '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
      })[ch]);
  }

  const ElementPicker$1 = new ElementPicker();

  // 脚本导出：JSON 与可独立运行的 JS
  function exportJSON(script) {
      return JSON.stringify(script, null, 2);
  }

  function exportJavaScript(script) {
      const json = JSON.stringify(script, null, 2);
      return `// WebChat 自动化脚本: ${script.meta?.name || '未命名'}
// 生成时间: ${new Date().toISOString()}
// 用法：在目标页面控制台粘贴运行（需先安装并启用 WebChat 扩展）
(function () {
    const script = ${json};
    if (!window.WebChatExecutor) {
        console.error('未找到 WebChatExecutor 运行时，请先安装/启用 WebChat 扩展');
        return;
    }
    const exec = new window.WebChatExecutor.ScriptExecutor({
        onLog: (info) => console.log('[WebChat]', info)
    });
    exec.execute(script).then(
        ctx => console.log('脚本执行完成', ctx),
        err => console.error('脚本执行失败', err)
    );
})();
`;
  }

  async function exportToFile(script, format = 'json') {
      const content = format === 'js' ? exportJavaScript(script) : exportJSON(script);
      const filename = (script.meta?.name || 'script').replace(/[^\w一-龥-]+/g, '_');
      const ext = format === 'js' ? 'js' : 'json';

      return new Promise((resolve, reject) => {
          chrome.runtime.sendMessage({
              action: 'downloadScript',
              content,
              filename: `webchat-scripts/${filename}.${ext}`,
              mime: format === 'js' ? 'application/javascript' : 'application/json'
          }, (resp) => {
              if (chrome.runtime.lastError) {
                  reject(new Error(chrome.runtime.lastError.message));
              } else if (resp && resp.ok) {
                  resolve(resp);
              } else {
                  reject(new Error(resp?.error || '导出失败'));
              }
          });
      });
  }

  function importFromText(text) {
      const obj = JSON.parse(text);
      if (!obj || !Array.isArray(obj.steps)) throw new Error('脚本格式不合法');
      return obj;
  }

  function hideScriptUiForPicking({ panelEl, root = document } = {}) {
      const entries = [];
      const hide = (el, mode) => {
          if (!el) return;
          entries.push({
              el,
              mode,
              className: el.className,
              display: el.style.display,
              pointerEvents: el.style.pointerEvents,
              ariaHidden: el.getAttribute('aria-hidden')
          });
          if (mode === 'panel') {
              el.classList.add('webchat-script-panel-hidden');
          } else {
              el.style.display = 'none';
              el.style.pointerEvents = 'none';
              el.setAttribute('aria-hidden', 'true');
          }
      };

      if (panelEl) hide(panelEl, 'panel');
      const modals = root.querySelectorAll('.webchat-script-modal');
      for (const modal of modals) hide(modal, 'modal');

      let restored = false;
      return () => {
          if (restored) return;
          restored = true;
          for (const entry of entries.reverse()) {
              entry.el.className = entry.className;
              entry.el.style.display = entry.display;
              entry.el.style.pointerEvents = entry.pointerEvents;
              if (entry.ariaHidden == null) entry.el.removeAttribute('aria-hidden');
              else entry.el.setAttribute('aria-hidden', entry.ariaHidden);
          }
      };
  }

  // 脚本管理面板：列表、录制、编辑、执行、AI 生成、导入导出

  const STORAGE_KEY = 'webchat_scripts';
  const PANEL_ID = 'webchat-script-panel';

  // 与 recorder.js 中的 attachHitPoint 等价：picker 选元素后由 panel 调用，给 step 补
  // 坐标兜底信息（hitPoint）。重放时若 selector / targets 都失效，executor 走该信息
  // 做 elementFromPoint 命中。仅记录元素中心点（picker 没有真实点击事件坐标）。
  function buildHitPointForElement(el) {
      if (!el || el.nodeType !== 1) return null;
      let rect;
      try { rect = el.getBoundingClientRect(); } catch { return null; }
      if (!rect) return null;
      if (rect.width === 0 && rect.height === 0) return null;
      const cx = rect.left + rect.width / 2;
      const cy = rect.top + rect.height / 2;
      const text = (el.textContent || el.value || el.placeholder || el.getAttribute?.('aria-label') || '')
          .replace(/\s+/g, ' ').trim().slice(0, 60);
      return {
          rx: 0.5,
          ry: 0.5,
          vx: Math.round(cx),
          vy: Math.round(cy),
          rect: {
              x: Math.round(rect.left),
              y: Math.round(rect.top),
              w: Math.round(rect.width),
              h: Math.round(rect.height)
          },
          viewport: {
              w: window.innerWidth,
              h: window.innerHeight,
              sx: window.scrollX,
              sy: window.scrollY
          },
          sig: {
              tag: el.tagName ? el.tagName.toLowerCase() : '',
              role: el.getAttribute?.('role') || '',
              type: el.getAttribute?.('type') || '',
              text
          }
      };
  }

  // ====== 数据存储 ======

  async function loadScripts() {
      const data = await chrome.storage.local.get(STORAGE_KEY);
      return Array.isArray(data[STORAGE_KEY]) ? data[STORAGE_KEY] : [];
  }

  async function saveScripts(list) {
      await chrome.storage.local.set({ [STORAGE_KEY]: list });
  }

  async function upsertScript(script) {
      const list = await loadScripts();
      script.meta.updatedAt = new Date().toISOString();
      const idx = list.findIndex(s => s.meta.id === script.meta.id);
      if (idx >= 0) list[idx] = script;
      else list.unshift(script);
      await saveScripts(list);
      return list;
  }

  async function deleteScript(id) {
      const list = await loadScripts();
      const next = list.filter(s => s.meta.id !== id);
      await saveScripts(next);
      return next;
  }

  // ====== 面板 ======

  let panelEl = null;
  let recordingBarEl = null;
  let currentView = 'list';
  let currentScript = null;
  let recorder = null;
  let executor = null;

  function ensurePanel() {
      if (panelEl) return panelEl;
      panelEl = document.createElement('div');
      panelEl.id = PANEL_ID;
      panelEl.innerHTML = `
        <div class="webchat-script-panel-inner">
            <div class="webchat-script-panel-header">
                <span class="webchat-script-panel-title">脚本自动化</span>
                <div class="webchat-script-panel-actions">
                    <button data-act="back" class="webchat-script-btn webchat-script-btn-icon" title="返回">←</button>
                    <button data-act="close" class="webchat-script-btn webchat-script-btn-icon" title="关闭">×</button>
                </div>
            </div>
            <div class="webchat-script-panel-body"></div>
            <div class="webchat-script-panel-footer"></div>
        </div>
    `;
      document.body.appendChild(panelEl);

      panelEl.querySelector('[data-act="close"]').addEventListener('click', () => closePanel());
      panelEl.querySelector('[data-act="back"]').addEventListener('click', () => {
          if (currentView !== 'list') renderList();
          else closePanel();
      });

      const header = panelEl.querySelector('.webchat-script-panel-header');
      let dragging = false, dx = 0, dy = 0;
      header.addEventListener('mousedown', (e) => {
          if (e.target.closest('button')) return;
          dragging = true;
          const r = panelEl.getBoundingClientRect();
          dx = e.clientX - r.left;
          dy = e.clientY - r.top;
          e.preventDefault();
      });
      document.addEventListener('mousemove', (e) => {
          if (!dragging) return;
          panelEl.style.left = (e.clientX - dx) + 'px';
          panelEl.style.top = (e.clientY - dy) + 'px';
          panelEl.style.right = 'auto';
          panelEl.style.bottom = 'auto';
      });
      document.addEventListener('mouseup', () => { dragging = false; });

      return panelEl;
  }

  function openPanel() {
      ensurePanel();
      panelEl.classList.add('webchat-script-panel-open');
      renderList();
  }

  function closePanel() {
      if (recorder?.recording) {
          recorder.stop();
          hideRecordingBar();
      }
      if (panelEl) panelEl.classList.remove('webchat-script-panel-open');
  }

  // 重新渲染前用 cloneNode(false) 替换容器：旧节点上累积的所有事件监听器
  // 会随旧节点一起被丢弃，避免每次 render 给同一个容器叠加 click/input handler
  // 而导致的"保存触发多次"等问题。
  function refreshContainer(selector) {
      const old = panelEl.querySelector(selector);
      if (!old) return null;
      const fresh = old.cloneNode(false);
      old.replaceWith(fresh);
      return fresh;
  }

  function setBody(html) {
      const body = refreshContainer('.webchat-script-panel-body');
      if (body) body.innerHTML = html;
      return body;
  }

  function setFooter(html) {
      const f = refreshContainer('.webchat-script-panel-footer');
      if (f) f.innerHTML = html;
      return f;
  }

  // ====== 列表视图 ======

  async function renderList() {
      currentView = 'list';
      currentScript = null;
      const list = await loadScripts();
      const items = list.length ? list.map(s => `
        <div class="webchat-script-item" data-id="${s.meta.id}">
            <div class="webchat-script-item-info">
                <div class="webchat-script-item-name">${escapeHtml(s.meta.name)}</div>
                <div class="webchat-script-item-meta">${s.steps.length} 步 · ${s.meta.source || 'manual'} · ${formatDate(s.meta.updatedAt)}</div>
            </div>
            <div class="webchat-script-item-actions">
                <button data-act="run" class="webchat-script-btn webchat-script-btn-primary">▶</button>
                <button data-act="edit" class="webchat-script-btn">编辑</button>
                <button data-act="export" class="webchat-script-btn">导出</button>
                <button data-act="delete" class="webchat-script-btn webchat-script-btn-danger">删除</button>
            </div>
        </div>
    `).join('') : `<div class="webchat-script-empty">暂无脚本，点击下方按钮创建</div>`;

      setBody(`<div class="webchat-script-list">${items}</div>`);
      setFooter(`
        <button data-act="record" class="webchat-script-btn webchat-script-btn-primary">● 开始录制</button>
        <button data-act="ai" class="webchat-script-btn">✨ AI 生成</button>
        <button data-act="manual" class="webchat-script-btn">+ 手动创建</button>
        <button data-act="import" class="webchat-script-btn">导入</button>
    `);

      panelEl.querySelector('.webchat-script-list').addEventListener('click', async (e) => {
          const btn = e.target.closest('button');
          if (!btn) return;
          const item = e.target.closest('.webchat-script-item');
          const id = item?.dataset.id;
          const ls = await loadScripts();
          const script = ls.find(s => s.meta.id === id);
          if (!script) return;

          const act = btn.dataset.act;
          if (act === 'run') runScript(script);
          else if (act === 'edit') openEditor(script);
          else if (act === 'export') promptExport(script);
          else if (act === 'delete') {
              if (confirm(`删除脚本 "${script.meta.name}" ?`)) {
                  await deleteScript(id);
                  renderList();
              }
          }
      });

      panelEl.querySelector('.webchat-script-panel-footer').addEventListener('click', (e) => {
          const btn = e.target.closest('button');
          if (!btn) return;
          const act = btn.dataset.act;
          if (act === 'record') startRecording();
          else if (act === 'ai') openAIGenerator();
          else if (act === 'manual') openEditor(blankScript());
          else if (act === 'import') openImport();
      });
  }

  function blankScript() {
      return {
          meta: {
              id: 'script_' + Date.now(),
              name: '新脚本',
              description: '',
              version: '1.0',
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString(),
              source: 'manual',
              targetUrl: location.href
          },
          variables: {},
          steps: []
      };
  }

  // ====== 录制视图 ======

  function startRecording() {
      currentView = 'record';
      recorder = new Recorder({
          onChange: (steps) => updateRecordingBarCount(steps)
      });
      recorder.start();
      // 隐藏主面板，避免影响录制；改用顶部悬浮控制条
      if (panelEl) panelEl.classList.add('webchat-script-panel-hidden');
      showRecordingBar();
  }

  function ensureRecordingBar() {
      if (recordingBarEl) return recordingBarEl;
      const bar = document.createElement('div');
      bar.id = 'webchat-script-recording-bar';
      bar.innerHTML = `
        <div class="webchat-rec-bar-drag" title="拖动">⋮⋮</div>
        <span class="webchat-rec-bar-dot"></span>
        <span class="webchat-rec-bar-label">录制中</span>
        <span class="webchat-rec-bar-count" data-count>0 步</span>
        <button data-act="pause" class="webchat-rec-bar-btn">暂停</button>
        <button data-act="stop" class="webchat-rec-bar-btn webchat-rec-bar-btn-primary">停止并保存</button>
        <button data-act="cancel" class="webchat-rec-bar-btn webchat-rec-bar-btn-danger">取消</button>
    `;
      document.body.appendChild(bar);

      // 拖动
      const handle = bar.querySelector('.webchat-rec-bar-drag');
      let dragging = false, dx = 0, dy = 0;
      handle.addEventListener('mousedown', (e) => {
          dragging = true;
          const r = bar.getBoundingClientRect();
          dx = e.clientX - r.left;
          dy = e.clientY - r.top;
          bar.style.transition = 'none';
          e.preventDefault();
          e.stopPropagation();
      });
      document.addEventListener('mousemove', (e) => {
          if (!dragging) return;
          bar.style.left = (e.clientX - dx) + 'px';
          bar.style.top = (e.clientY - dy) + 'px';
          bar.style.right = 'auto';
          bar.style.transform = 'none';
      });
      document.addEventListener('mouseup', () => { dragging = false; });

      bar.addEventListener('click', async (e) => {
          const btn = e.target.closest('button');
          if (!btn) return;
          const act = btn.dataset.act;
          if (act === 'pause') {
              if (recorder.paused) { recorder.resume(); btn.textContent = '暂停'; }
              else { recorder.pause(); btn.textContent = '继续'; }
          } else if (act === 'stop') {
              recorder.stop();
              hideRecordingBar();
              if (panelEl) panelEl.classList.remove('webchat-script-panel-hidden');
              const name = prompt('脚本名称：', '录制脚本 ' + new Date().toLocaleTimeString());
              if (!name) return renderList();
              const script = recorder.getScript({ name });
              await upsertScript(script);
              renderList();
          } else if (act === 'cancel') {
              recorder.stop();
              hideRecordingBar();
              if (panelEl) panelEl.classList.remove('webchat-script-panel-hidden');
              renderList();
          }
      });

      recordingBarEl = bar;
      return bar;
  }

  function showRecordingBar() {
      const bar = ensureRecordingBar();
      bar.classList.add('webchat-rec-bar-open');
      updateRecordingBarCount(recorder?.steps || []);
  }

  function hideRecordingBar() {
      if (recordingBarEl) recordingBarEl.classList.remove('webchat-rec-bar-open');
  }

  function updateRecordingBarCount(steps) {
      const el = recordingBarEl?.querySelector('[data-count]');
      if (el) el.textContent = `${steps.length} 步`;
  }

  // ====== 脚本编辑器 ======

  function openEditor(script) {
      currentView = 'edit';
      currentScript = JSON.parse(JSON.stringify(script));
      renderEditor();
  }

  function renderEditor() {
      const s = currentScript;
      setBody(`
        <div class="webchat-script-editor">
            <div class="webchat-script-meta">
                <label>名称 <input type="text" data-field="name" value="${escapeAttr(s.meta.name)}"></label>
                <label>描述 <input type="text" data-field="description" value="${escapeAttr(s.meta.description || '')}"></label>
            </div>
            <div class="webchat-script-vars">
                <div class="webchat-script-section-title">变量</div>
                <div class="webchat-script-vars-list"></div>
                <button data-act="add-var" class="webchat-script-btn webchat-script-btn-small">+ 添加变量</button>
            </div>
            <div class="webchat-script-steps">
                <div class="webchat-script-section-title">步骤 (${s.steps.length})</div>
                <ol class="webchat-script-steps-list" data-list></ol>
                <button data-act="add-step" class="webchat-script-btn webchat-script-btn-small">+ 添加步骤</button>
            </div>
        </div>
    `);
      setFooter(`
        <button data-act="run" class="webchat-script-btn webchat-script-btn-primary">▶ 运行</button>
        <button data-act="save" class="webchat-script-btn webchat-script-btn-primary">保存</button>
        <button data-act="export-json" class="webchat-script-btn">导出 JSON</button>
    `);
      renderVarsList();
      renderStepsList();
      bindEditor();
  }

  function bindEditor() {
      const body = panelEl.querySelector('.webchat-script-panel-body');
      body.addEventListener('input', (e) => {
          const t = e.target.dataset.field;
          if (t && (t === 'name' || t === 'description')) {
              currentScript.meta[t] = e.target.value;
          }
      });
      body.addEventListener('click', (e) => {
          const btn = e.target.closest('button');
          if (!btn) return;
          const act = btn.dataset.act;
          if (act === 'add-var') {
              const name = prompt('变量名：');
              if (!name) return;
              currentScript.variables[name] = '';
              renderVarsList();
          } else if (act === 'remove-var') {
              const name = btn.dataset.name;
              delete currentScript.variables[name];
              renderVarsList();
          } else if (act === 'add-step') {
              addStepDialog();
          } else if (act === 'edit-step') {
              editStepDialog(Number(btn.dataset.idx));
          } else if (act === 'remove-step') {
              currentScript.steps.splice(Number(btn.dataset.idx), 1);
              renderStepsList();
          } else if (act === 'move-up') {
              const i = Number(btn.dataset.idx);
              if (i > 0) {
                  [currentScript.steps[i - 1], currentScript.steps[i]] = [currentScript.steps[i], currentScript.steps[i - 1]];
                  renderStepsList();
              }
          } else if (act === 'move-down') {
              const i = Number(btn.dataset.idx);
              if (i < currentScript.steps.length - 1) {
                  [currentScript.steps[i + 1], currentScript.steps[i]] = [currentScript.steps[i], currentScript.steps[i + 1]];
                  renderStepsList();
              }
          } else if (act === 'pick-element') {
              const idx = Number(btn.dataset.idx);
              pickElementForStep(idx);
          }
      });

      panelEl.querySelector('.webchat-script-panel-footer').addEventListener('click', async (e) => {
          const btn = e.target.closest('button');
          if (!btn) return;
          const act = btn.dataset.act;
          if (act === 'save') {
              await upsertScript(currentScript);
              alert('已保存');
              renderList();
          } else if (act === 'run') {
              await upsertScript(currentScript);
              runScript(currentScript);
          } else if (act === 'export-json') {
              promptExport(currentScript);
          }
      });
  }

  function renderVarsList() {
      // 用 clone 替换内层容器，丢掉上一次 render 时挂的 input 监听
      const old = panelEl.querySelector('.webchat-script-vars-list');
      if (!old) return;
      const wrap = old.cloneNode(false);
      old.replaceWith(wrap);

      const vars = currentScript.variables || {};
      wrap.innerHTML = Object.keys(vars).map(name => `
        <div class="webchat-script-var-row">
            <span class="webchat-script-var-name">${escapeHtml(name)}</span>
            <input type="text" data-var="${escapeAttr(name)}" value="${escapeAttr(vars[name] ?? '')}">
            <button data-act="remove-var" data-name="${escapeAttr(name)}" class="webchat-script-btn webchat-script-btn-small webchat-script-btn-danger">删</button>
        </div>
    `).join('') || '<div class="webchat-script-hint">暂无变量</div>';

      wrap.addEventListener('input', (e) => {
          const k = e.target.dataset.var;
          if (k != null) currentScript.variables[k] = e.target.value;
      });
  }

  function renderStepsList() {
      const list = panelEl.querySelector('[data-list]');
      list.innerHTML = currentScript.steps.map((s, i) => {
          const tCount = Array.isArray(s.params?.targets) ? s.params.targets.length : 0;
          const badge = tCount > 0
              ? `<span class="webchat-script-step-locators" title="${tCount} 条候选 locator">${tCount}</span>`
              : '';
          return `
        <li class="webchat-script-step" data-idx="${i}">
            <div class="webchat-script-step-head">
                <span class="webchat-script-step-type">${stepIcon(s.type)} ${s.type}</span>
                ${badge}
                <span class="webchat-script-step-desc">${escapeHtml(s.description || '')}</span>
            </div>
            <div class="webchat-script-step-body">
                <code>${escapeHtml(stepSummary(s))}</code>
            </div>
            <div class="webchat-script-step-actions">
                <button data-act="move-up" data-idx="${i}" class="webchat-script-btn webchat-script-btn-small">↑</button>
                <button data-act="move-down" data-idx="${i}" class="webchat-script-btn webchat-script-btn-small">↓</button>
                <button data-act="edit-step" data-idx="${i}" class="webchat-script-btn webchat-script-btn-small">编辑</button>
                <button data-act="remove-step" data-idx="${i}" class="webchat-script-btn webchat-script-btn-small webchat-script-btn-danger">删</button>
            </div>
        </li>`;
      }).join('') || '<li class="webchat-script-empty">暂无步骤</li>';
      const title = panelEl.querySelector('.webchat-script-steps .webchat-script-section-title');
      if (title) title.textContent = `步骤 (${currentScript.steps.length})`;
  }

  function stepSummary(s) {
      const p = s.params || {};
      if (p.selector) return `${p.selector}${p.value !== undefined ? ' = ' + JSON.stringify(p.value) : ''}`;
      if (p.url) return p.url;
      if (p.duration != null) return `等待 ${p.duration}ms`;
      if (p.message) return p.message;
      return JSON.stringify(p);
  }

  function stepIcon(type) {
      const map = {
          click: '👆', dblclick: '👆👆', input: '⌨️', type: '⌨️', select: '📋',
          checkbox: '☑️', scroll: '⬇️', hover: '🖱️', wait: '⏳', waitTime: '⏱️',
          navigate: '🌐', reload: '🔄', back: '⬅️', forward: '➡️',
          keypress: '🔤', hotkey: '⚡', drag: '✋', upload: '📤', screenshot: '📷',
          extract: '📥', extractList: '📋', extractTable: '📊',
          condition: '🔀', loop: '🔁', assert: '✓', setVariable: '📝', log: '📝',
          aiRead: '🤖', aiDecide: '🤖', aiLocate: '🤖'
      };
      return map[type] || '•';
  }

  // ====== 步骤编辑对话框 ======

  function addStepDialog() { editStepDialog(-1); }

  function editStepDialog(idx) {
      const isNew = idx < 0;
      const step = isNew
          ? { id: 'step_' + Date.now(), type: 'click', description: '', params: {}, options: {} }
          : JSON.parse(JSON.stringify(currentScript.steps[idx]));

      const dialog = document.createElement('div');
      dialog.className = 'webchat-script-modal';
      dialog.innerHTML = `
        <div class="webchat-script-modal-inner">
            <div class="webchat-script-modal-header">
                <span>${isNew ? '添加步骤' : '编辑步骤'}</span>
                <button data-act="close" class="webchat-script-btn webchat-script-btn-icon">×</button>
            </div>
            <div class="webchat-script-modal-body">
                <label>动作类型
                    <select data-field="type">
                        ${ACTION_TYPES.map(t => `<option value="${t}" ${step.type === t ? 'selected' : ''}>${t}</option>`).join('')}
                    </select>
                </label>
                <label>描述 <input type="text" data-field="description" value="${escapeAttr(step.description || '')}"></label>
                <div class="webchat-script-params" data-params></div>
                <details>
                    <summary>高级 (JSON)</summary>
                    <textarea data-field="raw" rows="8">${escapeAttr(JSON.stringify(step, null, 2))}</textarea>
                </details>
            </div>
            <div class="webchat-script-modal-footer">
                <button data-act="save" class="webchat-script-btn webchat-script-btn-primary">保存</button>
                <button data-act="close" class="webchat-script-btn">取消</button>
            </div>
        </div>
    `;
      document.body.appendChild(dialog);

      const paramsBox = dialog.querySelector('[data-params]');
      renderStepParams(paramsBox, step);

      dialog.querySelector('[data-field="type"]').addEventListener('change', (e) => {
          step.type = e.target.value;
          renderStepParams(paramsBox, step);
          dialog.querySelector('[data-field="raw"]').value = JSON.stringify(step, null, 2);
      });

      paramsBox.addEventListener('input', (e) => {
          const k = e.target.dataset.param;
          if (!k) return;
          let v = e.target.type === 'checkbox' ? e.target.checked : e.target.value;
          if (e.target.dataset.parse === 'number') v = Number(v);
          step.params[k] = v;
          dialog.querySelector('[data-field="raw"]').value = JSON.stringify(step, null, 2);
      });

      paramsBox.addEventListener('click', (e) => {
          const btn = e.target.closest('button');
          if (!btn || btn.dataset.act !== 'pick') return;
          startElementPicker(({ selector, fallbacks, targets, element }) => {
              if (!selector) return;
              step.params.selector = selector;
              step.params.selectorFallbacks = fallbacks;
              if (Array.isArray(targets)) step.params.targets = targets;
              const hp = buildHitPointForElement(element);
              if (hp) step.params.hitPoint = hp;
              renderStepParams(paramsBox, step);
              dialog.querySelector('[data-field="raw"]').value = JSON.stringify(step, null, 2);
          });
      });

      dialog.addEventListener('click', (e) => {
          const btn = e.target.closest('button');
          if (!btn) return;
          const act = btn.dataset.act;
          if (act === 'close') dialog.remove();
          else if (act === 'save') {
              try {
                  const raw = dialog.querySelector('[data-field="raw"]').value;
                  const parsed = JSON.parse(raw);
                  parsed.description = dialog.querySelector('[data-field="description"]').value;
                  parsed.id = parsed.id || step.id;
                  if (isNew) currentScript.steps.push(parsed);
                  else currentScript.steps[idx] = parsed;
                  dialog.remove();
                  renderStepsList();
              } catch (err) {
                  alert('保存失败：' + err.message);
              }
          }
      });
  }

  const ACTION_TYPES = [
      'click', 'dblclick', 'input', 'type', 'select', 'checkbox', 'scroll', 'hover',
      'wait', 'waitTime', 'navigate', 'reload', 'back', 'forward',
      'keypress', 'hotkey', 'drag', 'screenshot',
      'extract', 'extractList', 'extractTable',
      'condition', 'loop', 'assert', 'setVariable', 'log',
      'aiRead', 'aiLocate'
  ];

  function renderStepParams(box, step) {
      const t = step.type;
      const p = step.params || (step.params = {});
      const fields = paramFields(t);
      box.innerHTML = fields.map(f => {
          const val = p[f.key] ?? f.defaultValue ?? '';
          if (f.type === 'checkbox') {
              return `<label class="webchat-script-row"><input type="checkbox" data-param="${f.key}" ${val ? 'checked' : ''}> ${f.label}</label>`;
          }
          const inputAttr = f.parse === 'number' ? 'data-parse="number" type="number"' : 'type="text"';
          const pickBtn = f.key === 'selector' ? `<button class="webchat-script-btn webchat-script-btn-small" data-act="pick">🎯</button>` : '';
          return `<label class="webchat-script-row">${f.label}
            <div class="webchat-script-input-wrap">
                <input ${inputAttr} data-param="${f.key}" value="${escapeAttr(typeof val === 'object' ? JSON.stringify(val) : val)}">
                ${pickBtn}
            </div>
        </label>`;
      }).join('') || '<div class="webchat-script-hint">该动作无参数</div>';
  }

  function paramFields(type) {
      const SEL = { key: 'selector', label: '选择器' };
      const VAL = { key: 'value', label: '值' };
      switch (type) {
          case 'click': case 'dblclick': case 'hover': return [SEL];
          case 'input': return [SEL, VAL, { key: 'clearBefore', label: '清空原有', type: 'checkbox', defaultValue: true }];
          case 'type': return [SEL, { key: 'text', label: '文本' }, { key: 'delay', label: '每字延迟(ms)', parse: 'number', defaultValue: 50 }];
          case 'select': return [SEL, VAL];
          case 'checkbox': return [SEL, { key: 'checked', label: '勾选', type: 'checkbox' }];
          case 'scroll': return [{ key: 'selector', label: '选择器(可空)' }, { key: 'x', label: 'X', parse: 'number' }, { key: 'y', label: 'Y', parse: 'number' }];
          case 'wait': return [SEL, { key: 'state', label: '状态(visible/hidden)' }];
          case 'waitTime': return [{ key: 'duration', label: '等待时长(ms)', parse: 'number', defaultValue: 1000 }];
          case 'navigate': return [{ key: 'url', label: 'URL' }];
          case 'keypress': return [{ key: 'key', label: '按键' }];
          case 'hotkey': return [{ key: 'keys', label: '按键(JSON 数组，如 ["Ctrl","A"])' }];
          case 'drag': return [{ key: 'sourceSelector', label: '源选择器' }, { key: 'targetSelector', label: '目标选择器' }];
          case 'screenshot': return [{ key: 'selector', label: '选择器(可空)' }, { key: 'fullPage', label: '整页', type: 'checkbox' }];
          case 'extract': return [SEL, { key: 'attribute', label: '属性(text/html/value/...)' }, { key: 'saveTo', label: '保存到变量' }];
          case 'extractList': return [SEL, { key: 'fields', label: '字段(JSON)' }, { key: 'saveTo', label: '保存到变量' }];
          case 'extractTable': return [SEL, { key: 'headers', label: '首行为表头', type: 'checkbox', defaultValue: true }, { key: 'saveTo', label: '保存到变量' }];
          case 'assert': return [SEL, { key: 'condition', label: '条件(elementVisible/textEquals/...)' }, { key: 'expected', label: '期望值' }, { key: 'message', label: '失败信息' }];
          case 'setVariable': return [{ key: 'name', label: '变量名' }, VAL];
          case 'log': return [{ key: 'message', label: '消息' }, { key: 'level', label: '级别(info/warn/error)' }];
          case 'condition': return [{ key: 'if', label: '条件表达式' }, { key: 'then', label: 'then 步骤(JSON)' }, { key: 'else', label: 'else 步骤(JSON)' }];
          case 'loop': return [{ key: 'type', label: '类型(count/forEach/while)' }, { key: 'count', label: '次数', parse: 'number' }, { key: 'items', label: 'items 变量名/数组' }, { key: 'steps', label: '子步骤(JSON)' }];
          case 'aiRead': return [{ key: 'selector', label: '选择器(可空)' }, { key: 'prompt', label: '提示词' }, { key: 'saveTo', label: '保存到变量' }];
          case 'aiLocate': return [{ key: 'description', label: '元素描述' }, { key: 'action', label: '动作(click/...)' }];
          default: return [];
      }
  }

  // ====== 元素选取 ======

  function startElementPicker(cb) {
      const restoreScriptUi = hideScriptUiForPicking({ panelEl });
      ElementPicker$1.start((res) => {
          restoreScriptUi();
          cb(res || {});
      });
  }

  function pickElementForStep(idx) {
      startElementPicker((res) => {
          if (!res || !res.selector) return;
          const step = currentScript.steps[idx];
          step.params = step.params || {};
          step.params.selector = res.selector;
          step.params.selectorFallbacks = res.fallbacks;
          if (Array.isArray(res.targets)) step.params.targets = res.targets;
          const hp = buildHitPointForElement(res.element);
          if (hp) step.params.hitPoint = hp;
          renderStepsList();
      });
  }

  // ====== AI 生成 ======

  function openAIGenerator() {
      currentView = 'ai';
      setBody(`
        <div class="webchat-script-ai">
            <div class="webchat-script-section-title">AI 脚本生成</div>
            <div class="webchat-script-hint">用自然语言描述你想自动化的操作，AI 将基于当前页面结构生成脚本。</div>
            <textarea data-field="prompt" rows="6" placeholder="例如：填写用户名 admin、密码 123456，然后点击登录按钮"></textarea>
            <div class="webchat-script-ai-progress is-empty" data-progress></div>
            <pre class="webchat-script-ai-stream is-empty" data-stream></pre>
        </div>
    `);
      setFooter(`
        <button data-act="generate" class="webchat-script-btn webchat-script-btn-primary">生成脚本</button>
    `);
      panelEl.querySelector('.webchat-script-panel-footer').addEventListener('click', async (e) => {
          const btn = e.target.closest('button');
          if (btn?.dataset.act === 'generate') await runAIGeneration(btn);
      });
  }

  // 阶段进度 UI：把"扫描元素 → 调用模型 → 解析结果"分阶段反馈
  // 关键点：
  //   1. 点按钮立即把 UI 切到"已开始"状态，下一帧才开始重活，避免点击瞬间冻屏
  //   2. 扫描阶段是真实进度（异步分批），模型阶段是不定长 indeterminate 动画
  //   3. 计时器用 setInterval 每 200ms 更新一次"已用时"，结束后清掉
  function createAIProgress(rootEl) {
      rootEl.classList.remove('is-empty');
      rootEl.innerHTML = `
        <div class="webchat-script-ai-prog-row">
            <span class="webchat-script-ai-prog-stage" data-stage>准备中...</span>
            <span class="webchat-script-ai-prog-time" data-time>0.0s</span>
        </div>
        <div class="webchat-script-ai-prog-bar"><div class="webchat-script-ai-prog-bar-fill" data-fill></div></div>
    `;
      const stageEl = rootEl.querySelector('[data-stage]');
      const timeEl = rootEl.querySelector('[data-time]');
      const fillEl = rootEl.querySelector('[data-fill]');
      const start = Date.now();
      const tick = () => { timeEl.textContent = ((Date.now() - start) / 1000).toFixed(1) + 's'; };
      const timer = setInterval(tick, 200);
      return {
          setStage(text, { indeterminate = false } = {}) {
              stageEl.textContent = text;
              stageEl.classList.remove('is-error', 'is-done');
              if (indeterminate) fillEl.classList.add('is-indeterminate');
              else fillEl.classList.remove('is-indeterminate');
          },
          setPercent(p) {
              fillEl.classList.remove('is-indeterminate');
              fillEl.style.width = Math.max(0, Math.min(100, p)) + '%';
          },
          done(text) {
              stageEl.textContent = text;
              stageEl.classList.add('is-done');
              fillEl.classList.remove('is-indeterminate');
              fillEl.classList.add('is-done');
              clearInterval(timer);
              tick();
          },
          fail(text) {
              stageEl.textContent = text;
              stageEl.classList.add('is-error');
              fillEl.classList.remove('is-indeterminate');
              fillEl.classList.add('is-error');
              clearInterval(timer);
              tick();
          }
      };
  }

  async function runAIGeneration(btn) {
      const promptEl = panelEl.querySelector('[data-field="prompt"]');
      const prompt = promptEl.value.trim();
      if (!prompt) return alert('请填写描述');
      const progressEl = panelEl.querySelector('[data-progress]');
      const streamEl = panelEl.querySelector('[data-stream]');

      // 1) 同步切到"已开始"状态、按钮禁用，避免重复点击
      if (btn) { btn.disabled = true; btn.textContent = '生成中...'; }
      promptEl.disabled = true;
      streamEl.classList.add('is-empty');
      streamEl.textContent = '';
      const prog = createAIProgress(progressEl);
      prog.setStage('扫描页面元素...');
      prog.setPercent(2);
      // 2) 让浏览器先把这帧画出来，再开始重活
      await new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)));

      let elements = [];
      try {
          elements = await utils.collectInteractiveElementsAsync({
              onProgress: ({ scanned, total, kept }) => {
                  if (!total) return;
                  const ratio = Math.min(1, scanned / total);
                  prog.setPercent(2 + Math.round(ratio * 48));
                  prog.setStage(`扫描页面元素 ${scanned}/${total}（已收集 ${kept}）`);
              }
          });
      } catch (err) {
          prog.fail('扫描失败：' + err.message);
          if (btn) { btn.disabled = false; btn.textContent = '生成脚本'; }
          promptEl.disabled = false;
          return;
      }

      prog.setStage(`AI 思考中（基于 ${elements.length} 个元素）`, { indeterminate: true });
      streamEl.classList.remove('is-empty');

      // 3) 通过 port 拿流式输出
      let port;
      try {
          port = chrome.runtime.connect({ name: 'scriptGenerateStream' });
      } catch (err) {
          prog.fail('无法连接 background：' + err.message);
          if (btn) { btn.disabled = false; btn.textContent = '生成脚本'; }
          promptEl.disabled = false;
          return;
      }

      const finish = (resetUI) => {
          try { port.disconnect(); } catch {}
          if (resetUI) {
              if (btn) { btn.disabled = false; btn.textContent = '生成脚本'; }
              promptEl.disabled = false;
          }
      };

      let totalChars = 0;
      let finished = false;
      port.onMessage.addListener(async (msg) => {
          if (msg.type === 'ping') {
              return; // 心跳，仅用于保活 service worker
          }
          if (msg.type === 'stream-start') {
              prog.setStage('AI 正在生成脚本...', { indeterminate: true });
          } else if (msg.type === 'chunk') {
              totalChars = msg.accumulated?.length ?? (totalChars + (msg.content?.length || 0));
              // 显示原文（含 ```json 包裹），用 textContent 避免任何 HTML 注入
              streamEl.textContent = msg.accumulated || (streamEl.textContent + (msg.content || ''));
              streamEl.scrollTop = streamEl.scrollHeight;
              prog.setStage(`AI 正在生成脚本 (${totalChars} 字)`, { indeterminate: true });
          } else if (msg.type === 'done') {
              finished = true;
              const script = msg.script;
              script.meta = {
                  ...blankScript().meta,
                  ...script.meta,
                  source: 'ai',
                  name: script.meta?.name || ('AI 脚本 ' + new Date().toLocaleTimeString())
              };
              currentScript = script;
              try { await upsertScript(script); } catch (e) { /* fallthrough */ }
              prog.setPercent(100);
              prog.done(`生成成功，共 ${script.steps?.length || 0} 步`);
              finish(false);
              setTimeout(() => openEditor(script), 400);
          } else if (msg.type === 'error') {
              finished = true;
              // 失败时把已积累的原文展示出来便于排错
              if (msg.raw) {
                  streamEl.textContent = msg.raw;
                  streamEl.scrollTop = streamEl.scrollHeight;
              }
              prog.fail('生成失败：' + msg.error);
              finish(true);
          }
      });

      port.onDisconnect.addListener(() => {
          if (finished) return;
          const lastErr = chrome.runtime.lastError?.message;
          prog.fail('连接已断开' + (lastErr ? '：' + lastErr : ''));
          finish(true);
      });

      port.postMessage({
          action: 'generateScript',
          prompt,
          pageInfo: {
              url: location.href,
              title: document.title,
              elements
          }
      });
  }

  // ====== 运行 ======

  async function runScript(script) {
      currentView = 'run';
      currentScript = script;
      const savedDelay = Number(localStorage.getItem('webchat_script_step_delay'));
      const initialDelay = Number.isFinite(savedDelay) && savedDelay >= 0 ? savedDelay : 600;
      const initialHighlight = localStorage.getItem('webchat_script_highlight') !== '0';
      setBody(`
        <div class="webchat-script-run">
            <div class="webchat-script-section-title">运行 ${escapeHtml(script.meta.name)}</div>
            <div class="webchat-script-run-controls">
                <label>步骤间隔(ms)
                    <input type="number" min="0" step="100" data-step-delay value="${initialDelay}" class="webchat-script-input" style="width:80px;margin-left:6px"/>
                </label>
                <label style="margin-left:12px">
                    <input type="checkbox" data-highlight ${initialHighlight ? 'checked' : ''}/>
                    高亮当前元素
                </label>
            </div>
            <ul class="webchat-script-run-log" data-log></ul>
        </div>
    `);
      setFooter(`
        <button data-act="abort" class="webchat-script-btn webchat-script-btn-danger">中止</button>
        <button data-act="back-list" class="webchat-script-btn">返回</button>
    `);

      const logEl = panelEl.querySelector('[data-log]');
      const log = (msg, cls = '') => {
          const li = document.createElement('li');
          li.className = cls;
          li.textContent = msg;
          logEl.appendChild(li);
          logEl.scrollTop = logEl.scrollHeight;
      };

      const delayInput = panelEl.querySelector('[data-step-delay]');
      const highlightInput = panelEl.querySelector('[data-highlight]');
      delayInput.addEventListener('change', () => {
          const v = Math.max(0, Number(delayInput.value) || 0);
          localStorage.setItem('webchat_script_step_delay', String(v));
          if (executor) executor.stepDelay = v;
      });
      highlightInput.addEventListener('change', () => {
          localStorage.setItem('webchat_script_highlight', highlightInput.checked ? '1' : '0');
          if (executor) executor.highlight = highlightInput.checked;
      });

      executor = new ScriptExecutor({
          stepDelay: initialDelay,
          highlight: initialHighlight,
          onBeforeStep: (step) => log(`▶ ${step.type}：${step.description || ''}`),
          onAfterStep: (step, res) => {
              if (res.ok) log(`  ✓ 完成`, 'ok');
              else log(`  ✗ 失败：${res.error}`, 'err');
          },
          onError: (step, err) => log(`  ✗ 错误：${err.message}`, 'err'),
          onLog: (info) => log(`  ${info.message || ''}`, info.level === 'error' ? 'err' : '')
      });

      panelEl.querySelector('.webchat-script-panel-footer').addEventListener('click', (e) => {
          const btn = e.target.closest('button');
          if (!btn) return;
          if (btn.dataset.act === 'abort') executor?.abort();
          if (btn.dataset.act === 'back-list') renderList();
      });

      try {
          await executor.execute(script);
          log('--- 脚本执行完成 ---', 'ok');
      } catch (err) {
          log('--- 脚本中断：' + err.message + ' ---', 'err');
      }
  }

  // ====== 导入/导出 ======

  function promptExport(script) {
      const choice = confirm('选择"确定"导出 JSON，"取消"导出可独立运行的 JS');
      const fmt = choice ? 'json' : 'js';
      exportToFile(script, fmt).then(
          () => alert('已发起下载'),
          (e) => alert('导出失败：' + e.message)
      );
  }

  function openImport() {
      const dialog = document.createElement('div');
      dialog.className = 'webchat-script-modal';
      dialog.innerHTML = `
        <div class="webchat-script-modal-inner">
            <div class="webchat-script-modal-header">
                <span>导入脚本</span>
                <button data-act="close" class="webchat-script-btn webchat-script-btn-icon">×</button>
            </div>
            <div class="webchat-script-modal-body">
                <textarea data-field="raw" rows="14" placeholder="粘贴脚本 JSON"></textarea>
            </div>
            <div class="webchat-script-modal-footer">
                <button data-act="import" class="webchat-script-btn webchat-script-btn-primary">导入</button>
                <button data-act="close" class="webchat-script-btn">取消</button>
            </div>
        </div>
    `;
      document.body.appendChild(dialog);
      dialog.addEventListener('click', async (e) => {
          const btn = e.target.closest('button');
          if (!btn) return;
          if (btn.dataset.act === 'close') dialog.remove();
          else if (btn.dataset.act === 'import') {
              try {
                  const raw = dialog.querySelector('[data-field="raw"]').value;
                  const obj = importFromText(raw);
                  obj.meta = { ...blankScript().meta, ...obj.meta, id: 'script_' + Date.now() };
                  await upsertScript(obj);
                  dialog.remove();
                  renderList();
              } catch (err) {
                  alert('导入失败：' + err.message);
              }
          }
      });
  }

  // ====== 工具 ======

  function escapeHtml(s) {
      return String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  }
  function escapeAttr(s) { return escapeHtml(s); }
  function formatDate(s) {
      if (!s) return '';
      try { return new Date(s).toLocaleString(); } catch { return s; }
  }
  const panel = { open: openPanel, close: closePanel };

  const panel$1 = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    closePanel,
    default: panel,
    openPanel
  }, Symbol.toStringTag, { value: 'Module' }));

})();
